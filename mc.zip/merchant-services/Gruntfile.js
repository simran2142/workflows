'use strict';

var path = require('path');



// grunt modules
module.exports = function(grunt) {

  // load grunt tasks automatically
  require('load-grunt-tasks')(grunt);

  // time how long tasks take. can help when optimizing build times
  require('time-grunt')(grunt);

  var appConfig = {
      liveReloadPort: 8080,
      phpPort: 8010    
  };

  // define the configuration for all the tasks
  grunt.initConfig({

  yeoman: appConfig,

  asciify: { 
    appName:{
      text: 'Merchant Serv',
      
      // Add the awesome to the console, and use the best font. 
      options: { 
        font:'standard',
        log:true
      }
    },

    reloading: {
      text: 'Reloading',
      
      // Add the awesome to the console, and use the best font. 
      options: { 
        font:'standard',
        log:true
      }
    },    

    complete: {
      text: 'Complete',
      
      // Add the awesome to the console, and use the best font. 
      options: { 
        font:'standard',
        log:true
      }
    }    
  },  

  concat: { 
    generated: { 
      files:
        [ 
        // Vendor Build
        // { dest: '.tmp\\concat\\scripts\\vendor.js',
        //   src:
        //    [ 'bower_components\\jquery\\dist\\jquery.min.js',
        //      'bower_components\\angular\\angular.js',
        //      'bower_components\\angular-animate\\angular-animate.js',
        //      'bower_components\\angular-sanitize\\angular-sanitize.js',
        //      'bower_components\\jquery.easing\\js\\jquery.easing.js',
        //      'bower_components\\BttrLazyLoading\\dist\\jquery.bttrlazyloading.js',
        //      'bower_components\\owlcarousel\\owl-carousel\\owl.carousel.js',
        //      'bower_components\\lodash\\dist\\lodash.js',
        //      'bower_components\\angular-google-maps\\dist\\angular-google-maps.js',
        //      'bower_components\\typedjs\\js\\typed.js',
        //      'bower_components\\moment\\min\\moment.min.js',
        //      'bower_components\\circliful\\js\\jquery.circliful.js',
        //      'bower_components\\nanoscroller\\bin\\javascripts\\jquery.nanoscroller.js' ] },        
          { dest: '.tmp\\concat\\scripts\\scripts.js',
            src:
              [ 
                '{.tmp,.}\\scripts\\**\\*.js', 
                '!{.tmp,.}\\scripts\\modules\\*.js'
              ] 
          },
      { dest: '.tmp\\concat\\scripts\\modules.js',
            src:
              [ 
        '{.tmp,.}\\scripts\\modules\\*.js'
              ] 
          }  
        ] 
      } 
  },     

  uglify: { 

    dev:
      { 
        options: {
          sourceMap: true
        },
        files:
        [ 
          // Vendor Build
          // { dest: 'assets\\scripts\\vendor.js',
          // src: [ '.tmp\\concat\\scripts\\vendor.js' ] },        
          { dest: 'assets\\scripts\\scripts.js',
            src: [ '.tmp\\concat\\scripts\\scripts.js' ] 
          },
      { dest: 'assets\\scripts\\modules.js',
            src: [ '.tmp\\concat\\scripts\\modules.js' ] 
          }
        ] 
      },
    dist:
      { 
        options: {
          sourceMap: false
        },
        files:
        [ 
          { dest: 'assets\\scripts\\scripts.js',
            src: [ '.tmp\\concat\\scripts\\scripts.js' ] 
          },
      { dest: 'assets\\scripts\\modules.js',
            src: [ '.tmp\\concat\\scripts\\modules.js' ] 
          }
        ] 
      }                  
  },

    // make sure code styles are up to par and there are no obvious mistakes
    jshint: {
      options: {
        jshintrc: '.jshintrc',
        reporter: require('jshint-stylish')
      },

      all: {
        src: [
          'Gruntfile.js',
          'test/**/*.js',
          './scripts/{,*/}*.js',
          '!./scripts/templates.js',
          '!./scripts/libs/**.js'
        ]
      }
    },

    // empties folders to start fresh
    clean: {
      scripts: {
        files: [{
          dot: true,
          src: [
            'assets/scripts/scripts.js',
            'assets/scripts/modules.js',    
            'assets/scripts/scripts.js.map'
          ]
        }]
      },
      css: {
        files: [{
          dot: true,
          src: [
            'assets/css/careers.css',
            'assets/css/careers.css.map'
          ]
        }]
      },
      server: '.tmp'      
    },

    // add vendor prefixed styles
    // we support IE9+ and other Modern Browsers
    //
    // TBD: Move to PostCSS as Autoprefixer is deprecated
    // https://github.com/nDmitry/grunt-postcss
    autoprefixer: {
      options: {
        browsers: ['last 2 version', 'ie 9']
      },
      dist: {
        files: [{
          expand: true,
          cwd: './assets/css/',
          src: '{,*/}*.css',
          dest: './assets/css/'
        }]
      }
    },

    // compile sass files with libsass
    sass: {
      dist: {

        options: {
          sourceMap: false,
          includePaths: ['bower_components'],
          outputStyle: 'nested',
          debugInfo: false,
          sourceComments: false,
          lineNumbers: false,
          precision: 5
        },

        files: [{
          expand: true,
          cwd: './scss',
          src: '**/*.{scss,sass}',
          dest: 'assets/css',
          ext: '.css'
        }]

      },

      dev: {
        options: {
          sourceMap: true,
          includePaths: ['bower_components'],
          outputStyle: 'nested',
          debugInfo: false,
          sourceComments: false,
          lineNumbers: false,
          precision: 5
        },

        files: [{
          expand: true,
          cwd: './scss',
          src: '**/*.{scss,sass}',
          dest: 'assets/css',
          ext: '.css'
        }]        

      }

    },

    // ng-annotate tries to make the code safe for minification automatically
    // by using the Angular long form for dependency injection.
    /*ngAnnotate: {
      dist: {
        files: [{
          expand: true,
          cwd: '.tmp/concat/scripts',
          src: '*.js',
          dest: '.tmp/concat/scripts'
        }]
      }
    },*/

    // run some tasks in parallel to speed up the build process
    concurrent: {

      dist: [
        'sass'
      ],

      dev: [
        'sync'
      ]
    },

    // test
    karma: {
      unit: {
        configFile: './karma.conf.js',
        singleRun: true
      }
    },

    // watches files for changes and runs tasks based on the changed files
    watch: {
      js: {
        files: ['./scripts/**/*.js', './test/*.spec.js'],
        tasks: ['asciify:reloading',
                'jshint',
                'clean:scripts',
                'clean:server',
                'concat',
                'ngAnnotate',
                'uglify:dev',
                'bsReload:js',
                'asciify:complete'],
        options: {
          spawn: false
        }                               
      },
      sass: {
        files: ['./scss/**/*.scss'],
        tasks: ['asciify:reloading',
                'clean:css',
                'sass:dev',
                'autoprefixer',                
                'bsReload:css',
                'asciify:complete'
               ],        
        options: {
          spawn: false
        }               
      },
      php: {
        files: [
                  '*.php',
                  './modules/*.php'
                ],
        options: {
          spawn: false
        }                                 
      }      

    },


    browserSync: {
        dev: {
            bsFiles: {
                src: [
                        '*.php',
                        './modules/*.php'
                      ]
            },
            options: {
                proxy: '127.0.0.1:<%= yeoman.phpPort %>', //our PHP server
                port: appConfig.liveReloadPort, // our new port
                open: true,
                watchTask: true,
                browser: ['chrome'
                          // , 'firefox'
                        ],
                plugins: [
                    {
                        module: 'bs-html-injector',
                        options: {
                            file: '**/*.php'
                        }
                    }
                ]                        
            }
        }
    },
    bsReload: {
      css: '*.css',
      js: '*.js'
    },
    php: {
        dev: {
            options: {
                port: appConfig.phpPort,
                base: '.'
            }
        }
    }   

  });

  grunt.registerTask('sync', ['php', 'browserSync', 'asciify:complete', 'watch']);

  grunt.loadNpmTasks('grunt-contrib-jshint');

  grunt.loadNpmTasks('grunt-asciify');

  grunt.registerTask('dist',
  [
    'asciify:appName',
    //'jshint',
    'clean:scripts',
    'clean:css',
    'concat',
    //'ngAnnotate',
    'uglify:dist',
    'sass:dist',
    'autoprefixer',
    //'karma',
    'asciify:complete'
  ]);

  grunt.registerTask('build:nokarma',
  [
    'asciify:appName',
    //'jshint',
    'clean:scripts',
    'clean:css',
    'concat',
    //'ngAnnotate',
    'uglify:dist',
    'sass:dist',
    'autoprefixer',
    'asciify:complete'
  ]);



  grunt.registerTask('dev:nokarma',
  [
    'asciify:appName',
   // 'jshint',
    'clean:scripts',
    'clean:css',
    'concat',
    //'ngAnnotate',
    'uglify:dev',
    'sass:dev',
    'autoprefixer',
    'sync'
  ]);

  grunt.registerTask('dev',
  [
    'asciify:appName',
    //'jshint',
    'clean:scripts',
    'clean:css',
    'concat',
    //'ngAnnotate',
    'uglify:dev',
    'sass:dev',
    //'autoprefixer',
    //'karma',    
    'sync'

  ]);

  grunt.registerTask('build',
  [
    'dist'
  ]);


  grunt.registerTask('default',
  [
    'dev'
  ]);
};