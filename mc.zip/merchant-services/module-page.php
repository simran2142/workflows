<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en" xml:lang="en"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang="en" xml:lang="en"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang="en" xml:lang="en"> <![endif]-->
<!--[if gt IE 8]><!-->
<!DOCTYPE html>
<html class="no-js" lang="en">
<!--<![endif]-->
<head>
  <title>Module Page | Chase Media Center</title>
  <meta content="text/html; charset=utf-8" http-equiv="content-type">
  <meta content="IE=edge" http-equiv="X-UA-Compatible">
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1, minimum-scale=1, user-scalable=no" name="viewport">
  <!--<link href="/images/chase-ux/favicon.ico" rel="shortcut icon">
  <link href="/images/chase-ux/favicon.ico" rel="icon">-->
  
  
  
  <!--<link href='/assets/css/careers.css' media="screen" rel="stylesheet" type="text/css">-->



  
  <link href='/assets/css/local/_bootstrap.css' media="screen" rel="stylesheet" type="text/css">
  <link href='/assets/css/local/_chase-styles.css' media="screen" rel="stylesheet" type="text/css">
  <link href='/assets/css/local/_fonts-opensans-smc-icomoon.css' media="screen" rel="stylesheet" type="text/css">
  <link href='/assets/css/local/_global-blue-ui.css' media="screen" rel="stylesheet" type="text/css">
  <link href='/assets/css/local/_global-site-modified.css' media="screen" rel="stylesheet" type="text/css">
  <link href='/assets/css/local/_global-MS.css' media="screen" rel="stylesheet" type="text/css">
 <!-- <link href='/assets/css/local/_merchant-services-mix-grid.css' media="screen" rel="stylesheet" type="text/css">
  <link href='/assets/css/local/_merchant-services-mix-grid-media.css' media="screen" rel="stylesheet" type="text/css">
  -->
  <link href='/assets/css/local/_merchant-services-module-page.css' media="screen" rel="stylesheet" type="text/css">
 <link href='/assets/css/local/_merchant-services-modal.css' media="screen" rel="stylesheet" type="text/css"> <!---->
  
<!--  <link href='/jpmc/css/1320482681099.css' media="screen" rel="stylesheet" type="text/css">
  <link href='/jpmc/css/1320482679147.css' media="screen" rel="stylesheet" type="text/css">
  <link href='/jpmc/css/1320482681779.css' media="screen" rel="stylesheet" type="text/css">
  <link href='/jpmc/css/1320482779878.css' media="screen" rel="stylesheet" type="text/css">
  <link href='/jpmc/css/1320482733141.css' media="screen" rel="stylesheet" type="text/css">
  <link href='/jpmc/css/1320482853770.css' media="screen" rel="stylesheet" type="text/css">
  <script src="/script/modernizr-2.js"></script>
  <script src="/script/jquery-1.js"></script>
  <script src='/jslink/bootstrap_collapse.js'></script>
  <script src='/jslink/bootstrap_modal.js'></script>
  <script src='/jslink/bootstrap_datepicker.js'></script>
  <script src='/jslink/jQ_ellipsis.js'></script>
  <script src='/jslink/mixitup_2.1.11.js'></script>
  <script src='/jslink/media-center-index-filtering.js'></script>
  <script src='/jslink/media-center-datepicker-initialize.js'></script>
  <script src='/jslink/media-center-modal-windows.js'></script>-->
  <script src='/assets/scripts/vendor.js'></script>
  <script src='/assets/scripts/scripts.js'></script>
  <script src='/assets/scripts/modules.js'></script>
  
  <!--[if lte IE 9]> 
  <script src="/script/jquery-ajaxtransport-xdomainrequest.js"></script>
  <![endif]-->

  <script src="https://chaseonline.chase.com/js/Reporting.js" type="text/javascript"></script>
  <script>
    var tagManagerConfig = { tagServer: "https://www.chase.com" };
  </script>
  <script>
    var langRedirectURL = "";
  </script>

 <!-- I have absolutely no use for require.js but I 
 cannot remove the script below or everythig breaks --> 
 <script src="/assets/scripts/require.js"></script>
 <script>
    requirejs.config({
      baseUrl: '/c/012416/etc/designs/chase-ux/clientlibs/chase-ux/js',
      paths: {
          "adservice": "https://sites.chase.com/apps/campaignmanagement/clientlibs/slotplacement/js/slotplacement.min",
          "slotplacement/slotplacementconfig" : "https://sites.chase.com/services/campaignmanagement/clientconfig.slotplacementconfig",
          "content/conf/appsconfig": tagManagerConfig.tagServer + "/etc/chase/appsconfig"
      }
    });
    define("jquery", [], function () { return jQuery; });
    define("slotplacement/clientconfig", function() {
    return {
      timeout : "1000"
    }
    });
  </script>
  <script src="/assets/scripts/chase-ux.js"></script>
  <style>
  .container.hero-container {
	  padding:0;
	  background: transparent;
  }
  .container.hero-container .hero{
	  height: inherit !important;
  }
  .container.hero-container img {
	  border: none;  
  }
  
  </style>
</head>
<body>
  <p class="accessible-text" id="linktotop">Link to Top</p>
  <div class="home__body">
   
   
      <?php include 'modules/_ms_global-header.php' ?>
  	
  
	<?php include 'modules/_ms_hero.php' ?>
	<!--</*?php include 'modules/_ms_sticky-subNav.php'*/ ?>-->

	<!--  (main)  -->
	<main role="main" tabindex="-1" class="main-content row" id="main">

	    <div class="headerAnimate"></div>
	    
	  	<?php include 'modules/_ms_module-headline.php' ?>

		<?php include 'modules/_ms_at-a-glance.php' ?>
		<?php include 'modules/_ms_at-a-glance.php' ?>
		<?php include 'modules/_ms_at-a-glance.php' ?>
		
		
		<?php include 'modules/_ms_module-headline.php' ?>
		
		<?php include 'modules/_ms_test-module.php' ?>
		
		<?php include 'modules/_ms_module-headline.php' ?>

		<?php include 'modules/_ms_test-module.php' ?>
		
		<?php include 'modules/_ms_module-headline.php' ?>
		
		<?php include 'modules/_ms_test-module.php' ?>
		
		<?php include 'modules/_ms_test-module.php' ?>
		
		<?php include 'modules/_ms_test-module.php' ?>
		

	</main><!-- /(main) -->

    
    
    
    
    <!--  FOOTER  -->
    <?php include 'modules/_ms_global-footer2.php' ?>
  
    
   
  </div><!-- END home__body -->
  
  <!--<?/*php include 'modules/_ms_modal.php' */?>-->
  
</body>
</html>