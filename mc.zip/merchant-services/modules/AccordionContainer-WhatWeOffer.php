    <section class="accordionModule module-padding-medium-both">
      <div class="container">
        <div class="row">
          <div id="prog-details-offer__accordion" class="col-xs-12 col-sm-8 col-sm-offset-2 colnopadding-small-up no-accordion-padding-top">
            <div id="accordion__component" data-accordion="" class="module accordion">
              <div id="accordion-intro" class="header-font-family text-center text-xs-left">
                <h2 id="intro__title">Who it&rsquo;s for</h2>
		    <h3 id="intro__title" class="gamma padding-reset-bottom-xs-small">What we offer</h3>
                <p id="intro__desc" class="delta accordion__tittle--sub">In this three-year program, you’ll hone critical banking skills in one of our Commercial Banking businesses to prepare you to become a banker or credit professional. You’ll also gain experience interacting with clients on meaningful projects.</p>
              </div>
              <div id="accordion-wrapper-container" class="accordion-wrapper">
                <div id="accordion-block" class="accordion-section">
                  <a id="data-content__a" class="accordion-section-title" href="#" data-content-trigger="0.07946428635870173-1">On-the-job experience</a>
                  <div id="data-content__div" data-content="0.07946428635870173-1" class="accordion-section-content">
                    <div class="accordion-section-content-wrapper">
                      <p id="accordion-block-summary">You’ll benefit from increased responsibility and industry knowledge, working with bankers to develop pitch books and presentations, preparing credit approval packages, completing financial modeling, or researching prospective clients and markets.</p>
                    </div>
                  </div>
                </div>
                <div id="accordion-block" class="accordion-section">
                  <a id="data-content__a" class="accordion-section-title" href="#" data-content-trigger="0.07946428635870173-2">Training</a>
                  <div id="data-content__div" data-content="0.07946428635870173-2" class="accordion-section-content">
                    <div class="accordion-section-content-wrapper">
                      <p id="accordion-block-summary">Depending upon your group, you’ll enjoy seven-to eight-weeks of training, learning about our products and services, clients and business practices through presentations, team exercises, exams and case studies, led by our experts and professionals. </p>
                    </div>
                  </div>
                </div>
                <div id="accordion-block" class="accordion-section">
                  <a id="data-content__a" class="accordion-section-title" href="#" data-content-trigger="0.07946428635870173-3">Career progression</a>
                  <div id="data-content__div" data-content="0.07946428635870173-3" class="accordion-section-content">
                    <div class="accordion-section-content-wrapper">
                      <p id="accordion-block-summary">After successfully completing the program, you may choose to become an Associate banker or underwriter, positioning you for a successful career in Commercial Banking.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
