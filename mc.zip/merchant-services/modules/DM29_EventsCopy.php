<section class="opportunities module" data-ng-show="usertypeSelected != 'experienced-professional'">
    <div class="container">
        <div id="events-advice" class="events">
	  <div class="visible-xs col-xs-12 text-center container">
          <h2 class="beta module-title text-center">Student Events</h2>
        </div>
            <div class="opp-subsection">
                <div class="module-padding-all-small text-center">
                    <div class="item">
                        <a href="http://careers.jpmorgan.com/careers/programs?type=Full-Time" class="img-hover">
                            <div class="img-caption img-hover-dim">
                                <figure class="has-img-hover">
                                    <img class="lazy img-responsive visible-lg-inline visible-md-inline visible-sm-inline visible-xs-block center-block" data-bttrlazyloading-sm-src="http://careers.jpmorgan.com/careers/1320683899061/1320542070216.jpg"
                                        data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320683899062/1320542070217.jpg"
                                        alt="Advice for Applicants" />
                                </figure>
                                <div class="img-caption__content text-shadow">
                                    <h3 id="img-caption__title" class="img-caption__title">Wild Guess <br class="hidden-xs">for Content</h3>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="opp-subsection">
                <div class="module-padding-all-small text-center">
                    <div class="item">
                        <h3 class="hidden-xs">Student Events</h3>
                        <p class=" text-center text-xs-left small">Lorem ipsum dolor sit amet, sed tempor equidem referrentur ut. Eam te magna numquam efficiendi. No
                            vim etiam melius salutandi. Melius patrioque eos eu, etiam fastidii mea an. Eum constituto eloquentiam
                            theophrastus ex, ei pro epicuri suscipiantur, sea essent denique tincidunt an.</p>
                        <h4>Upcoming Student Events in North America</h4>
                        <div class="row">
                            <div class="col-xs-4 text-center header-font-family margin-reset-bottom col-xs-offset-2">
                                <span class="beta in-person-events large-x gray-text">28</span><br />
                                <span class="delta">In-person Events</span> </div>
                            <div class="col-xs-4 text-center header-font-family margin-reset-bottom border-left-lg">
                                <span class="beta virtual-events large-x gray-text">3</span><br /> <span class="delta">Virtual Events</span>
                            </div>
                        </div>
                        <p class="module-padding-base-both">
                            <a href="http://careers.jpmorgan.com/careers/student-events" class="btn btn-outline red" id="browse-all-events">Browse all events</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>