<div ng-cloak data-ng-show="divToShow == 'featured_locations'">
  <div class="featured_locations">
    <div id="featured-loc-tier1" class="module-spacing-xs-small">
      <a id="img-caption-full__a" href="http://careers.jpmorgan.com/careers/locations/glasgow" class="img-hover">
        <div id="img-caption-full__container" class="location-highlight img-caption img-caption-full container-highlight">
          <div class="img-hover-dim img-hover-full">
            <div class="has-img-hover">
              <img id="img-caption-full__image" class="img-caption__image img-responsive lazy" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320712608613/1320551706832.jpg" data-bttrlazyloading-sm-src="http://careers.jpmorgan.com/careers/1320712608615/1320551706830.jpg" alt="Glasgow" />
              <noscript><img id="img-caption-full__default-image" class="img-caption__image img-responsive" src="http://careers.jpmorgan.com/careers/1320712608613/1320551706832.jpg" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320712608613/1320551706832.jpg" alt="Glasgow" /></noscript>
            </div>
            <div class="img-caption__content">
              <h2 id="img-caption-full__title" class="img-caption__title text-shadow">Glasgow</h2>
              <h3 id="img-caption-full__subtitle" class="img-caption__subtitle text-shadow">United Kingdom</h3>
              <p id="img-caption-cta" class="img-caption__cta"></p>
            </div>
          </div>
        </div>
      </a>
    </div>
    <div id="tier2-container" class="container img-caption-split">
      <div id="tier2-row" class="row">
        <div id="tier2-block__1" class="col-xs-12 col-sm-6 colnoleftpadding-small-up has-sibling">
          <body>
            <a id="img-caption__container" href="http://careers.jpmorgan.com/careers/locations/bournemouth" class="img-hover">
              <div id="img-caption__block" class="img-caption img-hover-dim">
                <div class="has-img-hover">
                  <img id="img-caption__image" class="img-caption__image img-responsive lazy" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320683006860/1320541482873.jpg" data-bttrlazyloading-sm-src="http://careers.jpmorgan.com/careers/1320683006855/1320541482872.jpg" alt="Bournemouth, United Kingdom" />
                </div>
                <noscript><div class="has-img-hover img-hover-dim"><img id="img-caption__default-img" class="img-caption__image img-responsive" src="http://careers.jpmorgan.com/careers/1320683006860/1320541482873.jpg" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320683006860/1320541482873.jpg" alt="Bournemouth, United Kingdom" /></div></noscript>
                <div class="img-caption__content text-shadow">
                  <h2 id="img-caption__title" class="img-caption__title">Bournemouth</h2>
                  <h3 id="img-caption__subtitle" class="img-caption__subtitle">United Kingdom</h3>
                </div>
              </div>
            </a>
          </body>
        </div>
        <div id="tier2-block__2" class="col-xs-12 col-sm-6 colnorightpadding-small-up">
          <body>
            <a id="img-caption__container" href="http://careers.jpmorgan.com/careers/locations/newark" class="img-hover">
              <div id="img-caption__block" class="img-caption img-hover-dim">
                <div class="has-img-hover">
                  <img id="img-caption__image" class="img-caption__image img-responsive lazy" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320682967756/1320541490648.jpg" data-bttrlazyloading-sm-src="http://careers.jpmorgan.com/careers/1320682967755/1320541490647.jpg" alt="Newark, DE" />
                </div>
                <noscript><div class="has-img-hover img-hover-dim"><img id="img-caption__default-img" class="img-caption__image img-responsive" src="http://careers.jpmorgan.com/careers/1320682967756/1320541490648.jpg" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320682967756/1320541490648.jpg" alt="Newark, DE" /></div></noscript>
                <div class="img-caption__content text-shadow">
                  <h2 id="img-caption__title" class="img-caption__title">Newark</h2>
                  <h3 id="img-caption__subtitle" class="img-caption__subtitle">U.S.A.</h3>
                </div>
              </div>
            </a>
          </body>
        </div>
      </div>
    </div>
    <div id="featured-loc-tier1" class="module-spacing-xs-small">
      <a id="img-caption-full__a" href="http://careers.jpmorgan.com/careers/locations/hong-kong" class="img-hover">
        <div id="img-caption-full__container" class="location-highlight img-caption img-caption-full container-highlight">
          <div class="img-hover-dim img-hover-full">
            <div class="has-img-hover">
              <img id="img-caption-full__image" class="img-caption__image img-responsive lazy" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320712702113/1320551706438.jpg" data-bttrlazyloading-sm-src="http://careers.jpmorgan.com/careers/1320712702115/1320551706400.jpg" alt="Hong Kong" />
              <noscript><img id="img-caption-full__default-image" class="img-caption__image img-responsive" src="http://careers.jpmorgan.com/careers/1320712702113/1320551706438.jpg" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320712702113/1320551706438.jpg" alt="Hong Kong" /></noscript>
            </div>
            <div class="img-caption__content">
              <h2 id="img-caption-full__title" class="img-caption__title text-shadow">Hong Kong</h2>
              <h3 id="img-caption-full__subtitle" class="img-caption__subtitle text-shadow">Hong Kong</h3>
              <p id="img-caption-cta" class="img-caption__cta"></p>
            </div>
          </div>
        </div>
      </a>
    </div>
    <div id="tier2-container" class="container img-caption-split">
      <div id="tier2-row" class="row">
        <div id="tier2-block__1" class="col-xs-12 col-sm-6 colnoleftpadding-small-up has-sibling">
          <body>
            <a id="img-caption__container" href="http://careers.jpmorgan.com/careers/locations/singapore" class="img-hover">
              <div id="img-caption__block" class="img-caption img-hover-dim">
                <div class="has-img-hover">
                  <img id="img-caption__image" class="img-caption__image img-responsive lazy" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320683512100/1320541770908.jpg" data-bttrlazyloading-sm-src="http://careers.jpmorgan.com/careers/1320683512099/1320541770907.jpg" alt="Singapore" />
                </div>
                <noscript><div class="has-img-hover img-hover-dim"><img id="img-caption__default-img" class="img-caption__image img-responsive" src="http://careers.jpmorgan.com/careers/1320683512100/1320541770908.jpg" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320683512100/1320541770908.jpg" alt="Singapore" /></div></noscript>
                <div class="img-caption__content text-shadow">
                  <h2 id="img-caption__title" class="img-caption__title">Singapore</h2>
                  <h3 id="img-caption__subtitle" class="img-caption__subtitle">Singapore</h3>
                </div>
              </div>
            </a>
          </body>
        </div>
        <div id="tier2-block__2" class="col-xs-12 col-sm-6 colnorightpadding-small-up">
          <body>
            <a id="img-caption__container" href="http://careers.jpmorgan.com/careers/locations/brooklyn" class="img-hover">
              <div id="img-caption__block" class="img-caption img-hover-dim">
                <div class="has-img-hover">
                  <img id="img-caption__image" class="img-caption__image img-responsive lazy" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320709192084/1320552355667.jpg" data-bttrlazyloading-sm-src="http://careers.jpmorgan.com/careers/1320709192074/1320552355666.jpg" alt="Brooklyn, NY" />
                </div>
                <noscript><div class="has-img-hover img-hover-dim"><img id="img-caption__default-img" class="img-caption__image img-responsive" src="http://careers.jpmorgan.com/careers/1320709192084/1320552355667.jpg" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320709192084/1320552355667.jpg" alt="Brooklyn, NY" /></div></noscript>
                <div class="img-caption__content text-shadow">
                  <h2 id="img-caption__title" class="img-caption__title">Brooklyn</h2>
                  <h3 id="img-caption__subtitle" class="img-caption__subtitle">U.S.A.</h3>
                </div>
              </div>
            </a>
          </body>
        </div>
      </div>
    </div>
  </div>
</div>
