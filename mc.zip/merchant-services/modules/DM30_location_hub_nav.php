  <section data-tabs="" data-dropdown-filters="" data-inline-data="true" class="module asset-grid tabs no-module-padding margin-reset-bottom location_hub_nav" 
  data-ng-init="subMenu = [{
        'id': 'featured',
        'element_id': 'related-locations-container-north-america',
        'title': 'North America',
        'active': 'active'
    }, 
    {
        'id': 'americas',
        'element_id': 'related-locations-container-latin-america',
        'title': 'Latin America'
    }, 
    {
        'id': 'asia-pacific',
        'element_id': 'related-locations-container-asia-pacific',
        'title': 'Asia Pacific'
    }, 
    {
        'id': 'europe-middle-east-africa',
        'element_id': 'related-locations-container-europe-middle-east-africa',
        'title': 'Europe, Middle East and Africa'
    }];">
    <div class="container-fluid tabs-wrapper">
      <div class="row">
        <div class="flex-wrapper col-xs-12 text-xs-left">
          <a href="#" class="visible-xs dropdown-header no-margin-bottom no-padding-bottom">&nbsp;</a>
          <ul class="tabs flex-container">

          <li class="">
            <div class="text-right text-xs-left">
              <ul class="tabs">
                <li class="active">
                  <a id="featured" class="active dropdown-filter-trigger dropdown-close" href="" 
                  data-show-element="featured_locations">Featured Locations</a>
                </li>
              </ul>
            </div>
            <div class="text-center text-xs-left">
              <ul class="tabs">
                <li>
                  <a id="regions" href="" class="dropdown-filter-trigger">
                  <span>Regions</span>
                  <i class="icon-plus-fill"></i>
                  <i class="icon-minus-fill"></i>
                  <i class="icon-plus"></i>
                  <i class="icon-minus"></i>
                  </a>
                    <div style="display: none;"  class="row filter-wrappers filter-triggers custom-dropdown mobile-dropdown">
                      <div class="col-xs-12 text-center text-xs-left">
                        <ul class="tabs dropdown-list">
                          <li ng-repeat="item in subMenu" data-sub-menu="item"></li>
                        </ul>
                      </div>
                    </div>
                </li>
              </ul>
            </div>
            <div class="text-left text-xs-left">
              <ul class="tabs">
                <li>
                  <a id="asia-pacific" class="dropdown-filter-trigger dropdown-close" href="" data-show-element="related-locations-container-tech-hub">Tech Hubs</a>
                </li>
              </ul>
            </div>

          </li>
          </ul>
          <div style="display: none;"  class="hidden-xs-down row filter-wrappers filter-triggers custom-dropdown">
            <div class="col-xs-12 text-center text-xs-left">

              <ul class="tabs dropdown-list">
                <li ng-repeat="item in subMenu" data-sub-menu="item"></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include 'modules/DM30_location_hub_featured_locations_tab.php' ?> 
    <?php include 'modules/DM31-RegionLocationsTab.php' ?>    
    <?php include 'modules/DM32_hub_location_tab.php' ?>    
    
    <div id="" class="grid-contents" data-animation="fadeIn" data-dynamic-html="gridContentHtml"></div>
  </section>
