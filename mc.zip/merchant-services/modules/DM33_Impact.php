  <div id="whyus-impact">
    <div class="container">
      <div class="row">
        <div id="whyus-impact__intro" class="col-xs-12 col-md-8 col-md-push-2"><article class="title-desc">
  <h2 id="intro__title" class="title-desc__title {{extraclass}}">Building and growing vibrant communities</h2>
  
</article></div>
      </div>
    </div>
    <div class="container colnoleftpadding-xs colnorightpadding-xs">
      <div class="row">
        <div class="col-xs-12 padding-reset">
          <div class="mcarousel">
            <div id="whyus-impact-carousel__container" data-carousel="" data-resolution="{{$root.deviceResolution}}" data-carousel-mobile="true" data-carousel-tablet="true" data-carousel-desktop="true" data-navigation="true" class="module no-overflow no-module-padding carousel hover-button text-center why-us-carousel carousel-control-color-red"><div id="whyus-impact__img-container" class="col-xs-12 padding-reset">
                <div class="item">
                  <figure>
                    <img class="lazy img-responsive visible-lg-inline visible-md-inline visible-sm-inline visible-xs-block" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320685561972/1320542679551.jpg" data-bttrlazyloading-sm-src="http://careers.jpmorgan.com/careers/1320685561971/1320542679552.jpg" alt="Global Cities Initiative" />
                  </figure>
                  <h4 id="foot-note" class="has-padding-top text-center">Global Cities Initiative</h4>
                </div>
              </div><div id="whyus-impact__img-container" class="col-xs-12 padding-reset">
                <div class="item">
                  <figure>
                    <img class="lazy img-responsive visible-lg-inline visible-md-inline visible-sm-inline visible-xs-block" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320685557140/1320542679690.jpg" data-bttrlazyloading-sm-src="http://careers.jpmorgan.com/careers/1320685557138/1320542679691.jpg" alt="Tech For Social Good" />
                  </figure>
                  <h4 id="foot-note" class="has-padding-top text-center">Technology for Social Good</h4>
                </div>
              </div><div id="whyus-impact__img-container" class="col-xs-12 padding-reset">
                <div class="item">
                  <figure>
                    <img class="lazy img-responsive visible-lg-inline visible-md-inline visible-sm-inline visible-xs-block" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320685557975/1320542679866.jpg" data-bttrlazyloading-sm-src="http://careers.jpmorgan.com/careers/1320685557957/1320542679867.jpg" alt="JPMorgan Chase &amp; Co. Institute" />
                  </figure>
                  <h4 id="foot-note" class="has-padding-top text-center">JPMorgan Chase Institute</h4>
                </div>
              </div></div>
          </div>
        </div>
      </div>
    </div>
  </div>