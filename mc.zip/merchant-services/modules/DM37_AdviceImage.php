<section class="adviceImage module">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-8 col-sm-offset-2">
          <h2 id="whyus__culture-title" class="text-center">Culture</h2>
		<p class="text-center">We believe in “doing first-class business in a first-class way.” </p>
        </div>
      </div>
    </div>
    <div class="container-highlight colnopadding-small-down module-padding-base-both">
      <div class="row">
        <div class="col-xs-12 padding-reset">
          <img      class="img-responsive lazy" data-bttrlazyloading-xs-src="http://jpmcareers.jpmchase.net/careers/1320542568691/1320542568671.jpg" data-bttrlazyloading-sm-src="http://jpmcareers.jpmchase.net/careers/1320542568693/1320542568669.jpg" alt="" />
          <noscript><img class="img-responsive" data-bttrlazyloading-xs-src="http://jpmcareers.jpmchase.net/careers/1320542568691/1320542568671.jpg" src="http://jpmcareers.jpmchase.net/careers/1320542568691/1320542568671.jpg" alt="" /></noscript>
        </div>
      </div>
    </div>
  </section>