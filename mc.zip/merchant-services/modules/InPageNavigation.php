
	<div id="sidebar"><!-- sidebar is first item in <main> -->
            <div id="nav-anchor"></div>
            <nav class="fixie">
		  	 <div class="points">
			 	<div class="dot"><a href="#home" 	 	class="home" 		data-name="home"	></a></div>
				<div class="dot"><a href="#about" 	 	class="about"		data-name="about"	></a></div>
				<div class="dot"><a href="#services" 	class="services"	data-name="services"></a></div>
				<div class="dot"><a href="#blog" 	 	class="blog"		data-name="blog"	></a></div>
				<div class="dot"><a href="#contact"  	class="contact"		data-name="contact"	></a></div>
			 </div>
                <ul>
                    <li><a href="#home" 		class="home" 		data-name="home"	>Home</a></li>
                    <li><a href="#about" 	      class="about"		data-name="about"	>About</a></li>
                    <li><a href="#services" 	class="services"	      data-name="services">Services to be rendered by the service renderer</a></li>
                    <li><a href="#blog" 		class="blog"		data-name="blog"	>Blog</a></li>
                    <li><a href="#contact" 	class="contact"		data-name="contact"	>Contact</a></li>
                </ul>
            </nav>
      </div>
  	 
