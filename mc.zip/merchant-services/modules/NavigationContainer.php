  <header class="header" id="header">
    <div class="container colnorightpadding-xs colnorightpadding-sm">
      <div class="row">
        <div class="col-xs-8 col-sm-4 colnoleftpadding-small-up">
          <div class="logo">
            <a href="/careers" id="homepage-link" title="JP Morgan"><img alt="JPMorgan" class="logo__image" src="assets/images/jpmorgan-chase-logo-light.svg"></a>
          </div>
        </div>
        <div class="nav-main__container col-xs-4 col-sm-8 colnoleftpadding-small-up colnorightpadding-small-up" id="nav-main__container">
          <nav class="nav-main" id="nav-main">
            <a class="nav-main-action js-toggle-action" href="javascript:;" id="nav-main-action">Menu</a>
            <ul class="js-toggle-content" id="nav-main-content">
              <li class='only-on-small'>
                <a href='/careers/' id='homepage-link' title="Home">Home</a>
              </li>
              <li>
                <a href='/careers/divisions' id='divisions__link' title="Divisions">Divisions</a>
              </li>
              <li>
                <a href='/careers/locations' id='locations__link' title="Locations">Locations</a>
              </li>
              <li>
                <a href='/careers/programs' id='programs__link' title="Programs">Programs</a>
              </li>
              <li>
                <a href='/careers/why-us' id='whyus__link' title="Why Us">Why Us</a>
              </li>
              <li class="dropdown">
                <span class="dropdown__title--sm" id="apply-label-mobile">Apply</span> 
                <a class="dropdown__title" href="javascript:;">
                  <span id="apply-label">Apply</span> 
                  <span class="dropdown__icon--env"><i class="dropdown__icon icon-arrow-down-fill"></i></span>
                </a>
                <ul>
                  <li>
                    <a href="/careers/apply-students" id="apply-student-prog__link" title="Student Programs">Student Programs</a>
                  </li>
                  <li>
                    <a href="/careers/student-events" id="apply-student-events__link" title="Student Events">Student Events</a>
                  </li>
                  <li>
                    <a href="/careers/apply-experienced" id="apply-exp-roles__link" title="Experienced Roles">Experienced Roles</a>
                  </li>
                  <li>
                    <a href="/careers/advice" id="need-addvice__link" title="Need Advice?">Need Advice?</a>
                  </li>
			
			
                </ul>
              </li>
              <li class="navSearch">
		  	<div class="iconContainer">
				<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
		viewBox="0 0 102 102" enable-background="new 0 0 102 102" xml:space="preserve">
					<path fill="#FFFFFF" d="M98.9,87.7L83.3,72.1c4.8-7,7.7-15.4,7.7-24.6C91,23.7,71.7,4.3,47.8,4.3C24,4.3,4.7,23.7,4.7,47.5
					c0,23.8,19.3,43.2,43.2,43.2c9,0,17.4-2.8,24.4-7.5l15.6,15.6c3.1,3.1,8,3.1,11.1,0C102,95.7,102,90.7,98.9,87.7z M18.1,47.5
					c0-16.4,13.3-29.8,29.8-29.8c16.4,0,29.8,13.3,29.8,29.8c0,16.4-13.3,29.8-29.8,29.8C31.4,77.3,18.1,63.9,18.1,47.5z"/>
				</svg>
			</div>

				
				<div class="searchPopover">
					<form class="searchContainer" name="careers_search" action='/search' method=get accept-charset="UTF-8">
						<input id="filters-search" name="q" class="search-input" value="" placeholder="Search" type="text">
						
						<!--<input id="search_form_submit" value="" type="submit" class="search-input" placeholder="Search">-->

						<button id="search_form_submit" value="" type="submit" class="searchicon">
							<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 102 102" enable-background="new 0 0 102 102" xml:space="preserve">
							<path fill="#FFFFFF" d="M98.9,87.7L83.3,72.1c4.8-7,7.7-15.4,7.7-24.6C91,23.7,71.7,4.3,47.8,4.3C24,4.3,4.7,23.7,4.7,47.5 c0,23.8,19.3,43.2,43.2,43.2c9,0,17.4-2.8,24.4-7.5l15.6,15.6c3.1,3.1,8,3.1,11.1,0C102,95.7,102,90.7,98.9,87.7z M18.1,47.5 c0-16.4,13.3-29.8,29.8-29.8c16.4,0,29.8,13.3,29.8,29.8c0,16.4-13.3,29.8-29.8,29.8C31.4,77.3,18.1,63.9,18.1,47.5z"/>
							</svg>
						</button>
						<div class="line"></div>
						<div class="close-button" href="#">
       						<span class="icon-close-small"></span>
     						</div>
					</form>
				</div>
		  </li>
		 
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </header>