<section class="openProgramsModule" id="prog-details-available-programs">
      <available-programs-list id="prog-details-programs" data-url="/assets/ajax/getProgramLocations/1320540447032">
        <section ng-if="$root.deviceResolution === 'desktop'" class="desktop available-programs-list">
              <div class="module bg-white">
          
                <div class="container">
                    <div class="title-holder">
                      <h2 class="title text-center"><span id="apply-for-label">Apply for </span> <span id="hero__title" class="hero__title">Commercial Banking Analyst Program - Full-time</span></h2>
                    </div>
          
                    <div class="tabs-container row">
                      <span id="no-label" class="no-label hide">No</span>
                      <ul class="tabs">
                       <!--  full-width --><li class="tab-graduate" data-ng-click="toggleTab('graduate')" ng-class="isTableEmpty('graduate')">
                            <div class="title" id="apply-student-tab">Apply as a student/graduate</div>
                            <div class="summary"><span class="count all-count" data-ng-bind="graduateProgramsCount"></span><span class="count filtered-count" data-ng-bind="programsFiltered.length"></span> <span class="open-programs-label"> open program</span><span class="plural" data-ng-show="(graduateProgramsCount !== 1)">s</span></div>
                        </li>
                        <!--  hide --><li class="tab-experienced" data-ng-click="toggleTab('experienced')" ng-class="isTableEmpty('experienced')">
                            <div class="title" id="apply-experienced-tab">Apply as an experienced professional</div>
                            <div class="summary"><span class="count all-count wcs-exp-count" data-ng-bind="experiencedProgramsCount"></span><span class="count filtered-count wcs-exp-count" data-ng-bind="programsFiltered.length"></span> <span class="open-programs-label"> open program</span><span class="plural" data-ng-show="(experiencedProgramsCount !== 1)">s</span></div>
                        </li>
                      </ul>
                    </div>
                    <div style="clear:both"></div>
                    <div class="filter-container row" ng-show="regionFilterDisplay">
                      <div class="customized-select">
                        <span class="hide ng-hide wcs-region-filter default-region-filter-label" value="Filter region">Filter region</span>
                        <form><button class="region-filter button wcs-region-filter" value="Filter region"><i class="icon-arrow-down"></i>Filter by region</button>
                        <select class="region-filter select wcs-region-placeholder" placeholder="Filter region" data-ng-model="metaData.region" ng-options="region for region in regions track by region">
                          <option style="display:none" value=""></option>
                        </select>
                        <a href="#" class="reset-region-filter wcs-see-all" data-ng-click="resetRegionFilter()">See all</a>
                      </form></div>
                    </div>
          
                    <div id="programs-feed-message" class="content-container hide" data-ng-show="hasExperiencedCTAMessage()">
                      <div class="table-content programs-feed-message">
                        <div class="col-xs-12">
                          <div class="row rowmargin">
                            <div class="col-xs-12 col-sm-9"><span class="display-block" id="open-programs-not-available__all">To browse all open full-time positions at the firm, and to apply to roles, please click the Apply button.</span></div>
                            <div class="col-xs-12 col-sm-3 apply-now-button">
                              <a id="apply-cta-link" href="" target="_blank" class="btn white wcs-apply-now">Apply</a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
          
                    <div class="content-container" data-ng-show="(graduateProgramsCount &gt; 0 &amp;&amp; metaData.tabSelected === 'graduate') || (experiencedProgramsCount &gt; 0 &amp;&amp; metaData.tabSelected === 'experienced')">
                      <div class="row table-header hidden-xs" data-ng-show="programsFiltered.length &gt; 0">
                        <div class="col-xs-12">
                          <div class="row rowmargin">
                            <div class="col-xs-12 col-md-4"><span class="display-block zeta text-bold wcs-name-header">Name</span></div>
                            <div class="col-xs-12 col-md-2"><span class="display-block zeta text-bold wcs-region-header">Region</span></div>
                            <div class="col-xs-12 col-md-2"><span class="display-block zeta text-bold wcs-location-header">Location</span></div>
                            <div class="col-xs-12 col-md-2"><span class="display-block zeta text-bold wcs-deadline-header">Deadline</span></div>
                          </div>
                        </div>
                      </div>
          
                      <div class="row table-content" data-ng-repeat="prg in programsFiltered = (programs | programsFilter:metaData:'all':'')">
                        <div class="col-xs-12">
                          <div class="row rowmargin">
                            <div class="col-xs-12 col-md-4 name"><span class="display-block" data-ng-bind="prg.name"></span></div>
                            <div class="col-xs-12 col-md-2 region"><span class="display-block" data-ng-bind="prg.region"></span></div>
                            <div class="col-xs-12 col-md-2 locations"><span class="display-block" data-ng-repeat="location in prg.locations"><div data-ng-bind="location"></div></span></div>
                            <div class="col-xs-12 col-md-4" ng-if="hasIndiaAsLocation(prg.locations)" id="open-programs-not-available__india">Check with your pre-placement center for information about applying to this program</div>
                            <div class="col-xs-12 col-md-1 program-date" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <span class="display-block">
                              <div class="date-block">
                                <div class="month" data-ng-bind="formatMonthShort(prg.deadline)"></div>
                                <div class="date" data-ng-bind="formatDateShort(prg.deadline)"></div>
                              </div>
                              <div class="year" data-ng-bind="formatYear(prg.deadline)"></div>
                              </span>
                            </div>
                            <div class="col-xs-12 col-md-3 apply-now-button" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <a data-ng-href="{{applicationUrl(prg)}}" id="program-apply-now" ng-show="prg.hasApplyNowLink" target="_blank" class="btn white wcs-apply-now">Apply</a>
                            </div>
                          </div>
                        </div>
                      </div>
          
                    </div>
          
                    <div class="table-footer-container">
                      <div class="row">
                        <div class="col-xs-12 col-sm-8 col-sm-offset-2 text-center">
                          <p>
                            <small id="open-programs-useful-info">Please note, only locations where this program is currently open will be displayed. If you're not able to find your desired location, please follow us on Facebook or LinkedIn for program application updates. </small>
                          </p>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
          
        </section>
        <section ng-if="$root.deviceResolution === 'tablet' && $root.isLandscape" class="desktop available-programs-list">
              <div class="module bg-white">
          
                <div class="container">
                    <div class="title-holder">
                      <h2 class="title text-center"><span id="apply-for-label">Apply for </span> <span id="hero__title" class="hero__title">Commercial Banking Analyst Program - Full-time</span></h2>
                    </div>
          
                    <div class="tabs-container">
                      <span id="no-label" class="no-label hide">No</span>
                      <ul class="tabs">
                        <li class="tab-graduate full-width" data-ng-click="toggleTab('graduate')" ng-class="isTableEmpty('graduate')">
                            <div class="title" id="apply-student-tab">Apply as a student/graduate</div>
                            <div class="summary"><span class="count all-count" data-ng-bind="graduateProgramsCount"></span><span class="count filtered-count" data-ng-bind="programsFiltered.length"></span> <span class="open-programs-label"> open program</span><span class="plural" data-ng-show="(graduateProgramsCount !== 1)">s</span></div>
                        </li>
                        <li class="tab-experienced hide" data-ng-click="toggleTab('experienced')" ng-class="isTableEmpty('experienced')">
                            <div class="title" id="apply-experienced-tab">Apply as an experienced professional</div>
                            <div class="summary"><span class="count all-count wcs-exp-count" data-ng-bind="experiencedProgramsCount"></span><span class="count filtered-count wcs-exp-count" data-ng-bind="programsFiltered.length"></span> <span class="open-programs-label"> open program</span><span class="plural" data-ng-show="(experiencedProgramsCount !== 1)">s</span></div>
                        </li>
                      </ul>
                    </div>
                    <div style="clear:both"></div>
                    <div class="filter-container" ng-show="regionFilterDisplay">
                      <div class="customized-select">
                        <span class="hide ng-hide wcs-region-filter default-region-filter-label" value="Filter region">Filter region</span>
                        <form><button class="region-filter button wcs-region-filter" value="Filter region"><i class="icon-arrow-down"></i>Filter by region</button>
                        <select class="region-filter select wcs-region-placeholder" placeholder="Filter region" data-ng-model="metaData.region" ng-options="region for region in regions track by region">
                          <option style="display:none" value=""></option>
                        </select>
                        <a href="#" class="reset-region-filter wcs-see-all" data-ng-click="resetRegionFilter()">See all</a>
                      </form></div>
                    </div>
  
                    <div id="programs-feed-message" class="content-container hide" data-ng-show="hasExperiencedCTAMessage()">
                      <div class="table-content programs-feed-message">
                        <div class="col-xs-12">
                          <div class="row rowmargin">
                            <div class="col-xs-12 col-sm-9"><span class="display-block" id="open-programs-not-available__all">To browse all open full-time positions at the firm, and to apply to roles, please click the Apply button.</span></div>
                            <div class="col-xs-12 col-sm-3 apply-now-button">
                              <a id="apply-cta-link" href="" target="_blank" class="btn white wcs-apply-now">Apply</a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
          
                    <div class="content-container" data-ng-show="(graduateProgramsCount &gt; 0 &amp;&amp; metaData.tabSelected === 'graduate') || (experiencedProgramsCount &gt; 0 &amp;&amp; metaData.tabSelected === 'experienced')">
                      <div class="row table-header hidden-xs" data-ng-show="programsFiltered.length &gt; 0">
                        <div class="col-xs-12">
                          <div class="row rowmargin">
                            <div class="col-xs-12 col-md-4"><span class="display-block zeta text-bold wcs-name-header">Name</span></div>
                            <div class="col-xs-12 col-md-2"><span class="display-block zeta text-bold wcs-region-header">Region</span></div>
                            <div class="col-xs-12 col-md-2"><span class="display-block zeta text-bold wcs-location-header">Location</span></div>
                            <div class="col-xs-12 col-md-2"><span class="display-block zeta text-bold wcs-deadline-header">Deadline</span></div>
                          </div>
                        </div>
                      </div>
          
                      <div class="row table-content" data-ng-repeat="prg in programsFiltered = (programs | programsFilter:metaData:'all':'')">
                        <div class="col-xs-12">
                          <div class="row rowmargin">
                            <div class="col-xs-12 col-md-4 name"><span class="display-block" data-ng-bind="prg.name"></span></div>
                            <div class="col-xs-12 col-md-2 region"><span class="display-block" data-ng-bind="prg.region"></span></div>
                            <div class="col-xs-12 col-md-2 locations"><span class="display-block" data-ng-repeat="location in prg.locations"><div data-ng-bind="location"></div></span></div>
                            <div class="col-xs-12 col-md-4" ng-if="hasIndiaAsLocation(prg.locations)" id="open-programs-not-available__india">Check with your pre-placement center for information about applying to this program</div>
                            <div class="col-xs-12 col-md-1 program-date" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <span class="display-block">
                              <div class="date-block">
                                <div class="month" data-ng-bind="formatMonthShort(prg.deadline)"></div>
                                <div class="date" data-ng-bind="formatDateShort(prg.deadline)"></div>
                              </div>
                              <div class="year" data-ng-bind="formatYear(prg.deadline)"></div>
                              </span>
                            </div>
                            <div class="col-xs-12 col-md-3 apply-now-button" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <a data-ng-href="{{applicationUrl(prg)}}" id="program-apply-now" ng-show="prg.hasApplyNowLink" target="_blank" class="btn white wcs-apply-now">Apply</a>
                            </div>
                          </div>
                        </div>
                      </div>
          
                    </div>
          
                    <div class="table-footer-container">
                      <div class="row">
                        <div class="col-xs-12 col-sm-8 col-sm-offset-2 text-center">
                          <p>
                            <small id="open-programs-useful-info">Please note, only locations where this program is currently open will be displayed. If you're not able to find your desired location, please follow us on Facebook or LinkedIn for program application updates. </small>
                          </p>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
          
        </section>
        <section ng-if="$root.deviceResolution === 'tablet' && !$root.isLandscape" class="desktop available-programs-list">
              <div class="module bg-white">
          
                <div class="container">
                    <div class="title-holder">
                      <h2 class="title text-center"><span id="apply-for-label">Apply for </span> <span id="hero__title" class="hero__title">Commercial Banking Analyst Program - Full-time</span></h2>
                    </div>
          
                    <div class="tabs-container ">
                      <span id="no-label" class="no-label hide">No</span>
                      <ul class="tabs">
                        <li class="tab-graduate full-width" data-ng-click="toggleTab('graduate')" ng-class="isTableEmpty()">
                            <div class="title" id="apply-student-tab">Apply as a student/graduate</div>
                            <div class="summary"><span class="count all-count" data-ng-bind="graduateProgramsCount"></span><span class="count filtered-count" data-ng-bind="(programsFiltered1.length + programsFiltered2.length)"></span> <span class="open-programs-label"> open program</span><span class="plural" data-ng-show="(graduateProgramsCount !== 1)">s</span></div>
                        </li>
                        <li class="tab-experienced hide" data-ng-click="toggleTab('experienced')" ng-class="isTableEmpty()">
                            <div class="title" id="apply-experienced-tab">Apply as an experienced professional</div>
                            <div class="summary"><span class="count all-count wcs-exp-count" data-ng-bind="experiencedProgramsCount"></span><span class="count filtered-count wcs-exp-count" data-ng-bind="(programsFiltered1.length + programsFiltered2.length)"></span> <span class="open-programs-label"> open program</span><span class="plural" data-ng-show="(experiencedProgramsCount !== 1)">s</span></div>
                        </li>
                      </ul>
                    </div>
                    <div style="clear:both"></div>
                    <div class="filter-container" ng-show="regionFilterDisplay">
                      <div class="customized-select">
                        <span class="hide ng-hide wcs-region-filter default-region-filter-label" value="Filter region">Filter region</span>
                        <form><button class="region-filter button wcs-region-filter" value="Filter region"><i class="icon-arrow-down"></i>Filter by region</button>
                        <select class="region-filter select wcs-region-placeholder" placeholder="Filter region" data-ng-model="metaData.region" ng-options="region for region in regions track by region">
                          <option style="display:none" value=""></option>
                        </select>
                        <a href="#" class="reset-region-filter wcs-see-all" data-ng-click="resetRegionFilter()">See all</a>
                      </form></div>
                    </div>
          
                    <div id="programs-feed-message" class="content-container hide" data-ng-show="hasExperiencedCTAMessage()">
                      <div class="table-content programs-feed-message">
                        <div class="col-xs-12">
                          <div class="row rowmargin">
                            <div class="col-xs-12 col-sm-9"><span class="display-block" id="open-programs-not-available__all">To browse all open full-time positions at the firm, and to apply to roles, please click the Apply button.</span></div>
                            <div class="col-xs-12 col-sm-3 apply-now-button">
                              <a id="apply-cta-link" href="" target="_blank" class="btn white wcs-apply-now">Apply</a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
          
                    <div class="mobile available-programs-list" data-ng-show="(graduateProgramsCount &gt; 0 &amp;&amp; metaData.tabSelected === 'graduate') || (experiencedProgramsCount &gt; 0 &amp;&amp; metaData.tabSelected === 'experienced')">
                      <div class="content-container row table-content">
                        <div class="content-item col-xs-12 col-sm-6">
                          <div class="rowmargin" data-ng-repeat="prg in programsFiltered1 = (programs | programsFilter:metaData:'even':'')">
                            <div class="content-item-block">
                              <div class="display-block label">Name</div>
                              <div class="display-block value"><span class="display-block" data-ng-bind="prg.name"></span></div>
                            </div>
                            <div class="content-item-block">
                              <div class="display-block label">Region</div>
                              <div class="display-block value"><span class="display-block" data-ng-bind="prg.region"></span></div>
                            </div>
                            <div class="content-item-block">
                              <div class="display-block label">Location</div>
                              <div class="display-block value">
                                <span class="display-block"><div data-ng-bind="prg.locationcsv"></div></span>
                              </div>
                            </div>
                            <div class="content-item-block" ng-if="hasIndiaAsLocation(prg.locations)">
                              <div class="display-block value" id="open-programs-not-available__india">Check with your pre-placement center for information about applying to this program</div>
                            </div>
                            <div class="content-item-block program-date" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <div class="display-block label">Deadline</div>
                              <div class="display-block value"><div class="month" data-ng-bind="formatMonthShort(prg.deadline)"></div> <div class="date" data-ng-bind="formatDateShort(prg.deadline)"></div>, <div class="year" data-ng-bind="formatYear(prg.deadline)"></div></div>
                            </div>
                            <div class="content-item-block apply-now-button" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <div class="display-block apply-now-button">
                              <a data-ng-href="{{applicationUrl(prg)}}" id="program-apply-now" ng-show="prg.hasApplyNowLink" target="_blank" class="btn white wcs-apply-now">Apply</a>
                              </div>
                            </div>
                          </div>
                        </div>
          
                        <div class="content-item col-xs-12 col-sm-6">
                          <div class="rowmargin" data-ng-repeat="prg in programsFiltered2 = (programs | programsFilter:metaData:'odd':'')">
                            <div class="content-item-block">
                              <div class="display-block label">Name</div>
                              <div class="display-block value"><span class="display-block" data-ng-bind="prg.name"></span></div>
                            </div>
                            <div class="content-item-block">
                              <div class="display-block label">Region</div>
                              <div class="display-block value"><span class="display-block" data-ng-bind="prg.region"></span></div>
                            </div>
                            <div class="content-item-block">
                              <div class="display-block label">Location</div>
                              <div class="display-block value">
                                <span class="display-block"><div data-ng-bind="prg.locationcsv"></div></span>
                              </div>
                            </div>
                            <div class="content-item-block" ng-if="hasIndiaAsLocation(prg.locations)">
                              <div class="display-block value" id="open-programs-not-available__india">Check with your pre-placement center for information about applying to this program</div>
                            </div>
                            <div class="content-item-block program-date" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <div class="display-block label">Deadline</div>
                              <div class="display-block value"><div class="month" data-ng-bind="formatMonthShort(prg.deadline)"></div> <div class="date" data-ng-bind="formatDateShort(prg.deadline)"></div>, <div class="year" data-ng-bind="formatYear(prg.deadline)"></div></div>
                            </div>
                            <div class="content-item-block apply-now-button" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <div class="display-block apply-now-button">
                              <a data-ng-href="{{applicationUrl(prg)}}" id="program-apply-now" ng-show="prg.hasApplyNowLink" target="_blank" class="btn white wcs-apply-now">Apply</a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
          
                    </div>
          
                    <div class="table-footer-container">
                      <div class="row">
                        <div class="col-xs-12 col-sm-8 col-sm-offset-2 text-center">
                          <p>
                            <small id="open-programs-useful-info">Please note, only locations where this program is currently open will be displayed. If you're not able to find your desired location, please follow us on Facebook or LinkedIn for program application updates. </small>
                          </p>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
          
        </section>
        <section ng-if="$root.deviceResolution === 'mobile'" class="mobile available-programs-list">
          <div class="title-holder">
            <h2 class="title text-center"><span id="apply-for-label">Apply for </span> <span id="hero__title" class="hero__title">Commercial Banking Analyst Program - Full-time</span></h2>
          </div>
          
          <div class="program-details-accordion">
            <div class="program-details-section section-1 tab-graduate full-width" ng-class="isTableEmpty('graduate')">
              <div class="section-title">
                <span class="label" id="apply-student-tab">Apply as a student/graduate</span>
                <span class="icon" data-ng-click="toggleTab('graduate')"><i class="icon-minus"></i><i class="icon-plus"></i></span>
              </div>
              <div class="section-subtitle">
                <div class="summary">
                  <span class="count filtered-count" data-ng-bind="gProgramsFiltered.length"></span><span class="count all-count" data-ng-bind="graduateProgramsCount"></span><span class="open-programs-label"> open program</span><span class="plural" data-ng-show="(graduateProgramsCount !== 1)">s</span>
                </div>
              </div>
              <div class="filter-container row" data-ng-show="gProgramsFiltered.length &gt; 0">
                  <div class="region-filter-display" ng-show="graduateRegionFilterDisplay">
                    <div class="customized-select">
                      <span class="hide ng-hide wcs-region-filter default-region-filter-label" value="Filter region">Filter region</span>
                      <form><button class="graduate region-filter button wcs-region-filter" value="Filter region"><i class="icon-arrow-down"></i>Filter by region</button>
                      <select class="region-filter select wcs-region-placeholder" placeholder="Filter region" data-ng-model="metaData.gRegion">
                        <option value="" style="display: none;"></option>
                        <option data-ng-repeat="region in regions" data-ng-value="region">{{displayLabel(region, 'str')}}</option>
                      </select>
                      <a href="#" class="reset-region-filter wcs-see-all" data-ng-click="resetRegionFilter()">See all</a>
                    </form></div>
                  </div>
              </div>
              <span id="no-label" class="no-label hide">No</span>
              <div class="section-content-wrapper" data-ng-class="hasFilterClass('graduate')">
                <div class="section-content" data-ng-repeat="prg in gProgramsFiltered = (programs | programsFilter:metaData:'all':'ignore-tab-selected-only-graduate')">
                  <div class="content-container">
                    <div class="divider" data-ng-show="$index &gt;= 1"></div>
                    <div class="content-item program">
                      <div class="row">
                        <div class="col-xs-12">
                          <div class="row rowmargin">
                            <div class="col-xs-12 content-item-block">
                              <div class="display-block label wcs-name-header">Name</div>
                              <div class="display-block value"><span class="display-block" data-ng-bind="prg.name"></span></div>
                            </div>
                            <div class="col-xs-12 content-item-block">
                              <div class="display-block label wcs-region-header">Region</div>
                              <div class="display-block value"><span class="display-block" data-ng-bind="prg.region"></span></div>
                            </div>
                            <div class="col-xs-12 content-item-block">
                              <div class="display-block label wcs-location-header">Location</div>
                              <div class="display-block value">
                                <span class="display-block"><div data-ng-bind="prg.locationcsv"></div></span>
                              </div>
                            </div>
                            <div class="col-xs-12 content-item-block" ng-if="hasIndiaAsLocation(prg.locations)">
                              <div class="display-block value" id="open-programs-not-available__india">Check with your pre-placement center for information about applying to this program</div>
                            </div>
                            <div class="col-xs-12 content-item-block program-date" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <div class="display-block label wcs-deadline-header">Deadline</div>
                              <div class="display-block value"><div class="month" data-ng-bind="formatMonthShort(prg.deadline)"></div> <div class="date" data-ng-bind="formatDateShort(prg.deadline)"></div>, <div class="year" data-ng-bind="formatYear(prg.deadline)"></div></div>
                            </div>
                            <div class="col-xs-12 content-item-block apply-now-button" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <div class="display-block apply-now-button">
                              <a data-ng-href="{{applicationUrl(prg)}}" ng-show="prg.hasApplyNowLink" target="_blank" class="btn white wcs-apply-now">Apply</a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="program-details-section section-2 tab-experienced hide" ng-class="isTableEmpty('experienced')">
              <div class="section-title">
                <span class="label" id="apply-experienced-tab">Apply as an experienced professional</span>
                <span class="icon" data-ng-click="toggleTab('experienced')"><i class="icon-minus"></i><i class="icon-plus"></i></span>
              </div>
              <div class="section-subtitle">
                <div class="summary">
                  <span class="count filtered-count" data-ng-bind="eProgramsFiltered.length"></span><span class="count all-count wcs-exp-count" data-ng-bind="experiencedProgramsCount"></span><span class="open-programs-label"> open program</span><span class="plural" data-ng-show="(experiencedProgramsCount !== 1)">s</span>
                </div>
              </div>
              <div class="filter-container row" data-ng-show="eProgramsFiltered.length &gt; 0">
                  <div class="region-filter-display" ng-show="experiencedRegionFilterDisplay">
                    <div class="customized-select">
                      <form><button class="experienced region-filter button wcs-region-filter" value="Filter region"><i class="icon-arrow-down"></i>Filter by region</button>
                      <select class="region-filter select wcs-region-placeholder" placeholder="Filter region" data-ng-model="metaData.eRegion" ng-options="region for region in regions track by region">
                        <option style="display:none" value=""></option>
                      </select>
                      <a href="#" class="reset-region-filter wcs-see-all" data-ng-click="resetRegionFilter()">See all</a>
                    </form></div>
                  </div>
              </div>
              <div class="section-content-wrapper" data-ng-class="hasFilterClass('experienced')">
                <div id="programs-feed-message" class="content-container" data-ng-show="hasExperiencedCTAMessage()">
                  <div class="table-content programs-feed-message">
                    <div class="col-xs-12">
                      <div class="row rowmargin">
                        <div class="col-xs-12 col-sm-9"><span class="display-block" id="open-programs-not-available__all">To browse all open full-time positions at the firm, and to apply to roles, please click the Apply button.</span></div>
                        <div class="col-xs-12 col-sm-3 apply-now-button">
                          <a data-ng-href="#" target="_blank" class="btn white wcs-apply-now">Apply</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="section-content" data-ng-repeat="prg in eProgramsFiltered = (programs | programsFilter:metaData:'all':'ignore-tab-selected-only-experienced')">
                  <div class="content-container">
                    <div class="divider" data-ng-show="$index &gt;= 1"></div>
                    <div class="content-item program">
                      <div class="row">
                        <div class="col-xs-12">
                          <div class="row rowmargin">
                            <div class="col-xs-12 content-item-block">
                              <div class="display-block label wcs-name-header">Name</div>
                              <div class="display-block value"><span class="display-block" data-ng-bind="prg.name"></span></div>
                            </div>
                            <div class="col-xs-12 content-item-block">
                              <div class="display-block label wcs-region-header">Region</div>
                              <div class="display-block value"><span class="display-block" data-ng-bind="prg.region"></span></div>
                            </div>
                            <div class="col-xs-12 content-item-block">
                              <div class="display-block label wcs-location-header">Location</div>
                              <div class="display-block value">
                                <span class="display-block"><div data-ng-bind="prg.locationcsv"></div></span>
                              </div>
                            </div>
                            <div class="col-xs-12 content-item-block" ng-if="hasIndiaAsLocation(prg.locations)">
                              <div class="display-block value" id="open-programs-not-available__india">Check with your pre-placement center for information about applying to this program</div>
                            </div>
                            <div class="col-xs-12 content-item-block program-date" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <div class="display-block label wcs-deadline-header">Deadline</div>
                              <div class="display-block value"><div class="month" data-ng-bind="formatMonthShort(prg.deadline)"></div> <div class="date" data-ng-bind="formatDateShort(prg.deadline)"></div>, <div class="year" data-ng-bind="formatYear(prg.deadline)"></div></div>
                            </div>
                            <div class="col-xs-12 content-item-block apply-now-button" ng-if="!hasIndiaAsLocation(prg.locations)">
                              <div class="display-block apply-now-button">
                              <a data-ng-href="{{applicationUrl(prg)}}" ng-show="prg.hasApplyNowLink" target="_blank" class="btn white wcs-apply-now">Apply</a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="table-footer-container container">
              <div class="row">
                <div class="col-xs-12 col-sm-8 col-sm-offset-2 text-center">
                  <p>
                    <small id="open-programs-useful-info">Please note, only locations where this program is currently open will be displayed. If you're not able to find your desired location, please follow us on Facebook or LinkedIn for program application updates. </small>
                  </p>
                </div>
              </div>
            </div>
          </div>
          
        </section>
      </available-programs-list>
    </section>
