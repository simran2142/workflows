  <section id="our-office-container" class="module mcarousel no-bottom-module-padding no-bottom-module-margin">
    <div class="container">
      <div id="" class="row">
        <div class="col-xs-12 col-md-8 col-md-push-2">
          <div id="our-offices-intro"><article class="title-desc margin-bottom-md">
  <h2 id="intro__title" class="title-desc__title {{extraclass}}">Our offices</h2>
  <p id="intro__desc" class="title-desc__desc delta header-font-family">We’re honored to be a premier financial institution in the U.K. But we’re just as proud of our ties to the community. The teams across our multiple offices support the Social Mobility Foundation, which helps disadvantaged youth get into top universities and organizations.</p>
</article></div>
        </div>
      </div>
    </div>

    <div id="office-img-carousel-container" data-carousel="" data-resolution="{{$root.deviceResolution}}" data-carousel-mobile="true" data-carousel-tablet="true" data-carousel-desktop="true" data-navigation="true" class="row module carousel no-module-padding no-bottom-module-margin margin-top-md office-location-carousel"></div>

    <section id="our-office-getting-around-container" class="module asset-grid no-module-padding no-module-margin"></section>
  <div id="office-img-carousel-container" data-carousel="" data-resolution="{{$root.deviceResolution}}" data-carousel-mobile="true" data-carousel-tablet="true" data-carousel-desktop="true" data-navigation="true" class="row module carousel no-module-padding no-bottom-module-margin margin-top-md office-location-carousel">
      <div id="office-hero-figure-1" class="col-xs-12 colnoleftpadding-xs colnorightpadding-xs">
        <div class="item location-carousel">
          <figure id="office-hero-figure-1">
            <img id="office-hero-img-1" class="lazy img-responsive visible-lg-inline visible-md-inline visible-sm-inline visible-xs-block" data-bttrlazyloading-xs-src="http://jpmcareers.jpmchase.net/careers/1320541894520/1320541894500.jpg" data-bttrlazyloading-sm-src="http://jpmcareers.jpmchase.net/careers/1320541894522/1320541894498.jpg" alt="London office" />
          </figure>
        </div>
      </div>
      
      
    </div><section id="our-office-getting-around-container" class="module asset-grid no-module-padding no-module-margin">
      <div class="container colnoleftpadding-xs colnorightpadding-xs">
        <div class="row">
          <div class="col-xs-12 col-sm-6 colnopadding">
            <div class="item blockquote bg-white">
              <blockquote id="blockquote-text">London is all about the food and the music. It is one of the culinary capitals of the world, and you don't have to break the bank to have a nice meal. There’s also a great music scene – whatever genre you like, you'll find something!<footer id="footer-text">James, Investor Services</footer></blockquote>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 colnopadding">
            <div class="item ico-info bg-darkblue text-center">
              <img id="getting-around-info__image" class="getting-around-info__image img-responsive img-circle center-block" src="http://jpmcareers.jpmchase.net/careers/1320541586940/1320541586920.jpg" alt="Getting around" />
              <h4 id="getting-around-info__title" class="margin-top-sm">Over 300 languages are spoken in London</h4>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 colnopadding text-center">
            <div id="map__co-ordinates" data-map="" class="maps h440" data-locations="[{&quot;lat&quot;:&quot;&quot;,&quot;lng&quot;:&quot;&quot;,&quot;address&quot;:&quot;60 Victoria Embankment, London, EC4Y 0JP&quot;},{&quot;lat&quot;:&quot;&quot;,&quot;lng&quot;:&quot;&quot;,&quot;address&quot;:&quot;1 Knightsbridge, Belgravia, London SW1X&quot;},{&quot;lat&quot;:&quot;&quot;,&quot;lng&quot;:&quot;&quot;,&quot;address&quot;:&quot;25 Bank Street, London, E14 5JP&quot;}]">
            </div>
          </div>
        </div>
      </div>
    </section></section>
