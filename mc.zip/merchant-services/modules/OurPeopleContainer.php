 <!-- BEGIN PEOPLE SLIDER -->   
<section id="division-detail-our-people" class="ourPeopleModule module featured" >
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<h2 id="our-people__title" class="beta module-title text-center">Our People</h2>
			</div>
		</div>
	</div>
	<div class="container">
		<!-- BEGIN DESKTOP PEOPLE SLIDER -->
		<div ng-if="$root.deviceResolution !== 'mobile'" class="ourPeople desktop row row-centered margin-top-md module carousel no-top-module-padding no-bottom-module-margin no-top-module-margin no-bottom-module-padding ng-isolate-scope" 
			data-carousel="" 
			data-resolution="{{$root.deviceResolution}}" 
			data-carousel-mobile="false" 
			data-carousel-tablet="true" 
			data-carousel-desktop="true" 
			data-carousel-control-color="red"
			data-navigation="true" >
			
			
			
			<!-- inside .ourPeople.desktop the 'people' markup will be grouped into groups of three using these <seperator> tags -->
			<seperator> <!-- first group of three -->
			
			
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="0" href="#Jacob" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Jacob</h4>
						<p class="our-people-emp small">Analyst - VP</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320683652639/1320541915594.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Lorem ipsum dolor sit amet, at est iudico audiam eleifend. Vis inermis mandamus id. Vis amet labores ut. Essent urbanitas ne vis. Eam ad dignissim disputationi, sit nusquam efficiendi cu.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-play"></i>Watch Video</p>
					</a>
				</div>
			</div>
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="1" href="#Ryland" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Ryland</h4>
						<p class="our-people-emp small">Marketing - Associate</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320712706320/1320551442964.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Dicit aliquip oblique vis id, autem errem nominati per ex. Cu his nonumes alienum percipitur, usu epicuri noluisse disputationi ex, lorem deterruisset in ius. Ex eos dico intellegebat, usu tibique adversarium reprehendunt ad, ei cum everti adipiscing. Odio paulo facilisi eam id.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-read"></i>Read More</p>
					</a>
				</div>
			</div>
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="2" href="#Chad" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Chad</h4>
						<p class="our-people-emp small">Analyst - Managing Director</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320712706304/1320552072938.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Eam ad dignissim disputationi, sit nusquam efficiendi cu. No usu corpora copiosae, tota aeque choro ad quo. Te propriae percipitur efficiendi sed. Vis ne soleat veritus albucius. His id quod amet torquatos. Ea mea esse simul electram.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-play"></i>Watch Video</p>
					</a>
				</div>
			</div>
			
			
			
			
			
			</seperator><!-- END first group of three -->
			<seperator> <!-- last group of three (or less) -->
			
			
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="3" href="#Jacob" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Jacob</h4>
						<p class="our-people-emp small">Analyst - VP</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320683652639/1320541915594.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Lorem ipsum dolor sit amet, at est iudico audiam eleifend. Vis inermis mandamus id. Vis amet labores ut. Essent urbanitas ne vis. Eam ad dignissim disputationi, sit nusquam efficiendi cu.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-play"></i>Watch Video</p>
					</a>
				</div>
			</div>
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="4" href="#Ryland" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Ryland</h4>
						<p class="our-people-emp small">Marketing - Associate</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320712706320/1320551442964.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Dicit aliquip oblique vis id, autem errem nominati per ex. Cu his nonumes alienum percipitur, usu epicuri noluisse disputationi ex, lorem deterruisset in ius. Ex eos dico intellegebat, usu tibique adversarium reprehendunt ad, ei cum everti adipiscing. Odio paulo facilisi eam id.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-read"></i>Read More</p>
					</a>
				</div>
			</div>
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="5" href="#Chad" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Chad</h4>
						<p class="our-people-emp small">Analyst - Managing Director</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320712706304/1320552072938.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Eam ad dignissim disputationi, sit nusquam efficiendi cu. No usu corpora copiosae, tota aeque choro ad quo. Te propriae percipitur efficiendi sed. Vis ne soleat veritus albucius. His id quod amet torquatos. Ea mea esse simul electram.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-play"></i>Watch Video</p>
					</a>
				</div>
			</div>
			
			
			
			</seperator><!-- END first group of three -->
			
			
			
			
		</div><!-- END DESKTOP PEOPLE SLIDER -->
		
		
		
		
		
		
		<!-- BEGIN MOBILE PEOPLE SLIDER -->
		<div ng-if="$root.deviceResolution == 'mobile'" class="ourPeople mobile row row-centered margin-top-md module carousel no-top-module-padding no-bottom-module-margin no-top-module-margin no-bottom-module-padding ng-isolate-scope" 
			data-carousel="" 
			data-resolution="{{$root.deviceResolution}}" 
			data-carousel-mobile="true" 
			data-carousel-tablet="true" 
			data-carousel-desktop="false" 
			data-carousel-control-color="red">
			
			
			
			
			<!-- inside .ourPeople.mobile there are no <seperator> tags -- that is the only difference, otherwise it is identical to .ourPeople.desktop above -->
			
			
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="0" href="#Jacob" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Jacob</h4>
						<p class="our-people-emp small">Analyst - VP</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320683652639/1320541915594.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Lorem ipsum dolor sit amet, at est iudico audiam eleifend. Vis inermis mandamus id. Vis amet labores ut. Essent urbanitas ne vis. Eam ad dignissim disputationi, sit nusquam efficiendi cu.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-play"></i>Watch Video</p>
					</a>
				</div>
			</div>
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="1" href="#Ryland" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Ryland</h4>
						<p class="our-people-emp small">Marketing - Associate</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320712706320/1320551442964.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Dicit aliquip oblique vis id, autem errem nominati per ex. Cu his nonumes alienum percipitur, usu epicuri noluisse disputationi ex, lorem deterruisset in ius. Ex eos dico intellegebat, usu tibique adversarium reprehendunt ad, ei cum everti adipiscing. Odio paulo facilisi eam id.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-read"></i>Read More</p>
					</a>
				</div>
			</div>
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="2" href="#Chad" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Chad</h4>
						<p class="our-people-emp small">Analyst - Managing Director</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320712706304/1320552072938.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Eam ad dignissim disputationi, sit nusquam efficiendi cu. No usu corpora copiosae, tota aeque choro ad quo. Te propriae percipitur efficiendi sed. Vis ne soleat veritus albucius. His id quod amet torquatos. Ea mea esse simul electram.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-play"></i>Watch Video</p>
					</a>
				</div>
			</div>
			
			
			
			
			
			
			
			
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="3" href="#Jacob" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Jacob</h4>
						<p class="our-people-emp small">Analyst - VP</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320683652639/1320541915594.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Lorem ipsum dolor sit amet, at est iudico audiam eleifend. Vis inermis mandamus id. Vis amet labores ut. Essent urbanitas ne vis. Eam ad dignissim disputationi, sit nusquam efficiendi cu.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-play"></i>Watch Video</p>
					</a>
				</div>
			</div>
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="4" href="#Ryland" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Ryland</h4>
						<p class="our-people-emp small">Marketing - Associate</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320712706320/1320551442964.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Dicit aliquip oblique vis id, autem errem nominati per ex. Cu his nonumes alienum percipitur, usu epicuri noluisse disputationi ex, lorem deterruisset in ius. Ex eos dico intellegebat, usu tibique adversarium reprehendunt ad, ei cum everti adipiscing. Odio paulo facilisi eam id.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-read"></i>Read More</p>
					</a>
				</div>
			</div>
			
			
			<div class="employeeProfile col-xs-12 col-sm-4 col-centered">
				<div class="item"> 
					<a data-push-down-trigger="" data-content-elem="#division-detail-our-people" data-carousel-go-to-slide="5" href="#Chad" class="link-wrapper img-hover-rounded ng-isolate-scope" data-url="assets/ajax/OurPeopleOverlayModule/1320540846694">
						<h4 class="our-people-emp-header delta header-font-family">Chad</h4>
						<p class="our-people-emp small">Analyst - Managing Director</p>
						<figure class="has-img-hover img-hover-dim"> 
							<img class="img-responsive img-profile center-block" src="http://careers.jpmorgan.com/careers/1320712706304/1320552072938.jpg" alt="Commercial Banking Full-time Analyst"> 
						</figure>
						<p class="our-people-emp-quote small margin-top-sm">Eam ad dignissim disputationi, sit nusquam efficiendi cu. No usu corpora copiosae, tota aeque choro ad quo. Te propriae percipitur efficiendi sed. Vis ne soleat veritus albucius. His id quod amet torquatos. Ea mea esse simul electram.</p>
						<p class="our-people-emp-quote btn"><i class="icon-people-play"></i>Watch Video</p>
					</a>
				</div>
			</div>
			
			
			
			
			
			
			
			
		</div><!-- END MOBILE PEOPLE SLIDER -->
		
		
		<div class="push-down-wrapper" data-dynamic-html="$root.pushDownWrapperContent"></div>
	</div>
	
	
	
</section> 

 	
