    <div id="hero" class="program-details hero hero__light">
      <div class="container">
        <div class="row">
          <div class="col-xs-12">
            <div class="hero__content">
              <p id="hero__label" class="hero__label">Full-Time</p>
              <h1 id="hero__title" class="hero__title">Commercial Banking Analyst Program - Full-time</h1>
              
              <span id="hero__cta__closed" class="btn black hero__cta closed-program">Applications currently closed</span>
              <a id="hero__cta__open" href="#prog-details-available-programs" class="btn red hero__cta open-program">Check open programs</a>
            </div>
          </div>
        </div>
      </div>
      <div id="hero__image">
        <style>@media only screen and (max-width: 768px) { .hero { background-image: url('http://careers.jpmorgan.com/careers/1320683934133/1320541938503.jpg'); } }@media only screen and (min-width: 769px) { .hero { background-image: url('http://careers.jpmorgan.com/careers/1320683934152/1320541938501.jpg'); } }</style>
      </div>
    </div>
