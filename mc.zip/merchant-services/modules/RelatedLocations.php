<section id="related-locations-container"><div class="module featured">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 text-center">
        <h2 id="other-locations" class="beta module-title">Where we work</h2>
      </div>
    </div>

    <div id="featured-location-section" class="row row-centered"><div id="featured-location" class="col-xs-12 col-sm-3 col-centered">
        <div class="item location-img-rounded-small">
          <a href="http://jpmcareers.jpmchase.net/careers/locations/london" class="link-wrapper img-hover-rounded">
            <figure class="module-spacing-small small-fig img-circle has-img-hover img-circle img-hover-dim">
              <img id="featued-loc-img" class="img-responsive img-circle center-block" src="http://jpmcareers.jpmchase.net/careers/1320541447268/1320541447248.jpg" alt="London" />
            </figure>
            <p id="featured-loc__title" class="epsilon featured-loc__title">London</p>
          </a>
        </div>
      </div><div id="featured-location" class="col-xs-12 col-sm-3 col-centered">
      <div class="item location-img-rounded-small">
          <a href="http://jpmcareers.jpmchase.net/careers/locations/bournemouth" class="link-wrapper img-hover-rounded">
            <figure class="module-spacing-small small-fig img-circle has-img-hover img-circle img-hover-dim">
              <img id="featued-loc-img" class="img-responsive img-circle center-block" src="http://jpmcareers.jpmchase.net/careers/1320541443164/1320541443144.jpg" alt="Map of Bournemouth" />
            </figure>
            <p id="featured-loc__title" class="epsilon featured-loc__title">Bournemouth</p>
          </a>
        </div>
      </div><div id="featured-location" class="col-xs-12 col-sm-3 col-centered">
        <div class="item location-img-rounded-small">
          <a href="http://jpmcareers.jpmchase.net/careers/locations/paris" class="link-wrapper img-hover-rounded">
            <figure class="module-spacing-small small-fig img-circle has-img-hover img-circle img-hover-dim">
              <img id="featued-loc-img" class="img-responsive img-circle center-block" src="http://jpmcareers.jpmchase.net/careers/1320541447853/1320541447833.jpg" alt="Paris" />
            </figure>
            <p id="featured-loc__title" class="epsilon featured-loc__title">New York</p>
          </a>
        </div>
      </div><div id="all-locations" class="col-xs-12 col-sm-3 col-centered">
        <div class="item location-img-rounded-small">
          <a href="http://jpmcareers.jpmchase.net/careers/locations" class="link-wrapper">
            <figure class="module-spacing-small small-fig">
              <img id="featued-loc-img" class="img-responsive img-circle center-block" src="http://jpmcareers.jpmchase.net/careers/1320542816130/1320542816109.jpg" alt="All locations" />
            </figure>
            <p id="featured-loc__title" class="epsilon featured-loc__title">All locations</p>
          </a>
        </div>
      </div></div>
  </div>
</div>
</section>