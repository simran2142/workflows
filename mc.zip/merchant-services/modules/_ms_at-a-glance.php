<div class="at-a-glance">
		
	<div class="col-xs-12 col-md-4 module-bucket">
		<h3 class="moduleTitle">Look at this Module</h3>
		<p class="moduleCopy">And then read the copy</p>
	</div>

</div><!-- /.module-container -->



