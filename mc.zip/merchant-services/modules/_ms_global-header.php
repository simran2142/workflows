    
    <a class="accessible-text" href="#main" id="skipToMainContent">Skip to main content</a>
    <!--googleoff: index-->
    <div class="browserupdate">
      <div class="browser-message container-fluid">
        <div class="feature-container">
          <div class="browser-message__inner">
            <div class="browser-message__inner-container">
              <img alt="Alert Message Icon" class="browser-message__icon" src="/images/ie_alert.png">
              <div class="browser-message__title">
                <p>Please upgrade your browser.</p>
              </div>
              <div class="browser-message__desc">
                <p>Your browser is out of date. For a faster and more secure online experience upgrade your browser to the most recent version. <a class="chaseanalytics-track-link" data-pt-name="fm_browser-msg" href="https://www.chase.com/services/browser-update.html">Click here for a list of recommended browsers</a>.&nbsp;</p>
              </div><a class="browser-message__dismiss-btn" href="#"><span class="icon-close"></span></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--googleon: index-->
    
    
    <!--googleoff: index-->
    <div class="site-message container-fluid">
      <span class="accessible-text">Begin Site Message Content</span>
      <div class="feature-container">
        <div class="site-message__inner">+
          <div class="site-message__inner-container">
            <img alt="Alert Message Icon" class="site-message__icon" src="/images/high-alert-icon.png">
            <div class="site-message__title"></div>
            <div class="site-message__desc"></div>
          </div>
        </div>
      </div><span class="accessible-text">End Site Message Content</span>
    </div>
    <!--googleon: index-->










    <!--  ========  -->
    <!--  LEFT NAV  -->
    <!--  ========  -->
	<div class="side-menu">
      <nav class="sidemenu closed" role="navigation" style="">
        <h1 class="accessible-text">Navigation</h1><a class="accessible-text" href="#skip-sidemenu">Skip Side Menu</a>
        <div class="sidemenu__menu">
          <div class="sidemenu__menu__search">
            <div class="sidemenu__menu__search__inner">
              <form action="https://www.chase.com/resources/search/search-results.html" class="sidemenu__menu__search__form" method="get" role="search">
                <input class="sidemenu__menu__search__term" name="q" placeholder="Search" type="text"> <input name="site" type="hidden" value="cfsAll"> <button class="sidemenu__menu__search__submit icon-search chaseanalytics-track-link" data-pt-name="sm_search" type="submit" value="Search"><span class="accessible-text">Submit To Search</span></button>
              </form>
              <div class="sidemenu__menu__search__close icon-close">
                <span class="accessible-text">Clear Search Term</span>
              </div>
            </div>
            <div class="sidemenu__menu__close">
              <a class="icon-close" href="#"><span class="accessible-text">Close Side Menu</span></a>
            </div>
          </div>
          <div class="sidemenu__menu__section">
            <div class="sidemenu__menu__section--primary">
              <ul class="sidemenu__menu__section--primary--links">
                <li class="sidemenu__menu__section--primary--link category-home">
                  <a class="chaseanalytics-track-link" data-pt-name='sm_chase.com' href='https://www.chase.com/' target='_blank'>
                  <p class="sidemenu__menu__section--primary--link__title">Chase.com</p></a>
                </li>
                <li class="sidemenu__menu__section--primary--link category-home">
                  <a class="chaseanalytics-track-link" data-pt-name='sm_news &amp; stories' href='https://www.chase.com/news' target='_blank'>
                  <p class="sidemenu__menu__section--primary--link__title">News &amp; Stories</p></a>
                </li>
              </ul>
            </div>
          </div>
          <div class="sidemenu__menu__section">
            <div class="sidemenu__menu__section--title__container">
              <p class="sidemenu__menu__section--title">CONNECT WITH CHASE</p>
            </div>
            <div class="sidemenu__menu__section--primary">
              <ul class="sidemenu__menu__section--primary--links">
                <li class="sidemenu__menu__section--primary--link category-home">
                  <a class="chaseanalytics-track-link" data-pt-name='sm_contact us' href='https://www.chase.com/resources/customer-service' target='_blank'>
                  <p class="sidemenu__menu__section--primary--link__title">Contact Us</p></a>
                </li>
              </ul>
            </div>
          </div>
          <div class="sidemenu__menu__footer">
            <ul class="sidemenu__menu__footer__links">
              <li class="sidemenu__menu__footer__link">
                <a class="chaseanalytics-track-link" data-pt-name='sm_about chase' href='https://www.chase.com/digital/resources/about-chase' target='_blank'>About Chase</a>
              </li>
              <li class="sidemenu__menu__footer__link">
                <a class="chaseanalytics-track-link" data-pt-name='sm_j.p. morgan' href='https://www.jpmorgan.com/pages/jpmorgan' target='_blank'>J.P. Morgan</a>
              </li>
              <li class="sidemenu__menu__footer__link">
                <a class="chaseanalytics-track-link" data-pt-name='sm_jpmorgan chase &amp; co.' href='http://www.jpmorganchase.com/' target='_blank'>JPMorgan Chase &amp; Co.</a>
              </li>
              <li class="sidemenu__menu__footer__link">
                <a class="chaseanalytics-track-link" data-pt-name='sm_careers' href='https://www.careersatchase.com/' target='_blank'>Careers</a>
              </li>
              <li class="sidemenu__menu__footer__link">
                <a class="chaseanalytics-track-link" data-pt-name='sm_chase canada' href='https://www.chase.com/online/canada/canada-home-en.htm' target='_blank'>Chase Canada</a>
              </li>
              <li class="sidemenu__menu__footer__link">
                <a class="chaseanalytics-track-link" data-pt-name='sm_clear and simple' href='https://www.chase.com/online/services/understand-products-avoid-fees.htm' target='_blank'>Clear and Simple</a>
              </li>
              <li class="sidemenu__menu__footer__link">
                <a class="chaseanalytics-track-link" data-pt-name='sm_safe act: chase mortgage loan originators' href='https://www.chase.com/mortgage/loan-originator-search' target='_blank'>SAFE Act: Chase Mortgage Loan Originators</a>
              </li>
              <li class="sidemenu__menu__footer__link">
                <a class="chaseanalytics-track-link" data-pt-name='sm_home mortgage disclosure act (hmda)' href='https://www.chase.com/mortgage/hmda' target='_blank'>Home Mortgage Disclosure Act (HMDA)</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>












<!--  HEADER  -->
	<div class="header">
      <header class="header header-version-b container-fluid black-linear black" data-feature="header" data-header-transition-override="" data-type="b" role="banner">
        <h1 class="accessible-text">Chase offers a broad range of financial services including personal banking, small business lending, mortgages, credit cards, auto financing and investment advice.</h1><!--<div class="header__black-linear-bg hide"></div>-->
        <div class="header__black-bg"></div>
        <div class="header__blue-bg hide"></div>
        <div class="header__inner row">
          <div class="header__section header__section--left col-xs-1 col-sm-1">
            <a class="header__section__item header__section--sidemenu icon-menu chaseanalytics-track-link" data-pt-name="hd_hamburger" href="#" id="skip-sidemenu"><span class="accessible-text">Show the Side Menu</span></a> <!-- dropdown removed from here -->
          </div>
          <div class="header__section header__section--center col-xs-10 col-sm-10">
            <a class="header__section--center--link chaseanalytics-track-link" data-pt-name="hd_logo" href="/home"><span class="chase-text"></span>
            <div class="chase-link-fix"></div><span class="chase-logo-icon"><span style="font-size:0.68em;">&nbsp;&nbsp;for&nbsp;</span></span><span class="accessible-text">Chase Merchant Services Home Page</span></a>
          </div>
          <div class="header__section header__section--right col-xs-1 col-sm-1">
            <!-- sign in removed from here -->
             <a class="header__section__item header__section--search icon-search" href="#"><span class="accessible-text">Show Search</span></a>
          </div>
        </div><!-- search bar -->
        <div class="header__section--search__bar row">
          <div class="header__section--search__bar__inner">
            <div class="header__section--search__bar__container">
              <form accept-charset="UTF-8" action='/search' class="header__section--search__bar__form col-xs-12" id="media_center_search" method="get" name="media_center_search">
                <input class="header__section--search__bar--search-input" name="q" placeholder="Search Chase Merchant Services" type="text" value=""> <button class="header__section--search__bar--search-icon icon-search" data-pt-name="hd_search" type="submit" value="Search"><span class="accessible-text">Submit to Search Chase Merchant Services</span></button>
                <div class="header__section--search__bar--search-close-icon icon-close">
                  <span class="accessible-text">Clear Search</span>
                </div>
              </form>
            </div>
          </div>
        </div><!-- / search bar -->
        <!-- subheader -->
       <!-- <div class="sub-header__nav-wrapper fade-background" id="SubHeaderDuplicate row" style="display: block;">
          <div class="sub-header_max-container">
            <div class="sub-header__nav--item col col-lg-2 col-md-2 col-sm-2 hidden-sm"></div>
            <div class='col col-lg-8 col-md-8 col-sm-8'>
              <div class="sub-header__nav--item col navItem">
                <a class="chaseanalytics-track-link chaseanalytics-track-link" data-pt-name="1" href="/content/news">Press Announcements</a>
              </div>
              <div class="sub-header__nav--item col navItem">
                <a class="chaseanalytics-track-link chaseanalytics-track-link" data-pt-name="2" href="/content/leadership">Leadership</a>
              </div>
              <div class="sub-header__nav--item col navItem">
                <a class="chaseanalytics-track-link chaseanalytics-track-link" data-pt-name="3" href="/content/media-assets">Media Assets</a>
              </div>
              <div class="sub-header__nav--item col navItem">
                <a class="chaseanalytics-track-link chaseanalytics-track-link" data-pt-name="4" href="/content/media-contacts">Media Contacts</a>
              </div>
            </div>
          </div>
        </div>-->
	  <!-- / subheader -->
      </header>
    </div>