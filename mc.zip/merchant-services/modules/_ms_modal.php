<!--googleoff: index-->

<div class="fade modal" id="modal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <span class="icon-close close" data-dismiss="modal"></span>
        </div>
        <div class="modal-body">
          <!--  js appended content  -->
        </div>
        <div class="modal-footer">
          <!--  js appended content  -->
        </div>
      </div><!-- .modal-content -->
    </div><!-- .modal-dialog -->
  </div><!-- #modal -->
  
 <!--googleon: index-->