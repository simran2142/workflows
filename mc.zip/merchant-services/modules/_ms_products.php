<h1 class="pageTitle">Press Announcements</h1>
      <div class="index-control">
        <div class="controls row" style="position:relative">
          <form id="Filters" name="Filters">
            <div class="desktopContain">
              <div class="left">
                <div class="controlFloat">
                  <fieldset>
                    <div class="left">
                      <label>Filter&nbsp;By:</label>
                    </div>
                    <div class="right custom-dropdown custom-dropdown--white">
                      <select class="custom-dropdown__select custom-dropdown__select--white" data-category-filter="true">
                        <option class='filt' value=''>
                          All Categories
                        </option>
                        <option class='filt' value='Business_Banking'>
                          Business Banking
                        </option>
                        <option class='filt' value='Consumer_Banking'>
                          Consumer Banking
                        </option>
                        <option class='filt' value='Lending'>
                          Lending
                        </option>
                        <option class='filt' value='Payments and_Cards'>
                          Payments & Cards
                        </option>
                      </select>
                    </div>
                  </fieldset>
                </div>
              </div>
              <div class="mobileShim"></div>
              <div class="right">
                <div class="controlFloat dateContainer">
                  <div class="input-daterange input-group" id="datepicker">
                    <div class="posFix">
                      <div class="form-control-container start">
                        <input class="news input-sm form-control startDate filt" name="start" placeholder="Date From" type="text">
                      </div>
                    </div><span class="input-group-addon">to</span>
                    <div class="posFix">
                      <div class="form-control-container end">
                        <input class="news input-sm form-control endDate filt" name="end" placeholder="Date To" type="text">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="controlFloat buttonContainer">
                  <button id="filterAll"></button> <button id="Reset"></button>
                  <div class="closeOptions"></div>
                </div>
              </div>
            </div>
            <div class="gridList">
              <div class="inactive" id="listView">
                <svg version="1.1" viewbox="0 0 50 47.5" x="0px" xmlns="http://www.w3.org/2000/svg" y="0px">
                <g id="listView">
                  <g class="icon">
                    <rect height="3.6" width="40.8" x="2.5" y="40.1"></rect>
                    <rect height="3.6" width="40.8" x="2.5" y="15.7"></rect>
                    <rect height="3.6" width="40.8" x="2.5" y="27.9"></rect>
                    <rect height="3.6" width="40.8" x="2.5" y="3.5"></rect>
                  </g>
                  <rect class="clickArea" height="46.3" width="48.1" x="0" y="0.6"></rect>
                </g></svg>
              </div><!-- #listView -->
              <div class="active" id="gridView">
                <svg version="1.1" viewbox="0 0 50 47.5" x="0px" xmlns="http://www.w3.org/2000/svg" y="0px">
                <g class="icon">
                  <rect height="17.9" width="17.9" x="3.8" y="3.5"></rect>
                  <rect height="17.9" width="17.9" x="26.5" y="3.5"></rect>
                  <rect height="17.9" width="17.9" x="3.8" y="25.8"></rect>
                  <rect height="17.9" width="17.9" x="26.5" y="25.8"></rect>
                </g>
                <rect class="clickArea" height="46.3" width="48.1" x="0.6" y="0.6"></rect></svg>
              </div><!-- #gridView -->
            </div><!-- .gridList -->
          </form>
        </div><!-- .controls -->
      </div><!-- .index-control -->
      <div class="index-container">
        <div class="mixItems" id="mixContainer">
          <div class='mix gridView Consumer_Banking' data-date='20161103' data-myorder='2016'>
            <a href='/content/pr/walmart-to-accept-chase-pay'><img alt='Walmart to Accept Chase Pay' src='/image/jpeg/1320715670629.jpg'>
            <p class="newsHead">Walmart to Accept Chase Pay</p>
            <p class="date">November 3, 2016</p>
            <p class="abstract">Chase announced today that Walmart (NYSE: WMT) will accept Chase Pay<sup>&reg;</sup> on Walmart.com, within the Walmart mobile application and in its stores through the Walmart Pay app.</p></a>
          </div>
          <div class='mix gridView Business_Banking' data-date='20161027' data-myorder='2016'>
            <a href='/content/pr/chase-earns-four-peat-from-jd-power'><img alt='Chase Earns Four-Peat from J.D. Power for Small Business Banking in the West' src='/image/jpeg/1320715120861.jpg'>
            <p class="newsHead">Chase Earns Four-Peat from J.D. Power for Small Business Banking in the West</p>
            <p class="date">October 27, 2016</p>
            <p class="abstract">Chase ranked highest in customer satisfaction among small business owners in the South and West regions, according to the 2016 J.D. Power study released today.</p></a>
          </div>
          <div class='mix gridView Consumer_Banking' data-date='20161019' data-myorder='2016'>
            <a href='/content/pr/wakefern-to-accept-chase-pay'><img alt='Wakefern to Accept Chase Pay' src='/image/jpeg/1320714403937.jpg'>
            <p class="newsHead">Wakefern to Accept Chase Pay</p>
            <p class="date">October 19, 2016</p>
            <p class="abstract">Chase announced today that Wakefern Food Corp. will accept Chase Pay<sup>&reg;</sup> as another way for customers to pay for groceries at ShopRite and The Fresh Grocer stores &#8211; supermarkets that are part of the Wakefern cooperative.</p></a>
          </div>
          <div class='mix gridView Consumer_Banking' data-date='20161017' data-myorder='2016'>
            <a href='/content/pr/boomers-make-money-talk-number-one'>
            <p class="newsHead">Forget the 'Birds and the Bees' Boomers Make &lsquo;The Talk&rsquo; About Money &#35;1</p>
            <p class="date">October 17, 2016</p>
            <p class="abstract">Of course, Boomers had &ldquo;THE Talk&rdquo; about the &ldquo;birds and the bees&ldquo; with their kids. But they put more value in having the &ldquo;money talk&rdquo; because they want to be much more open about finances than their parents were with them.</p></a>
          </div>
          <div class='mix gridView Business_Banking' data-date='20161006' data-myorder='2016'>
            <a href='/content/pr/us-small-businesses-ring-in-election'>
            <p class="newsHead">U.S. Small Businesses Ring in Election&#44; Holiday Seasons with Good Cheer</p>
            <p class="date">October 6, 2016</p>
            <p class="abstract">Newest Chase survey &ldquo;Business Leaders Outlook&ldquo; reveals optimism for businesses and industry&#44; but caution about overall economy. Hispanic owners use more technology&#44; expect sales and profits to increase.</p></a>
          </div>
          <div class='mix gridView Consumer_Banking' data-date='20161005' data-myorder='2016'>
            <a href='/content/pr/holderness-partner-with-chase'><img alt='Penn and Kim Holderness Partner with Chase' src='/image/jpeg/1320713350377.jpg'>
            <p class="newsHead">Penn and Kim Holderness Partner with Chase</p>
            <p class="date">October 5, 2016</p>
            <p class="abstract">Social media stars partner with Chase to create 10 videos to highlight the ways digital banking creates more time for people.</p></a>
          </div>
          <div class='mix gridView Consumer_Banking' data-date='20160930' data-myorder='2016'>
            <a href='/content/pr/fdic-reports-number-one-in-deposit-growth'>
            <p class="newsHead">FDIC Reports JPMorgan Chase &#35;1 in U.S. Deposit Growth</p>
            <p class="date">September 30, 2016</p>
            <p class="abstract">For the fourth consecutive year, JPMorgan Chase led the nation in deposit growth as customers added &#36;85 billion to their bank accounts.</p></a>
          </div>
          <div class='mix gridView Consumer_Banking' data-date='20160927' data-myorder='2016'>
            <a href='/content/pr/duckett-named-ceo-consumer-banking'><img alt='Chase Names Thasunda Duckett CEO of Consumer Banking ' src='/image/jpeg/1320713696466.jpg'>
            <p class="newsHead">Chase Names Thasunda Duckett CEO of Consumer Banking</p>
            <p class="date">September 27, 2016</p>
            <p class="abstract">Chase announced today that Thasunda Duckett has been named CEO of Consumer Banking. She was previously CEO of the firm's Auto Finance business.</p></a>
          </div>
          <div class='mix gridView Payments and_Cards' data-date='20160922' data-myorder='2016'>
            <a href='/content/pr/walmart-payments-through-chasenet'>
            <p class="newsHead">Walmart to Process Payments through ChaseNet</p>
            <p class="date">September 22, 2016</p>
            <p class="abstract">Chase today announced that it has expanded its relationship with Walmart (NYSE: WMT) to process payments on ChaseNet, the bank's closed-loop network, at its 5,000+ Walmart and Sam's Club locations in the U.S. and at Sam's Club ecommerce.</p></a>
          </div>
          
         
          <div class="gap"></div>
          <div class="gap"></div>
          <div class="gap"></div>
        </div>
      </div><!-- .index-container -->