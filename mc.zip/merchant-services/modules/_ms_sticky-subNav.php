<!--<script>
!function(n) {
    "use strict";
    "function" == typeof define && define.amd ? define(["jquery"], n) : "undefined" != typeof exports ? module.exports = n(require("jquery")) : n(jQuery)
}(function(n) {
    "use strict";
    var t = window.Slick || {};
    t = function() {
        function t(t, r) {
            var f, u = this;
            u.defaults = {
                accessibility: !0,
                adaptiveHeight: !1,
                appendArrows: n(t),
                appendDots: n(t),
                arrows: !0,
                asNavFor: null ,
                prevArrow: '<button type="button" data-role="none" class="slick-prev" aria-label="Previous" tabindex="0" role="button">Previous<\/button>',
                nextArrow: '<button type="button" data-role="none" class="slick-next" aria-label="Next" tabindex="0" role="button">Next<\/button>',
                autoplay: !1,
                autoplaySpeed: 3e3,
                centerMode: !1,
                centerPadding: "50px",
                cssEase: "ease",
                customPaging: function(t, i) {
                    return n('<button type="button" data-role="none" role="button" tabindex="0" />').text(i + 1)
                },
                dots: !1,
                dotsClass: "slick-dots",
                draggable: !0,
                easing: "linear",
                edgeFriction: .35,
                fade: !1,
                focusOnSelect: !1,
                infinite: !0,
                initialSlide: 0,
                lazyLoad: "ondemand",
                mobileFirst: !1,
                pauseOnHover: !0,
                pauseOnFocus: !0,
                pauseOnDotsHover: !1,
                respondTo: "window",
                responsive: null ,
                rows: 1,
                rtl: !1,
                slide: "",
                slidesPerRow: 1,
                slidesToShow: 1,
                slidesToScroll: 1,
                speed: 500,
                swipe: !0,
                swipeToSlide: !1,
                touchMove: !0,
                touchThreshold: 5,
                useCSS: !0,
                useTransform: !0,
                variableWidth: !1,
                vertical: !1,
                verticalSwiping: !1,
                waitForAnimate: !0,
                zIndex: 1e3
            };
            u.initials = {
                animating: !1,
                dragging: !1,
                autoPlayTimer: null ,
                currentDirection: 0,
                currentLeft: null ,
                currentSlide: 0,
                direction: 1,
                $dots: null ,
                listWidth: null ,
                listHeight: null ,
                loadIndex: 0,
                $nextArrow: null ,
                $prevArrow: null ,
                slideCount: null ,
                slideWidth: null ,
                $slideTrack: null ,
                $slides: null ,
                sliding: !1,
                slideOffset: 0,
                swipeLeft: null ,
                $list: null ,
                touchObject: {},
                transformsEnabled: !1,
                unslicked: !1
            };
            n.extend(u, u.initials);
            u.activeBreakpoint = null ;
            u.animType = null ;
            u.animProp = null ;
            u.breakpoints = [];
            u.breakpointSettings = [];
            u.cssTransitions = !1;
            u.focussed = !1;
            u.interrupted = !1;
            u.hidden = "hidden";
            u.paused = !0;
            u.positionProp = null ;
            u.respondTo = null ;
            u.rowCount = 1;
            u.shouldClick = !0;
            u.$slider = n(t);
            u.$slidesCache = null ;
            u.transformType = null ;
            u.transitionType = null ;
            u.visibilityChange = "visibilitychange";
            u.windowWidth = 0;
            u.windowTimer = null ;
            f = n(t).data("slick") || {};
            u.options = n.extend({}, u.defaults, r, f);
            u.currentSlide = u.options.initialSlide;
            u.originalSettings = u.options;
            "undefined" != typeof document.mozHidden ? (u.hidden = "mozHidden",
            u.visibilityChange = "mozvisibilitychange") : "undefined" != typeof document.webkitHidden && (u.hidden = "webkitHidden",
            u.visibilityChange = "webkitvisibilitychange");
            u.autoPlay = n.proxy(u.autoPlay, u);
            u.autoPlayClear = n.proxy(u.autoPlayClear, u);
            u.autoPlayIterator = n.proxy(u.autoPlayIterator, u);
            u.changeSlide = n.proxy(u.changeSlide, u);
            u.clickHandler = n.proxy(u.clickHandler, u);
            u.selectHandler = n.proxy(u.selectHandler, u);
            u.setPosition = n.proxy(u.setPosition, u);
            u.swipeHandler = n.proxy(u.swipeHandler, u);
            u.dragHandler = n.proxy(u.dragHandler, u);
            u.keyHandler = n.proxy(u.keyHandler, u);
            u.instanceUid = i++;
            u.htmlExpr = /^(?:\s*(<[\w\W]+>)[^>]*)$/;
            u.registerBreakpoints();
            u.init(!0)
        }
        var i = 0;
        return t
    }();
    t.prototype.activateADA = function() {
        var n = this;
        n.$slideTrack.find(".slick-active").attr({
            "aria-hidden": "false"
        }).find("a, input, button, select").attr({
            tabindex: "0"
        })
    }
    ;
    t.prototype.addSlide = t.prototype.slickAdd = function(t, i, r) {
        var u = this;
        if ("boolean" == typeof i)
            r = i,
            i = null ;
        else if (0 > i || i >= u.slideCount)
            return !1;
        u.unload();
        "number" == typeof i ? 0 === i && 0 === u.$slides.length ? n(t).appendTo(u.$slideTrack) : r ? n(t).insertBefore(u.$slides.eq(i)) : n(t).insertAfter(u.$slides.eq(i)) : r === !0 ? n(t).prependTo(u.$slideTrack) : n(t).appendTo(u.$slideTrack);
        u.$slides = u.$slideTrack.children(this.options.slide);
        u.$slideTrack.children(this.options.slide).detach();
        u.$slideTrack.append(u.$slides);
        u.$slides.each(function(t, i) {
            n(i).attr("data-slick-index", t)
        });
        u.$slidesCache = u.$slides;
        u.reinit()
    }
    ;
    t.prototype.animateHeight = function() {
        var n = this, t;
        1 === n.options.slidesToShow && n.options.adaptiveHeight === !0 && n.options.vertical === !1 && (t = n.$slides.eq(n.currentSlide).outerHeight(!0),
        n.$list.animate({
            height: t
        }, n.options.speed))
    }
    ;
    t.prototype.animateSlide = function(t, i) {
        var u = {}
          , r = this;
        r.animateHeight();
        r.options.rtl === !0 && r.options.vertical === !1 && (t = -t);
        r.transformsEnabled === !1 ? r.options.vertical === !1 ? r.$slideTrack.animate({
            left: t
        }, r.options.speed, r.options.easing, i) : r.$slideTrack.animate({
            top: t
        }, r.options.speed, r.options.easing, i) : r.cssTransitions === !1 ? (r.options.rtl === !0 && (r.currentLeft = -r.currentLeft),
        n({
            animStart: r.currentLeft
        }).animate({
            animStart: t
        }, {
            duration: r.options.speed,
            easing: r.options.easing,
            step: function(n) {
                n = Math.ceil(n);
                r.options.vertical === !1 ? (u[r.animType] = "translate(" + n + "px, 0px)",
                r.$slideTrack.css(u)) : (u[r.animType] = "translate(0px," + n + "px)",
                r.$slideTrack.css(u))
            },
            complete: function() {
                i && i.call()
            }
        })) : (r.applyTransition(),
        t = Math.ceil(t),
        u[r.animType] = r.options.vertical === !1 ? "translate3d(" + t + "px, 0px, 0px)" : "translate3d(0px," + t + "px, 0px)",
        r.$slideTrack.css(u),
        i && setTimeout(function() {
            r.disableTransition();
            i.call()
        }, r.options.speed))
    }
    ;
    t.prototype.getNavTarget = function() {
        var i = this
          , t = i.options.asNavFor;
        return t && null !== t && (t = n(t).not(i.$slider)),
        t
    }
    ;
    t.prototype.asNavFor = function(t) {
        var r = this
          , i = r.getNavTarget();
        null !== i && "object" == typeof i && i.each(function() {
            var i = n(this).slick("getSlick");
            i.unslicked || i.slideHandler(t, !0)
        })
    }
    ;
    t.prototype.applyTransition = function(n) {
        var t = this
          , i = {};
        i[t.transitionType] = t.options.fade === !1 ? t.transformType + " " + t.options.speed + "ms " + t.options.cssEase : "opacity " + t.options.speed + "ms " + t.options.cssEase;
        t.options.fade === !1 ? t.$slideTrack.css(i) : t.$slides.eq(n).css(i)
    }
    ;
    t.prototype.autoPlay = function() {
        var n = this;
        n.autoPlayClear();
        n.slideCount > n.options.slidesToShow && (n.autoPlayTimer = setInterval(n.autoPlayIterator, n.options.autoplaySpeed))
    }
    ;
    t.prototype.autoPlayClear = function() {
        var n = this;
        n.autoPlayTimer && clearInterval(n.autoPlayTimer)
    }
    ;
    t.prototype.autoPlayIterator = function() {
        var n = this
          , t = n.currentSlide + n.options.slidesToScroll;
        n.paused || n.interrupted || n.focussed || (n.options.infinite === !1 && (1 === n.direction && n.currentSlide + 1 === n.slideCount - 1 ? n.direction = 0 : 0 === n.direction && (t = n.currentSlide - n.options.slidesToScroll,
        n.currentSlide - 1 == 0 && (n.direction = 1))),
        n.slideHandler(t))
    }
    ;
    t.prototype.buildArrows = function() {
        var t = this;
        t.options.arrows === !0 && (t.$prevArrow = n(t.options.prevArrow).addClass("slick-arrow"),
        t.$nextArrow = n(t.options.nextArrow).addClass("slick-arrow"),
        t.slideCount > t.options.slidesToShow ? (t.$prevArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),
        t.$nextArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),
        t.htmlExpr.test(t.options.prevArrow) && t.$prevArrow.prependTo(t.options.appendArrows),
        t.htmlExpr.test(t.options.nextArrow) && t.$nextArrow.appendTo(t.options.appendArrows),
        t.options.infinite !== !0 && t.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true")) : t.$prevArrow.add(t.$nextArrow).addClass("slick-hidden").attr({
            "aria-disabled": "true",
            tabindex: "-1"
        }))
    }
    ;
    t.prototype.buildDots = function() {
        var i, r, t = this;
        if (t.options.dots === !0 && t.slideCount > t.options.slidesToShow) {
            for (t.$slider.addClass("slick-dotted"),
            r = n("<ul />").addClass(t.options.dotsClass),
            i = 0; i <= t.getDotCount(); i += 1)
                r.append(n("<li />").append(t.options.customPaging.call(this, t, i)));
            t.$dots = r.appendTo(t.options.appendDots);
            t.$dots.find("li").first().addClass("slick-active").attr("aria-hidden", "false")
        }
    }
    ;
    t.prototype.buildOut = function() {
        var t = this;
        t.$slides = t.$slider.children(t.options.slide + ":not(.slick-cloned)").addClass("slick-slide");
        t.slideCount = t.$slides.length;
        t.$slides.each(function(t, i) {
            n(i).attr("data-slick-index", t).data("originalStyling", n(i).attr("style") || "")
        });
        t.$slider.addClass("slick-slider");
        t.$slideTrack = 0 === t.slideCount ? n('<div class="slick-track"/>').appendTo(t.$slider) : t.$slides.wrapAll('<div class="slick-track"/>').parent();
        t.$list = t.$slideTrack.wrap('<div aria-live="polite" class="slick-list"/>').parent();
        t.$slideTrack.css("opacity", 0);
        (t.options.centerMode === !0 || t.options.swipeToSlide === !0) && (t.options.slidesToScroll = 1);
        n("img[data-lazy]", t.$slider).not("[src]").addClass("slick-loading");
        t.setupInfinite();
        t.buildArrows();
        t.buildDots();
        t.updateDots();
        t.setSlideClasses("number" == typeof t.currentSlide ? t.currentSlide : 0);
        t.options.draggable === !0 && t.$list.addClass("draggable")
    }
    ;
    t.prototype.buildRows = function() {
        var t, i, r, f, c, u, e, n = this, o, s, h;
        if (f = document.createDocumentFragment(),
        u = n.$slider.children(),
        n.options.rows > 1) {
            for (e = n.options.slidesPerRow * n.options.rows,
            c = Math.ceil(u.length / e),
            t = 0; c > t; t++) {
                for (o = document.createElement("div"),
                i = 0; i < n.options.rows; i++) {
                    for (s = document.createElement("div"),
                    r = 0; r < n.options.slidesPerRow; r++)
                        h = t * e + (i * n.options.slidesPerRow + r),
                        u.get(h) && s.appendChild(u.get(h));
                    o.appendChild(s)
                }
                f.appendChild(o)
            }
            n.$slider.empty().append(f);
            n.$slider.children().children().children().css({
                width: 100 / n.options.slidesPerRow + "%",
                display: "inline-block"
            })
        }
    }
    ;
    t.prototype.checkResponsive = function(t, i) {
        var f, u, e, r = this, o = !1, s = r.$slider.width(), h = window.innerWidth || n(window).width();
        if ("window" === r.respondTo ? e = h : "slider" === r.respondTo ? e = s : "min" === r.respondTo && (e = Math.min(h, s)),
        r.options.responsive && r.options.responsive.length && null !== r.options.responsive) {
            u = null ;
            for (f in r.breakpoints)
                r.breakpoints.hasOwnProperty(f) && (r.originalSettings.mobileFirst === !1 ? e < r.breakpoints[f] && (u = r.breakpoints[f]) : e > r.breakpoints[f] && (u = r.breakpoints[f]));
            null !== u ? null !== r.activeBreakpoint ? (u !== r.activeBreakpoint || i) && (r.activeBreakpoint = u,
            "unslick" === r.breakpointSettings[u] ? r.unslick(u) : (r.options = n.extend({}, r.originalSettings, r.breakpointSettings[u]),
            t === !0 && (r.currentSlide = r.options.initialSlide),
            r.refresh(t)),
            o = u) : (r.activeBreakpoint = u,
            "unslick" === r.breakpointSettings[u] ? r.unslick(u) : (r.options = n.extend({}, r.originalSettings, r.breakpointSettings[u]),
            t === !0 && (r.currentSlide = r.options.initialSlide),
            r.refresh(t)),
            o = u) : null !== r.activeBreakpoint && (r.activeBreakpoint = null ,
            r.options = r.originalSettings,
            t === !0 && (r.currentSlide = r.options.initialSlide),
            r.refresh(t),
            o = u);
            t || o === !1 || r.$slider.trigger("breakpoint", [r, o])
        }
    }
    ;
    t.prototype.changeSlide = function(t, i) {
        var f, e, o, r = this, u = n(t.currentTarget), s;
        switch (u.is("a") && t.preventDefault(),
        u.is("li") || (u = u.closest("li")),
        o = r.slideCount % r.options.slidesToScroll != 0,
        f = o ? 0 : (r.slideCount - r.currentSlide) % r.options.slidesToScroll,
        t.data.message) {
        case "previous":
            e = 0 === f ? r.options.slidesToScroll : r.options.slidesToShow - f;
            r.slideCount > r.options.slidesToShow && r.slideHandler(r.currentSlide - e, !1, i);
            break;
        case "next":
            e = 0 === f ? r.options.slidesToScroll : f;
            r.slideCount > r.options.slidesToShow && r.slideHandler(r.currentSlide + e, !1, i);
            break;
        case "index":
            s = 0 === t.data.index ? 0 : t.data.index || u.index() * r.options.slidesToScroll;
            r.slideHandler(r.checkNavigable(s), !1, i);
            u.children().trigger("focus");
            break;
        default:
            return
        }
    }
    ;
    t.prototype.checkNavigable = function(n) {
        var t, i, u = this, r;
        if (t = u.getNavigableIndexes(),
        i = 0,
        n > t[t.length - 1])
            n = t[t.length - 1];
        else
            for (r in t) {
                if (n < t[r]) {
                    n = i;
                    break
                }
                i = t[r]
            }
        return n
    }
    ;
    t.prototype.cleanUpEvents = function() {
        var t = this;
        t.options.dots && null !== t.$dots && n("li", t.$dots).off("click.slick", t.changeSlide).off("mouseenter.slick", n.proxy(t.interrupt, t, !0)).off("mouseleave.slick", n.proxy(t.interrupt, t, !1));
        t.$slider.off("focus.slick blur.slick");
        t.options.arrows === !0 && t.slideCount > t.options.slidesToShow && (t.$prevArrow && t.$prevArrow.off("click.slick", t.changeSlide),
        t.$nextArrow && t.$nextArrow.off("click.slick", t.changeSlide));
        t.$list.off("touchstart.slick mousedown.slick", t.swipeHandler);
        t.$list.off("touchmove.slick mousemove.slick", t.swipeHandler);
        t.$list.off("touchend.slick mouseup.slick", t.swipeHandler);
        t.$list.off("touchcancel.slick mouseleave.slick", t.swipeHandler);
        t.$list.off("click.slick", t.clickHandler);
        n(document).off(t.visibilityChange, t.visibility);
        t.cleanUpSlideEvents();
        t.options.accessibility === !0 && t.$list.off("keydown.slick", t.keyHandler);
        t.options.focusOnSelect === !0 && n(t.$slideTrack).children().off("click.slick", t.selectHandler);
        n(window).off("orientationchange.slick.slick-" + t.instanceUid, t.orientationChange);
        n(window).off("resize.slick.slick-" + t.instanceUid, t.resize);
        n("[draggable!=true]", t.$slideTrack).off("dragstart", t.preventDefault);
        n(window).off("load.slick.slick-" + t.instanceUid, t.setPosition);
        n(document).off("ready.slick.slick-" + t.instanceUid, t.setPosition)
    }
    ;
    t.prototype.cleanUpSlideEvents = function() {
        var t = this;
        t.$list.off("mouseenter.slick", n.proxy(t.interrupt, t, !0));
        t.$list.off("mouseleave.slick", n.proxy(t.interrupt, t, !1))
    }
    ;
    t.prototype.cleanUpRows = function() {
        var n, t = this;
        t.options.rows > 1 && (n = t.$slides.children().children(),
        n.removeAttr("style"),
        t.$slider.empty().append(n))
    }
    ;
    t.prototype.clickHandler = function(n) {
        var t = this;
        t.shouldClick === !1 && (n.stopImmediatePropagation(),
        n.stopPropagation(),
        n.preventDefault())
    }
    ;
    t.prototype.destroy = function(t) {
        var i = this;
        i.autoPlayClear();
        i.touchObject = {};
        i.cleanUpEvents();
        n(".slick-cloned", i.$slider).detach();
        i.$dots && i.$dots.remove();
        i.$prevArrow && i.$prevArrow.length && (i.$prevArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display", ""),
        i.htmlExpr.test(i.options.prevArrow) && i.$prevArrow.remove());
        i.$nextArrow && i.$nextArrow.length && (i.$nextArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display", ""),
        i.htmlExpr.test(i.options.nextArrow) && i.$nextArrow.remove());
        i.$slides && (i.$slides.removeClass("slick-slide slick-active slick-center slick-visible slick-current").removeAttr("aria-hidden").removeAttr("data-slick-index").each(function() {
            n(this).attr("style", n(this).data("originalStyling"))
        }),
        i.$slideTrack.children(this.options.slide).detach(),
        i.$slideTrack.detach(),
        i.$list.detach(),
        i.$slider.append(i.$slides));
        i.cleanUpRows();
        i.$slider.removeClass("slick-slider");
        i.$slider.removeClass("slick-initialized");
        i.$slider.removeClass("slick-dotted");
        i.unslicked = !0;
        t || i.$slider.trigger("destroy", [i])
    }
    ;
    t.prototype.disableTransition = function(n) {
        var t = this
          , i = {};
        i[t.transitionType] = "";
        t.options.fade === !1 ? t.$slideTrack.css(i) : t.$slides.eq(n).css(i)
    }
    ;
    t.prototype.fadeSlide = function(n, t) {
        var i = this;
        i.cssTransitions === !1 ? (i.$slides.eq(n).css({
            zIndex: i.options.zIndex
        }),
        i.$slides.eq(n).animate({
            opacity: 1
        }, i.options.speed, i.options.easing, t)) : (i.applyTransition(n),
        i.$slides.eq(n).css({
            opacity: 1,
            zIndex: i.options.zIndex
        }),
        t && setTimeout(function() {
            i.disableTransition(n);
            t.call()
        }, i.options.speed))
    }
    ;
    t.prototype.fadeSlideOut = function(n) {
        var t = this;
        t.cssTransitions === !1 ? t.$slides.eq(n).animate({
            opacity: 0,
            zIndex: t.options.zIndex - 2
        }, t.options.speed, t.options.easing) : (t.applyTransition(n),
        t.$slides.eq(n).css({
            opacity: 0,
            zIndex: t.options.zIndex - 2
        }))
    }
    ;
    t.prototype.filterSlides = t.prototype.slickFilter = function(n) {
        var t = this;
        null !== n && (t.$slidesCache = t.$slides,
        t.unload(),
        t.$slideTrack.children(this.options.slide).detach(),
        t.$slidesCache.filter(n).appendTo(t.$slideTrack),
        t.reinit())
    }
    ;
    t.prototype.focusHandler = function() {
        var t = this;
        t.$slider.off("focus.slick blur.slick").on("focus.slick blur.slick", "*:not(.slick-arrow)", function(i) {
            i.stopImmediatePropagation();
            var r = n(this);
            setTimeout(function() {
                t.options.pauseOnFocus && (t.focussed = r.is(":focus"),
                t.autoPlay())
            }, 0)
        })
    }
    ;
    t.prototype.getCurrent = t.prototype.slickCurrentSlide = function() {
        var n = this;
        return n.currentSlide
    }
    ;
    t.prototype.getDotCount = function() {
        var n = this
          , i = 0
          , r = 0
          , t = 0;
        if (n.options.infinite === !0)
            for (; i < n.slideCount; )
                ++t,
                i = r + n.options.slidesToScroll,
                r += n.options.slidesToScroll <= n.options.slidesToShow ? n.options.slidesToScroll : n.options.slidesToShow;
        else if (n.options.centerMode === !0)
            t = n.slideCount;
        else if (n.options.asNavFor)
            for (; i < n.slideCount; )
                ++t,
                i = r + n.options.slidesToScroll,
                r += n.options.slidesToScroll <= n.options.slidesToShow ? n.options.slidesToScroll : n.options.slidesToShow;
        else
            t = 1 + Math.ceil((n.slideCount - n.options.slidesToShow) / n.options.slidesToScroll);
        return t - 1
    }
    ;
    t.prototype.getLeft = function(n) {
        var f, r, i, t = this, u = 0;
        return t.slideOffset = 0,
        r = t.$slides.first().outerHeight(!0),
        t.options.infinite === !0 ? (t.slideCount > t.options.slidesToShow && (t.slideOffset = t.slideWidth * t.options.slidesToShow * -1,
        u = r * t.options.slidesToShow * -1),
        t.slideCount % t.options.slidesToScroll != 0 && n + t.options.slidesToScroll > t.slideCount && t.slideCount > t.options.slidesToShow && (n > t.slideCount ? (t.slideOffset = (t.options.slidesToShow - (n - t.slideCount)) * t.slideWidth * -1,
        u = (t.options.slidesToShow - (n - t.slideCount)) * r * -1) : (t.slideOffset = t.slideCount % t.options.slidesToScroll * t.slideWidth * -1,
        u = t.slideCount % t.options.slidesToScroll * r * -1))) : n + t.options.slidesToShow > t.slideCount && (t.slideOffset = (n + t.options.slidesToShow - t.slideCount) * t.slideWidth,
        u = (n + t.options.slidesToShow - t.slideCount) * r),
        t.slideCount <= t.options.slidesToShow && (t.slideOffset = 0,
        u = 0),
        t.options.centerMode === !0 && t.options.infinite === !0 ? t.slideOffset += t.slideWidth * Math.floor(t.options.slidesToShow / 2) - t.slideWidth : t.options.centerMode === !0 && (t.slideOffset = 0,
        t.slideOffset += t.slideWidth * Math.floor(t.options.slidesToShow / 2)),
        f = t.options.vertical === !1 ? n * t.slideWidth * -1 + t.slideOffset : n * r * -1 + u,
        t.options.variableWidth === !0 && (i = t.slideCount <= t.options.slidesToShow || t.options.infinite === !1 ? t.$slideTrack.children(".slick-slide").eq(n) : t.$slideTrack.children(".slick-slide").eq(n + t.options.slidesToShow),
        f = t.options.rtl === !0 ? i[0] ? -1 * (t.$slideTrack.width() - i[0].offsetLeft - i.width()) : 0 : i[0] ? -1 * i[0].offsetLeft : 0,
        t.options.centerMode === !0 && (i = t.slideCount <= t.options.slidesToShow || t.options.infinite === !1 ? t.$slideTrack.children(".slick-slide").eq(n) : t.$slideTrack.children(".slick-slide").eq(n + t.options.slidesToShow + 1),
        f = t.options.rtl === !0 ? i[0] ? -1 * (t.$slideTrack.width() - i[0].offsetLeft - i.width()) : 0 : i[0] ? -1 * i[0].offsetLeft : 0,
        f += (t.$list.width() - i.outerWidth()) / 2)),
        f
    }
    ;
    t.prototype.getOption = t.prototype.slickGetOption = function(n) {
        var t = this;
        return t.options[n]
    }
    ;
    t.prototype.getNavigableIndexes = function() {
        var i, n = this, t = 0, r = 0, u = [];
        for (n.options.infinite === !1 ? i = n.slideCount : (t = -1 * n.options.slidesToScroll,
        r = -1 * n.options.slidesToScroll,
        i = 2 * n.slideCount); i > t; )
            u.push(t),
            t = r + n.options.slidesToScroll,
            r += n.options.slidesToScroll <= n.options.slidesToShow ? n.options.slidesToScroll : n.options.slidesToShow;
        return u
    }
    ;
    t.prototype.getSlick = function() {
        return this
    }
    ;
    t.prototype.getSlideCount = function() {
        var u, i, r, t = this;
        return r = t.options.centerMode === !0 ? t.slideWidth * Math.floor(t.options.slidesToShow / 2) : 0,
        t.options.swipeToSlide === !0 ? (t.$slideTrack.find(".slick-slide").each(function(u, f) {
            if (f.offsetLeft - r + n(f).outerWidth() / 2 > -1 * t.swipeLeft)
                return ( i = f,
                !1)
        }),
        u = Math.abs(n(i).attr("data-slick-index") - t.currentSlide) || 1) : t.options.slidesToScroll
    }
    ;
    t.prototype.goTo = t.prototype.slickGoTo = function(n, t) {
        var i = this;
        i.changeSlide({
            data: {
                message: "index",
                index: parseInt(n)
            }
        }, t)
    }
    ;
    t.prototype.init = function(t) {
        var i = this;
        n(i.$slider).hasClass("slick-initialized") || (n(i.$slider).addClass("slick-initialized"),
        i.buildRows(),
        i.buildOut(),
        i.setProps(),
        i.startLoad(),
        i.loadSlider(),
        i.initializeEvents(),
        i.updateArrows(),
        i.updateDots(),
        i.checkResponsive(!0),
        i.focusHandler());
        t && i.$slider.trigger("init", [i]);
        i.options.accessibility === !0 && i.initADA();
        i.options.autoplay && (i.paused = !1,
        i.autoPlay())
    }
    ;
    t.prototype.initADA = function() {
        var t = this;
        t.$slides.add(t.$slideTrack.find(".slick-cloned")).attr({
            "aria-hidden": "true",
            tabindex: "-1"
        }).find("a, input, button, select").attr({
            tabindex: "-1"
        });
        t.$slideTrack.attr("role", "listbox");
        t.$slides.not(t.$slideTrack.find(".slick-cloned")).each(function(i) {
            n(this).attr({
                role: "option",
                "aria-describedby": "slick-slide" + t.instanceUid + i
            })
        });
        null !== t.$dots && t.$dots.attr("role", "tablist").find("li").each(function(i) {
            n(this).attr({
                role: "presentation",
                "aria-selected": "false",
                "aria-controls": "navigation" + t.instanceUid + i,
                id: "slick-slide" + t.instanceUid + i
            })
        }).first().attr("aria-selected", "true").end().find("button").attr("role", "button").end().closest("div").attr("role", "toolbar");
        t.activateADA()
    }
    ;
    t.prototype.initArrowEvents = function() {
        var n = this;
        n.options.arrows === !0 && n.slideCount > n.options.slidesToShow && (n.$prevArrow.off("click.slick").on("click.slick", {
            message: "previous"
        }, n.changeSlide),
        n.$nextArrow.off("click.slick").on("click.slick", {
            message: "next"
        }, n.changeSlide))
    }
    ;
    t.prototype.initDotEvents = function() {
        var t = this;
        t.options.dots === !0 && t.slideCount > t.options.slidesToShow && n("li", t.$dots).on("click.slick", {
            message: "index"
        }, t.changeSlide);
        t.options.dots === !0 && t.options.pauseOnDotsHover === !0 && n("li", t.$dots).on("mouseenter.slick", n.proxy(t.interrupt, t, !0)).on("mouseleave.slick", n.proxy(t.interrupt, t, !1))
    }
    ;
    t.prototype.initSlideEvents = function() {
        var t = this;
        t.options.pauseOnHover && (t.$list.on("mouseenter.slick", n.proxy(t.interrupt, t, !0)),
        t.$list.on("mouseleave.slick", n.proxy(t.interrupt, t, !1)))
    }
    ;
    t.prototype.initializeEvents = function() {
        var t = this;
        t.initArrowEvents();
        t.initDotEvents();
        t.initSlideEvents();
        t.$list.on("touchstart.slick mousedown.slick", {
            action: "start"
        }, t.swipeHandler);
        t.$list.on("touchmove.slick mousemove.slick", {
            action: "move"
        }, t.swipeHandler);
        t.$list.on("touchend.slick mouseup.slick", {
            action: "end"
        }, t.swipeHandler);
        t.$list.on("touchcancel.slick mouseleave.slick", {
            action: "end"
        }, t.swipeHandler);
        t.$list.on("click.slick", t.clickHandler);
        n(document).on(t.visibilityChange, n.proxy(t.visibility, t));
        t.options.accessibility === !0 && t.$list.on("keydown.slick", t.keyHandler);
        t.options.focusOnSelect === !0 && n(t.$slideTrack).children().on("click.slick", t.selectHandler);
        n(window).on("orientationchange.slick.slick-" + t.instanceUid, n.proxy(t.orientationChange, t));
        n(window).on("resize.slick.slick-" + t.instanceUid, n.proxy(t.resize, t));
        n("[draggable!=true]", t.$slideTrack).on("dragstart", t.preventDefault);
        n(window).on("load.slick.slick-" + t.instanceUid, t.setPosition);
        n(document).on("ready.slick.slick-" + t.instanceUid, t.setPosition)
    }
    ;
    t.prototype.initUI = function() {
        var n = this;
        n.options.arrows === !0 && n.slideCount > n.options.slidesToShow && (n.$prevArrow.show(),
        n.$nextArrow.show());
        n.options.dots === !0 && n.slideCount > n.options.slidesToShow && n.$dots.show()
    }
    ;
    t.prototype.keyHandler = function(n) {
        var t = this;
        n.target.tagName.match("TEXTAREA|INPUT|SELECT") || (37 === n.keyCode && t.options.accessibility === !0 ? t.changeSlide({
            data: {
                message: t.options.rtl === !0 ? "next" : "previous"
            }
        }) : 39 === n.keyCode && t.options.accessibility === !0 && t.changeSlide({
            data: {
                message: t.options.rtl === !0 ? "previous" : "next"
            }
        }))
    }
    ;
    t.prototype.lazyLoad = function() {
        function f(i) {
            n("img[data-lazy]", i).each(function() {
                var i = n(this)
                  , r = n(this).attr("data-lazy")
                  , u = document.createElement("img");
                u.onload = function() {
                    i.animate({
                        opacity: 0
                    }, 100, function() {
                        i.attr("src", r).animate({
                            opacity: 1
                        }, 200, function() {
                            i.removeAttr("data-lazy").removeClass("slick-loading")
                        });
                        t.$slider.trigger("lazyLoaded", [t, i, r])
                    })
                }
                ;
                u.onerror = function() {
                    i.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error");
                    t.$slider.trigger("lazyLoadError", [t, i, r])
                }
                ;
                u.src = r
            })
        }
        var e, r, i, u, t = this;
        t.options.centerMode === !0 ? t.options.infinite === !0 ? (i = t.currentSlide + (t.options.slidesToShow / 2 + 1),
        u = i + t.options.slidesToShow + 2) : (i = Math.max(0, t.currentSlide - (t.options.slidesToShow / 2 + 1)),
        u = 2 + (t.options.slidesToShow / 2 + 1) + t.currentSlide) : (i = t.options.infinite ? t.options.slidesToShow + t.currentSlide : t.currentSlide,
        u = Math.ceil(i + t.options.slidesToShow),
        t.options.fade === !0 && (i > 0 && i--,
        u <= t.slideCount && u++));
        e = t.$slider.find(".slick-slide").slice(i, u);
        f(e);
        t.slideCount <= t.options.slidesToShow ? (r = t.$slider.find(".slick-slide"),
        f(r)) : t.currentSlide >= t.slideCount - t.options.slidesToShow ? (r = t.$slider.find(".slick-cloned").slice(0, t.options.slidesToShow),
        f(r)) : 0 === t.currentSlide && (r = t.$slider.find(".slick-cloned").slice(-1 * t.options.slidesToShow),
        f(r))
    }
    ;
    t.prototype.loadSlider = function() {
        var n = this;
        n.setPosition();
        n.$slideTrack.css({
            opacity: 1
        });
        n.$slider.removeClass("slick-loading");
        n.initUI();
        "progressive" === n.options.lazyLoad && n.progressiveLazyLoad()
    }
    ;
    t.prototype.next = t.prototype.slickNext = function() {
        var n = this;
        n.changeSlide({
            data: {
                message: "next"
            }
        })
    }
    ;
    t.prototype.orientationChange = function() {
        var n = this;
        n.checkResponsive();
        n.setPosition()
    }
    ;
    t.prototype.pause = t.prototype.slickPause = function() {
        var n = this;
        n.autoPlayClear();
        n.paused = !0
    }
    ;
    t.prototype.play = t.prototype.slickPlay = function() {
        var n = this;
        n.autoPlay();
        n.options.autoplay = !0;
        n.paused = !1;
        n.focussed = !1;
        n.interrupted = !1
    }
    ;
    t.prototype.postSlide = function(n) {
        var t = this;
        t.unslicked || (t.$slider.trigger("afterChange", [t, n]),
        t.animating = !1,
        t.setPosition(),
        t.swipeLeft = null ,
        t.options.autoplay && t.autoPlay(),
        t.options.accessibility === !0 && t.initADA())
    }
    ;
    t.prototype.prev = t.prototype.slickPrev = function() {
        var n = this;
        n.changeSlide({
            data: {
                message: "previous"
            }
        })
    }
    ;
    t.prototype.preventDefault = function(n) {
        n.preventDefault()
    }
    ;
    t.prototype.progressiveLazyLoad = function(t) {
        t = t || 1;
        var r, u, f, i = this, e = n("img[data-lazy]", i.$slider);
        e.length ? (r = e.first(),
        u = r.attr("data-lazy"),
        f = document.createElement("img"),
        f.onload = function() {
            r.attr("src", u).removeAttr("data-lazy").removeClass("slick-loading");
            i.options.adaptiveHeight === !0 && i.setPosition();
            i.$slider.trigger("lazyLoaded", [i, r, u]);
            i.progressiveLazyLoad()
        }
        ,
        f.onerror = function() {
            3 > t ? setTimeout(function() {
                i.progressiveLazyLoad(t + 1)
            }, 500) : (r.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"),
            i.$slider.trigger("lazyLoadError", [i, r, u]),
            i.progressiveLazyLoad())
        }
        ,
        f.src = u) : i.$slider.trigger("allImagesLoaded", [i])
    }
    ;
    t.prototype.refresh = function(t) {
        var r, u, i = this;
        u = i.slideCount - i.options.slidesToShow;
        !i.options.infinite && i.currentSlide > u && (i.currentSlide = u);
        i.slideCount <= i.options.slidesToShow && (i.currentSlide = 0);
        r = i.currentSlide;
        i.destroy(!0);
        n.extend(i, i.initials, {
            currentSlide: r
        });
        i.init();
        t || i.changeSlide({
            data: {
                message: "index",
                index: r
            }
        }, !1)
    }
    ;
    t.prototype.registerBreakpoints = function() {
        var u, f, i, t = this, r = t.options.responsive || null ;
        if ("array" === n.type(r) && r.length) {
            t.respondTo = t.options.respondTo || "window";
            for (u in r)
                if (i = t.breakpoints.length - 1,
                f = r[u].breakpoint,
                r.hasOwnProperty(u)) {
                    for (; i >= 0; )
                        t.breakpoints[i] && t.breakpoints[i] === f && t.breakpoints.splice(i, 1),
                        i--;
                    t.breakpoints.push(f);
                    t.breakpointSettings[f] = r[u].settings
                }
            t.breakpoints.sort(function(n, i) {
                return t.options.mobileFirst ? n - i : i - n
            })
        }
    }
    ;
    t.prototype.reinit = function() {
        var t = this;
        t.$slides = t.$slideTrack.children(t.options.slide).addClass("slick-slide");
        t.slideCount = t.$slides.length;
        t.currentSlide >= t.slideCount && 0 !== t.currentSlide && (t.currentSlide = t.currentSlide - t.options.slidesToScroll);
        t.slideCount <= t.options.slidesToShow && (t.currentSlide = 0);
        t.registerBreakpoints();
        t.setProps();
        t.setupInfinite();
        t.buildArrows();
        t.updateArrows();
        t.initArrowEvents();
        t.buildDots();
        t.updateDots();
        t.initDotEvents();
        t.cleanUpSlideEvents();
        t.initSlideEvents();
        t.checkResponsive(!1, !0);
        t.options.focusOnSelect === !0 && n(t.$slideTrack).children().on("click.slick", t.selectHandler);
        t.setSlideClasses("number" == typeof t.currentSlide ? t.currentSlide : 0);
        t.setPosition();
        t.focusHandler();
        t.paused = !t.options.autoplay;
        t.autoPlay();
        t.$slider.trigger("reInit", [t])
    }
    ;
    t.prototype.resize = function() {
        var t = this;
        n(window).width() !== t.windowWidth && (clearTimeout(t.windowDelay),
        t.windowDelay = window.setTimeout(function() {
            t.windowWidth = n(window).width();
            t.checkResponsive();
            t.unslicked || t.setPosition()
        }, 50))
    }
    ;
    t.prototype.removeSlide = t.prototype.slickRemove = function(n, t, i) {
        var r = this;
        return "boolean" == typeof n ? (t = n,
        n = t === !0 ? 0 : r.slideCount - 1) : n = t === !0 ? --n : n,
        r.slideCount < 1 || 0 > n || n > r.slideCount - 1 ? !1 : (r.unload(),
        i === !0 ? r.$slideTrack.children().remove() : r.$slideTrack.children(this.options.slide).eq(n).remove(),
        r.$slides = r.$slideTrack.children(this.options.slide),
        r.$slideTrack.children(this.options.slide).detach(),
        r.$slideTrack.append(r.$slides),
        r.$slidesCache = r.$slides,
        void r.reinit())
    }
    ;
    t.prototype.setCSS = function(n) {
        var r, u, t = this, i = {};
        t.options.rtl === !0 && (n = -n);
        r = "left" == t.positionProp ? Math.ceil(n) + "px" : "0px";
        u = "top" == t.positionProp ? Math.ceil(n) + "px" : "0px";
        i[t.positionProp] = n;
        t.transformsEnabled === !1 ? t.$slideTrack.css(i) : (i = {},
        t.cssTransitions === !1 ? (i[t.animType] = "translate(" + r + ", " + u + ")",
        t.$slideTrack.css(i)) : (i[t.animType] = "translate3d(" + r + ", " + u + ", 0px)",
        t.$slideTrack.css(i)))
    }
    ;
    t.prototype.setDimensions = function() {
        var n = this, t;
        n.options.vertical === !1 ? n.options.centerMode === !0 && n.$list.css({
            padding: "0px " + n.options.centerPadding
        }) : (n.$list.height(n.$slides.first().outerHeight(!0) * n.options.slidesToShow),
        n.options.centerMode === !0 && n.$list.css({
            padding: n.options.centerPadding + " 0px"
        }));
        n.listWidth = n.$list.width();
        n.listHeight = n.$list.height();
        n.options.vertical === !1 && n.options.variableWidth === !1 ? (n.slideWidth = Math.ceil(n.listWidth / n.options.slidesToShow),
        n.$slideTrack.width(Math.ceil(n.slideWidth * n.$slideTrack.children(".slick-slide").length))) : n.options.variableWidth === !0 ? n.$slideTrack.width(5e3 * n.slideCount) : (n.slideWidth = Math.ceil(n.listWidth),
        n.$slideTrack.height(Math.ceil(n.$slides.first().outerHeight(!0) * n.$slideTrack.children(".slick-slide").length)));
        t = n.$slides.first().outerWidth(!0) - n.$slides.first().width();
        n.options.variableWidth === !1 && n.$slideTrack.children(".slick-slide").width(n.slideWidth - t)
    }
    ;
    t.prototype.setFade = function() {
        var i, t = this;
        t.$slides.each(function(r, u) {
            i = t.slideWidth * r * -1;
            t.options.rtl === !0 ? n(u).css({
                position: "relative",
                right: i,
                top: 0,
                zIndex: t.options.zIndex - 2,
                opacity: 0
            }) : n(u).css({
                position: "relative",
                left: i,
                top: 0,
                zIndex: t.options.zIndex - 2,
                opacity: 0
            })
        });
        t.$slides.eq(t.currentSlide).css({
            zIndex: t.options.zIndex - 1,
            opacity: 1
        })
    }
    ;
    t.prototype.setHeight = function() {
        var n = this, t;
        1 === n.options.slidesToShow && n.options.adaptiveHeight === !0 && n.options.vertical === !1 && (t = n.$slides.eq(n.currentSlide).outerHeight(!0),
        n.$list.css("height", t))
    }
    ;
    t.prototype.setOption = t.prototype.slickSetOption = function() {
        var u, f, e, i, r, t = this, o = !1;
        if ("object" === n.type(arguments[0]) ? (e = arguments[0],
        o = arguments[1],
        r = "multiple") : "string" === n.type(arguments[0]) && (e = arguments[0],
        i = arguments[1],
        o = arguments[2],
        "responsive" === arguments[0] && "array" === n.type(arguments[1]) ? r = "responsive" : "undefined" != typeof arguments[1] && (r = "single")),
        "single" === r)
            t.options[e] = i;
        else if ("multiple" === r)
            n.each(e, function(n, i) {
                t.options[n] = i
            });
        else if ("responsive" === r)
            for (f in i)
                if ("array" !== n.type(t.options.responsive))
                    t.options.responsive = [i[f]];
                else {
                    for (u = t.options.responsive.length - 1; u >= 0; )
                        t.options.responsive[u].breakpoint === i[f].breakpoint && t.options.responsive.splice(u, 1),
                        u--;
                    t.options.responsive.push(i[f])
                }
        o && (t.unload(),
        t.reinit())
    }
    ;
    t.prototype.setPosition = function() {
        var n = this;
        n.setDimensions();
        n.setHeight();
        n.options.fade === !1 ? n.setCSS(n.getLeft(n.currentSlide)) : n.setFade();
        n.$slider.trigger("setPosition", [n])
    }
    ;
    t.prototype.setProps = function() {
        var n = this
          , t = document.body.style;
        n.positionProp = n.options.vertical === !0 ? "top" : "left";
        "top" === n.positionProp ? n.$slider.addClass("slick-vertical") : n.$slider.removeClass("slick-vertical");
        (void 0 !== t.WebkitTransition || void 0 !== t.MozTransition || void 0 !== t.msTransition) && n.options.useCSS === !0 && (n.cssTransitions = !0);
        n.options.fade && ("number" == typeof n.options.zIndex ? n.options.zIndex < 3 && (n.options.zIndex = 3) : n.options.zIndex = n.defaults.zIndex);
        void 0 !== t.OTransform && (n.animType = "OTransform",
        n.transformType = "-o-transform",
        n.transitionType = "OTransition",
        void 0 === t.perspectiveProperty && void 0 === t.webkitPerspective && (n.animType = !1));
        void 0 !== t.MozTransform && (n.animType = "MozTransform",
        n.transformType = "-moz-transform",
        n.transitionType = "MozTransition",
        void 0 === t.perspectiveProperty && void 0 === t.MozPerspective && (n.animType = !1));
        void 0 !== t.webkitTransform && (n.animType = "webkitTransform",
        n.transformType = "-webkit-transform",
        n.transitionType = "webkitTransition",
        void 0 === t.perspectiveProperty && void 0 === t.webkitPerspective && (n.animType = !1));
        void 0 !== t.msTransform && (n.animType = "msTransform",
        n.transformType = "-ms-transform",
        n.transitionType = "msTransition",
        void 0 === t.msTransform && (n.animType = !1));
        void 0 !== t.transform && n.animType !== !1 && (n.animType = "transform",
        n.transformType = "transform",
        n.transitionType = "transition");
        n.transformsEnabled = n.options.useTransform && null !== n.animType && n.animType !== !1
    }
    ;
    t.prototype.setSlideClasses = function(n) {
        var u, i, r, f, t = this;
        i = t.$slider.find(".slick-slide").removeClass("slick-active slick-center slick-current").attr("aria-hidden", "true");
        t.$slides.eq(n).addClass("slick-current");
        t.options.centerMode === !0 ? (u = Math.floor(t.options.slidesToShow / 2),
        t.options.infinite === !0 && (n >= u && n <= t.slideCount - 1 - u ? t.$slides.slice(n - u, n + u + 1).addClass("slick-active").attr("aria-hidden", "false") : (r = t.options.slidesToShow + n,
        i.slice(r - u + 1, r + u + 2).addClass("slick-active").attr("aria-hidden", "false")),
        0 === n ? i.eq(i.length - 1 - t.options.slidesToShow).addClass("slick-center") : n === t.slideCount - 1 && i.eq(t.options.slidesToShow).addClass("slick-center")),
        t.$slides.eq(n).addClass("slick-center")) : n >= 0 && n <= t.slideCount - t.options.slidesToShow ? t.$slides.slice(n, n + t.options.slidesToShow).addClass("slick-active").attr("aria-hidden", "false") : i.length <= t.options.slidesToShow ? i.addClass("slick-active").attr("aria-hidden", "false") : (f = t.slideCount % t.options.slidesToShow,
        r = t.options.infinite === !0 ? t.options.slidesToShow + n : n,
        t.options.slidesToShow == t.options.slidesToScroll && t.slideCount - n < t.options.slidesToShow ? i.slice(r - (t.options.slidesToShow - f), r + f).addClass("slick-active").attr("aria-hidden", "false") : i.slice(r, r + t.options.slidesToShow).addClass("slick-active").attr("aria-hidden", "false"));
        "ondemand" === t.options.lazyLoad && t.lazyLoad()
    }
    ;
    t.prototype.setupInfinite = function() {
        var i, r, u, t = this;
        if (t.options.fade === !0 && (t.options.centerMode = !1),
        t.options.infinite === !0 && t.options.fade === !1 && (r = null ,
        t.slideCount > t.options.slidesToShow)) {
            for (u = t.options.centerMode === !0 ? t.options.slidesToShow + 1 : t.options.slidesToShow,
            i = t.slideCount; i > t.slideCount - u; i -= 1)
                r = i - 1,
                n(t.$slides[r]).clone(!0).attr("id", "").attr("data-slick-index", r - t.slideCount).prependTo(t.$slideTrack).addClass("slick-cloned");
            for (i = 0; u > i; i += 1)
                r = i,
                n(t.$slides[r]).clone(!0).attr("id", "").attr("data-slick-index", r + t.slideCount).appendTo(t.$slideTrack).addClass("slick-cloned");
            t.$slideTrack.find(".slick-cloned").find("[id]").each(function() {
                n(this).attr("id", "")
            })
        }
    }
    ;
    t.prototype.interrupt = function(n) {
        var t = this;
        n || t.autoPlay();
        t.interrupted = n
    }
    ;
    t.prototype.selectHandler = function(t) {
        var i = this
          , u = n(t.target).is(".slick-slide") ? n(t.target) : n(t.target).parents(".slick-slide")
          , r = parseInt(u.attr("data-slick-index"));
        return r || (r = 0),
        i.slideCount <= i.options.slidesToShow ? (i.setSlideClasses(r),
        void i.asNavFor(r)) : void i.slideHandler(r)
    }
    ;
    t.prototype.slideHandler = function(n, t, i) {
        var u, f, s, o, e, h = null , r = this;
        return t = t || !1,
        r.animating === !0 && r.options.waitForAnimate === !0 || r.options.fade === !0 && r.currentSlide === n || r.slideCount <= r.options.slidesToShow ? void 0 : (t === !1 && r.asNavFor(n),
        u = n,
        h = r.getLeft(u),
        o = r.getLeft(r.currentSlide),
        r.currentLeft = null === r.swipeLeft ? o : r.swipeLeft,
        r.options.infinite === !1 && r.options.centerMode === !1 && (0 > n || n > r.getDotCount() * r.options.slidesToScroll) ? void (r.options.fade === !1 && (u = r.currentSlide,
        i !== !0 ? r.animateSlide(o, function() {
            r.postSlide(u)
        }) : r.postSlide(u))) : r.options.infinite === !1 && r.options.centerMode === !0 && (0 > n || n > r.slideCount - r.options.slidesToScroll) ? void (r.options.fade === !1 && (u = r.currentSlide,
        i !== !0 ? r.animateSlide(o, function() {
            r.postSlide(u)
        }) : r.postSlide(u))) : (r.options.autoplay && clearInterval(r.autoPlayTimer),
        f = 0 > u ? r.slideCount % r.options.slidesToScroll != 0 ? r.slideCount - r.slideCount % r.options.slidesToScroll : r.slideCount + u : u >= r.slideCount ? r.slideCount % r.options.slidesToScroll != 0 ? 0 : u - r.slideCount : u,
        r.animating = !0,
        r.$slider.trigger("beforeChange", [r, r.currentSlide, f]),
        s = r.currentSlide,
        r.currentSlide = f,
        r.setSlideClasses(r.currentSlide),
        r.options.asNavFor && (e = r.getNavTarget(),
        e = e.slick("getSlick"),
        e.slideCount <= e.options.slidesToShow && e.setSlideClasses(r.currentSlide)),
        r.updateDots(),
        r.updateArrows(),
        r.options.fade === !0 ? (i !== !0 ? (r.fadeSlideOut(s),
        r.fadeSlide(f, function() {
            r.postSlide(f)
        })) : r.postSlide(f),
        void r.animateHeight()) : void (i !== !0 ? r.animateSlide(h, function() {
            r.postSlide(f)
        }) : r.postSlide(f))))
    }
    ;
    t.prototype.startLoad = function() {
        var n = this;
        n.options.arrows === !0 && n.slideCount > n.options.slidesToShow && (n.$prevArrow.hide(),
        n.$nextArrow.hide());
        n.options.dots === !0 && n.slideCount > n.options.slidesToShow && n.$dots.hide();
        n.$slider.addClass("slick-loading")
    }
    ;
    t.prototype.swipeDirection = function() {
        var i, r, u, n, t = this;
        return i = t.touchObject.startX - t.touchObject.curX,
        r = t.touchObject.startY - t.touchObject.curY,
        u = Math.atan2(r, i),
        n = Math.round(180 * u / Math.PI),
        0 > n && (n = 360 - Math.abs(n)),
        45 >= n && n >= 0 ? t.options.rtl === !1 ? "left" : "right" : 360 >= n && n >= 315 ? t.options.rtl === !1 ? "left" : "right" : n >= 135 && 225 >= n ? t.options.rtl === !1 ? "right" : "left" : t.options.verticalSwiping === !0 ? n >= 35 && 135 >= n ? "down" : "up" : "vertical"
    }
    ;
    t.prototype.swipeEnd = function() {
        var t, i, n = this;
        if (n.dragging = !1,
        n.interrupted = !1,
        n.shouldClick = n.touchObject.swipeLength > 10 ? !1 : !0,
        void 0 === n.touchObject.curX)
            return !1;
        if (n.touchObject.edgeHit === !0 && n.$slider.trigger("edge", [n, n.swipeDirection()]),
        n.touchObject.swipeLength >= n.touchObject.minSwipe) {
            switch (i = n.swipeDirection()) {
            case "left":
            case "down":
                t = n.options.swipeToSlide ? n.checkNavigable(n.currentSlide + n.getSlideCount()) : n.currentSlide + n.getSlideCount();
                n.currentDirection = 0;
                break;
            case "right":
            case "up":
                t = n.options.swipeToSlide ? n.checkNavigable(n.currentSlide - n.getSlideCount()) : n.currentSlide - n.getSlideCount();
                n.currentDirection = 1
            }
            "vertical" != i && (n.slideHandler(t),
            n.touchObject = {},
            n.$slider.trigger("swipe", [n, i]))
        } else
            n.touchObject.startX !== n.touchObject.curX && (n.slideHandler(n.currentSlide),
            n.touchObject = {})
    }
    ;
    t.prototype.swipeHandler = function(n) {
        var t = this;
        if (!(t.options.swipe === !1 || "ontouchend"in document && t.options.swipe === !1 || t.options.draggable === !1 && -1 !== n.type.indexOf("mouse")))
            switch (t.touchObject.fingerCount = n.originalEvent && void 0 !== n.originalEvent.touches ? n.originalEvent.touches.length : 1,
            t.touchObject.minSwipe = t.listWidth / t.options.touchThreshold,
            t.options.verticalSwiping === !0 && (t.touchObject.minSwipe = t.listHeight / t.options.touchThreshold),
            n.data.action) {
            case "start":
                t.swipeStart(n);
                break;
            case "move":
                t.swipeMove(n);
                break;
            case "end":
                t.swipeEnd(n)
            }
    }
    ;
    t.prototype.swipeMove = function(n) {
        var f, e, r, u, i, t = this;
        return i = void 0 !== n.originalEvent ? n.originalEvent.touches : null ,
        !t.dragging || i && 1 !== i.length ? !1 : (f = t.getLeft(t.currentSlide),
        t.touchObject.curX = void 0 !== i ? i[0].pageX : n.clientX,
        t.touchObject.curY = void 0 !== i ? i[0].pageY : n.clientY,
        t.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(t.touchObject.curX - t.touchObject.startX, 2))),
        t.options.verticalSwiping === !0 && (t.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(t.touchObject.curY - t.touchObject.startY, 2)))),
        e = t.swipeDirection(),
        "vertical" !== e ? (void 0 !== n.originalEvent && t.touchObject.swipeLength > 4 && n.preventDefault(),
        u = (t.options.rtl === !1 ? 1 : -1) * (t.touchObject.curX > t.touchObject.startX ? 1 : -1),
        t.options.verticalSwiping === !0 && (u = t.touchObject.curY > t.touchObject.startY ? 1 : -1),
        r = t.touchObject.swipeLength,
        t.touchObject.edgeHit = !1,
        t.options.infinite === !1 && (0 === t.currentSlide && "right" === e || t.currentSlide >= t.getDotCount() && "left" === e) && (r = t.touchObject.swipeLength * t.options.edgeFriction,
        t.touchObject.edgeHit = !0),
        t.swipeLeft = t.options.vertical === !1 ? f + r * u : f + r * (t.$list.height() / t.listWidth) * u,
        t.options.verticalSwiping === !0 && (t.swipeLeft = f + r * u),
        t.options.fade === !0 || t.options.touchMove === !1 ? !1 : t.animating === !0 ? (t.swipeLeft = null ,
        !1) : void t.setCSS(t.swipeLeft)) : void 0)
    }
    ;
    t.prototype.swipeStart = function(n) {
        var i, t = this;
        return t.interrupted = !0,
        1 !== t.touchObject.fingerCount || t.slideCount <= t.options.slidesToShow ? (t.touchObject = {},
        !1) : (void 0 !== n.originalEvent && void 0 !== n.originalEvent.touches && (i = n.originalEvent.touches[0]),
        t.touchObject.startX = t.touchObject.curX = void 0 !== i ? i.pageX : n.clientX,
        t.touchObject.startY = t.touchObject.curY = void 0 !== i ? i.pageY : n.clientY,
        void (t.dragging = !0))
    }
    ;
    t.prototype.unfilterSlides = t.prototype.slickUnfilter = function() {
        var n = this;
        null !== n.$slidesCache && (n.unload(),
        n.$slideTrack.children(this.options.slide).detach(),
        n.$slidesCache.appendTo(n.$slideTrack),
        n.reinit())
    }
    ;
    t.prototype.unload = function() {
        var t = this;
        n(".slick-cloned", t.$slider).remove();
        t.$dots && t.$dots.remove();
        t.$prevArrow && t.htmlExpr.test(t.options.prevArrow) && t.$prevArrow.remove();
        t.$nextArrow && t.htmlExpr.test(t.options.nextArrow) && t.$nextArrow.remove();
        t.$slides.removeClass("slick-slide slick-active slick-visible slick-current").attr("aria-hidden", "true").css("width", "")
    }
    ;
    t.prototype.unslick = function(n) {
        var t = this;
        t.$slider.trigger("unslick", [t, n]);
        t.destroy()
    }
    ;
    t.prototype.updateArrows = function() {
        var t, n = this;
        t = Math.floor(n.options.slidesToShow / 2);
        n.options.arrows === !0 && n.slideCount > n.options.slidesToShow && !n.options.infinite && (n.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false"),
        n.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false"),
        0 === n.currentSlide ? (n.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true"),
        n.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false")) : n.currentSlide >= n.slideCount - n.options.slidesToShow && n.options.centerMode === !1 ? (n.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true"),
        n.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false")) : n.currentSlide >= n.slideCount - 1 && n.options.centerMode === !0 && (n.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true"),
        n.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false")))
    }
    ;
    t.prototype.updateDots = function() {
        var n = this;
        null !== n.$dots && (n.$dots.find("li").removeClass("slick-active").attr("aria-hidden", "true"),
        n.$dots.find("li").eq(Math.floor(n.currentSlide / n.options.slidesToScroll)).addClass("slick-active").attr("aria-hidden", "false"))
    }
    ;
    t.prototype.visibility = function() {
        var n = this;
        n.options.autoplay && (n.interrupted = document[n.hidden] ? !0 : !1)
    }
    ;
    n.fn.slick = function() {
        for (var u, i = this, r = arguments[0], f = Array.prototype.slice.call(arguments, 1), e = i.length, n = 0; e > n; n++)
            if ("object" == typeof r || "undefined" == typeof r ? i[n].slick = new t(i[n],r) : u = i[n].slick[r].apply(i[n].slick, f),
            "undefined" != typeof u)
                return u;
        return i
    }
});
/*!-----------------------------------------------------------------------------
 * Vegas - Fullscreen Backgrounds and Slideshows.
 * v2.2.0 - built 2016-01-18
 * Licensed under the MIT License.
 * http://vegas.jaysalvat.com/
 * ----------------------------------------------------------------------------
 * Copyright (C) 2010-2016 Jay Salvat
 * http://jaysalvat.com/
 * --------------------------------------------------------------------------*/
!function(n) {
    "use strict";
    var t = {
        slide: 0,
        delay: 5e3,
        preload: !1,
        preloadImage: !1,
        preloadVideo: !1,
        timer: !0,
        overlay: !1,
        autoplay: !0,
        shuffle: !1,
        cover: !0,
        color: null ,
        align: "center",
        valign: "center",
        transition: "fade",
        transitionDuration: 1e3,
        transitionRegister: [],
        animation: null ,
        animationDuration: "auto",
        animationRegister: [],
        init: function() {},
        play: function() {},
        pause: function() {},
        walk: function() {},
        slides: []
    }
      , i = {}
      , r = function(i, r) {
        this.elmt = i;
        this.settings = n.extend({}, t, n.vegas.defaults, r);
        this.slide = this.settings.slide;
        this.total = this.settings.slides.length;
        this.noshow = this.total < 2;
        this.paused = !this.settings.autoplay || this.noshow;
        this.$elmt = n(i);
        this.$timer = null ;
        this.$overlay = null ;
        this.$slide = null ;
        this.timeout = null ;
        this.transitions = ["fade", "fade2", "blur", "blur2", "flash", "flash2", "negative", "negative2", "burn", "burn2", "slideLeft", "slideLeft2", "slideRight", "slideRight2", "slideUp", "slideUp2", "slideDown", "slideDown2", "zoomIn", "zoomIn2", "zoomOut", "zoomOut2", "swirlLeft", "swirlLeft2", "swirlRight", "swirlRight2"];
        this.animations = ["kenburns", "kenburnsLeft", "kenburnsRight", "kenburnsUp", "kenburnsUpLeft", "kenburnsUpRight", "kenburnsDown", "kenburnsDownLeft", "kenburnsDownRight"];
        this.settings.transitionRegister instanceof Array == !1 && (this.settings.transitionRegister = [this.settings.transitionRegister]);
        this.settings.animationRegister instanceof Array == !1 && (this.settings.animationRegister = [this.settings.animationRegister]);
        this.transitions = this.transitions.concat(this.settings.transitionRegister);
        this.animations = this.animations.concat(this.settings.animationRegister);
        this.support = {
            objectFit: "objectFit"in document.body.style,
            transition: "transition"in document.body.style || "WebkitTransition"in document.body.style,
            video: n.vegas.isVideoCompatible()
        };
        this.settings.shuffle === !0 && this.shuffle();
        this._init()
    }
    ;
    r.prototype = {
        _init: function() {
            var i, r, u, e = "BODY" === this.elmt.tagName, o = this.settings.timer, f = this.settings.overlay, t = this;
            this._preload();
            e || (this.$elmt.css("height", this.$elmt.css("height")),
            i = n('<div class="vegas-wrapper">').css("overflow", this.$elmt.css("overflow")).css("padding", this.$elmt.css("padding")),
            this.$elmt.css("padding") || i.css("padding-top", this.$elmt.css("padding-top")).css("padding-bottom", this.$elmt.css("padding-bottom")).css("padding-left", this.$elmt.css("padding-left")).css("padding-right", this.$elmt.css("padding-right")),
            this.$elmt.clone(!0).children().appendTo(i),
            this.elmt.innerHTML = "");
            o && this.support.transition && (u = n('<div class="vegas-timer"><div class="vegas-timer-progress">'),
            this.$timer = u,
            this.$elmt.prepend(u));
            f && (r = n('<div class="vegas-overlay">'),
            "string" == typeof f && r.css("background-image", "url(" + f + ")"),
            this.$overlay = r,
            this.$elmt.prepend(r));
            this.$elmt.addClass("vegas-container");
            e || this.$elmt.append(i);
            setTimeout(function() {
                t.trigger("init");
                t._goto(t.slide);
                t.settings.autoplay && t.trigger("play")
            }, 1)
        },
        _preload: function() {
            for (var t, n = 0; n < this.settings.slides.length; n++)
                (this.settings.preload || this.settings.preloadImages) && this.settings.slides[n].src && (t = new Image,
                t.src = this.settings.slides[n].src),
                (this.settings.preload || this.settings.preloadVideos) && this.support.video && this.settings.slides[n].video && (this.settings.slides[n].video instanceof Array ? this._video(this.settings.slides[n].video) : this._video(this.settings.slides[n].video.src))
        },
        _random: function(n) {
            return n[Math.floor(Math.random() * (n.length - 1))]
        },
        _slideShow: function() {
            var n = this;
            this.total > 1 && !this.paused && !this.noshow && (this.timeout = setTimeout(function() {
                n.next()
            }, this._options("delay")))
        },
        _timer: function(n) {
            var t = this;
            clearTimeout(this.timeout);
            this.$timer && (this.$timer.removeClass("vegas-timer-running").find("div").css("transition-duration", "0ms"),
            this.paused || this.noshow || n && setTimeout(function() {
                t.$timer.addClass("vegas-timer-running").find("div").css("transition-duration", t._options("delay") - 100 + "ms")
            }, 100))
        },
        _video: function(n) {
            var t, r, u = n.toString();
            return i[u] ? i[u] : (n instanceof Array == !1 && (n = [n]),
            t = document.createElement("video"),
            t.preload = !0,
            n.forEach(function(n) {
                r = document.createElement("source");
                r.src = n;
                t.appendChild(r)
            }),
            i[u] = t,
            t)
        },
        _fadeOutSound: function(n, t) {
            var r = this
              , u = t / 10
              , i = n.volume - .09;
            i > 0 ? (n.volume = i,
            setTimeout(function() {
                r._fadeOutSound(n, t)
            }, u)) : n.pause()
        },
        _fadeInSound: function(n, t) {
            var r = this
              , u = t / 10
              , i = n.volume + .09;
            1 > i && (n.volume = i,
            setTimeout(function() {
                r._fadeInSound(n, t)
            }, u))
        },
        _options: function(n, t) {
            return void 0 === t && (t = this.slide),
            void 0 !== this.settings.slides[t][n] ? this.settings.slides[t][n] : this.settings[n]
        },
        _goto: function(t) {
            function w() {
                c._timer(!0);
                setTimeout(function() {
                    r && (c.support.transition ? (s.css("transition", "all " + o + "ms").addClass("vegas-transition-" + r + "-out"),
                    s.each(function() {
                        var n = s.find("video").get(0);
                        n && (n.volume = 1,
                        c._fadeOutSound(n, o))
                    }),
                    u.css("transition", "all " + o + "ms").addClass("vegas-transition-" + r + "-in")) : u.fadeIn(o));
                    for (var n = 0; n < s.length - 4; n++)
                        s.eq(n).remove();
                    c.trigger("walk");
                    c._slideShow()
                }, 100)
            }
            "undefined" == typeof this.settings.slides[t] && (t = 0);
            this.slide = t;
            var u, l, a, i, v, s = this.$elmt.children(".vegas-slide"), b = this.settings.slides[t].src, e = this.settings.slides[t].video, y = this._options("delay"), k = this._options("align"), d = this._options("valign"), f = this._options("cover"), g = this._options("color") || this.$elmt.css("background-color"), c = this, nt = s.length, r = this._options("transition"), o = this._options("transitionDuration"), h = this._options("animation"), p = this._options("animationDuration");
            "repeat" !== f && (f === !0 ? f = "cover" : f === !1 && (f = "contain"));
            ("random" === r || r instanceof Array) && (r = r instanceof Array ? this._random(r) : this._random(this.transitions));
            ("random" === h || h instanceof Array) && (h = h instanceof Array ? this._random(h) : this._random(this.animations));
            ("auto" === o || o > y) && (o = y);
            "auto" === p && (p = y);
            u = n('<div class="vegas-slide"><\/div>');
            this.support.transition && r && u.addClass("vegas-transition-" + r);
            this.support.video && e ? (i = e instanceof Array ? this._video(e) : this._video(e.src),
            i.loop = void 0 !== e.loop ? e.loop : !0,
            i.muted = void 0 !== e.mute ? e.mute : !0,
            i.muted === !1 ? (i.volume = 0,
            this._fadeInSound(i, o)) : i.pause(),
            a = n(i).addClass("vegas-video").css("background-color", g),
            this.support.objectFit ? a.css("object-position", k + " " + d).css("object-fit", f).css("width", "100%").css("height", "100%") : "contain" === f && a.css("width", "100%").css("height", "100%"),
            u.append(a)) : (v = new Image,
            l = n('<div class="vegas-slide-inner"><\/div>').css("background-image", "url(" + b + ")").css("background-color", g).css("background-position", k + " " + d),
            "repeat" === f ? l.css("background-repeat", "repeat") : l.css("background-size", f),
            this.support.transition && h && l.addClass("vegas-animation-" + h).css("animation-duration", p + "ms"),
            u.append(l));
            this.support.transition || u.css("display", "none");
            nt ? s.eq(nt - 1).after(u) : this.$elmt.prepend(u);
            c._timer(!1);
            i ? (4 === i.readyState && (i.currentTime = 0),
            i.play(),
            w()) : (v.src = b,
            v.onload = w)
        },
        shuffle: function() {
            for (var i, t, n = this.total - 1; n > 0; n--)
                t = Math.floor(Math.random() * (n + 1)),
                i = this.settings.slides[n],
                this.settings.slides[n] = this.settings.slides[t],
                this.settings.slides[t] = i
        },
        play: function() {
            this.paused && (this.paused = !1,
            this.next(),
            this.trigger("play"))
        },
        pause: function() {
            this._timer(!1);
            this.paused = !0;
            this.trigger("pause")
        },
        toggle: function() {
            this.paused ? this.play() : this.pause()
        },
        playing: function() {
            return !this.paused && !this.noshow
        },
        current: function(n) {
            return n ? {
                slide: this.slide,
                data: this.settings.slides[this.slide]
            } : this.slide
        },
        jump: function(n) {
            0 > n || n > this.total - 1 || n === this.slide || (this.slide = n,
            this._goto(this.slide))
        },
        next: function() {
            this.slide++;
            this.slide >= this.total && (this.slide = 0);
            this._goto(this.slide)
        },
        previous: function() {
            this.slide--;
            this.slide < 0 && (this.slide = this.total - 1);
            this._goto(this.slide)
        },
        trigger: function(n) {
            var t = [];
            t = "init" === n ? [this.settings] : [this.slide, this.settings.slides[this.slide]];
            this.$elmt.trigger("vegas" + n, t);
            "function" == typeof this.settings[n] && this.settings[n].apply(this.$elmt, t)
        },
        options: function(i, r) {
            var u = this.settings.slides.slice();
            if ("object" == typeof i)
                this.settings = n.extend({}, t, n.vegas.defaults, i);
            else {
                if ("string" != typeof i)
                    return this.settings;
                if (void 0 === r)
                    return this.settings[i];
                this.settings[i] = r
            }
            this.settings.slides !== u && (this.total = this.settings.slides.length,
            this.noshow = this.total < 2,
            this._preload())
        },
        destroy: function() {
            clearTimeout(this.timeout);
            this.$elmt.removeClass("vegas-container");
            this.$elmt.find("> .vegas-slide").remove();
            this.$elmt.find("> .vegas-wrapper").clone(!0).children().appendTo(this.$elmt);
            this.$elmt.find("> .vegas-wrapper").remove();
            this.settings.timer && this.$timer.remove();
            this.settings.overlay && this.$overlay.remove();
            this.elmt._vegas = null
        }
    };
    n.fn.vegas = function(n) {
        var t, u = arguments, i = !1;
        if (void 0 === n || "object" == typeof n)
            return this.each(function() {
                this._vegas || (this._vegas = new r(this,n))
            });
        if ("string" == typeof n) {
            if (this.each(function() {
                var r = this._vegas;
                if (!r)
                    throw new Error("No Vegas applied to this element.");
                "function" == typeof r[n] && "_" !== n[0] ? t = r[n].apply(r, [].slice.call(u, 1)) : i = !0
            }),
            i)
                throw new Error('No method "' + n + '" in Vegas.');
            return void 0 !== t ? t : this
        }
    }
    ;
    n.vegas = {};
    n.vegas.defaults = t;
    n.vegas.isVideoCompatible = function() {
        return !/(Android|webOS|Phone|iPad|iPod|BlackBerry|Windows Phone)/i.test(navigator.userAgent)
    }
}(window.jQuery || window.Zepto);






































function droidTest() {
    var n = navigator.userAgent.toLowerCase(), r = n.indexOf("android") > -1, t, i;
    if (r)
        return t = parseFloat(n.match(/android\s+([\d\.]+)/)[1]),
        i = t < 4.1 ? !0 : !1,
        i
}
function setIFrameSrc(n, t) {
    var r = document.getElementById(n), i = document.createElement("iframe"), u;
    i.id = r.getAttribute("id");
    i.src = t;
    i.setAttribute("width", "100%");
    $(".compatibility").hasClass("iosdevice") ? i.setAttribute("height", "80%") : i.setAttribute("height", "98%");
    i.setAttribute("frameborder", "0");
    u = r.parentNode;
    u.replaceChild(i, r)
}
function setReadMoreSrc(n, t) {
    var u = "#" + n, r = document.getElementById(n), i = document.createElement("a"), f;
    i.id = r.getAttribute("id");
    i.href = t;
    i.setAttribute("target", "_blank");
    f = r.parentNode;
    f.replaceChild(i, r);
    $(u).append('<div class="readmorebar">Read More<\/div>');
    $(u).show()
}
function setNavigation() {
    var t = window.location.href
      , n = t.indexOf("?") > 0 ? t.split("?")[0] : t;
    n = n.replace(/\/$/, "");
    n = decodeURIComponent(n);
    $(".sub-nav-item a[href]").each(function() {
        var t = $(this).attr("href").indexOf("?") > 0 ? $(this).attr("href").split("?")[0] : $(this).attr("href");
        if (typeof t == "undefined" || t === null )
            return !1;
        n.substring(0, t.length) === t && ($(this).closest("li").addClass("active"),
        $(this).closest(".more").addClass("active"))
    });
    $(".sub-nav-item.active a").each(function() {
        var n = $(this).attr("data-arrow-id");
        $("#line-arrow").addClass(n)
    })
}


$(document).ready(function() {
    var n, f, t, i, r, u;
    navigator.platform.match(/iPad/) || navigator.userAgent.match(/iPad/) ? $(".compatibility").addClass("ipad iosdevice") : navigator.platform.match(/iPhone/) || navigator.userAgent.match(/iPhone/) ? $(".compatibility").addClass("iphone iosdevice") : (navigator.platform.match(/iPod/) || navigator.userAgent.match(/iPod/)) && $(".compatibility").addClass("ipod iosdevice");
    navigator.appVersion.indexOf("MSIE 8.") != -1 && $(".compatibility").addClass("IE8");
    $("sup:contains('SM')").addClass("sm-fix");
    $(document).on("click", ".hover-delay", function(n) {
        function t() {
            window.location = my_link
        }
        n.preventDefault();
        my_link = $(this).attr("href");
        window.setTimeout(t, 500)
    });
    $(".popup-custom").click(function(n) {
        n.preventDefault();
        var t = $(window)
          , i = parseInt((t.width() - 545) / 2, 10)
          , r = parseInt((t.height() - 325) / 2, 10);
        window.open(this.href, "targetWindow", "resizable=yes", "location=no", "status=no", "scrollbars=1", "width=545", "height=325", "top=" + r, "left=" + i)
    });
    $(".star_ratings").click(function() {
        setIFrameSrc("iframeid", $(this).attr("href"));
        $(".compatibility").hasClass("iosdevice") && setReadMoreSrc("readmorebar", $(this).attr("href"));
        var n = $(this).attr("data-pt-name")
          , t = $(this).attr("data-pt-page");
        CHASE.analytics.trackModalLoad(n, t)
    });
    $(".product-detail #OfferDetails").on("click", function() {
        var n = $(this).attr("data-pt-name");
        CHASE.analytics.trackModalLoad(n, "product_page")
    });
    $(".product-detail .additional-item a").on("click", function() {
        var n = $(this).attr("data-pt-name");
        CHASE.analytics.trackModalLoad(n, "product_page")
    });
    $(".weblinkingPopup").each(function() {
        $(this).append("<span class='sr-only'> Opens Overlay <\/span>")
    });
    n = $("#ThirdPartyPopUp");
    n.on("show.bs.modal", function(t) {
        var r = $(t.relatedTarget)
          , u = r.attr("href")
          , i = $("#thirdPartyProceedLink");
        i.on("click", function() {
            n.modal("hide")
        }).attr("href", u);
        n.css("visibility", "visible").fadeIn(function() {
            i.focus()
        })
    });
    n.on("hidden.bs.modal", function() {
        $("#offerDetailsModal").hasClass("in") && $("body").addClass("modal-open")
    });
    $("a, button").click(function() {
        $lastClicked = $(this)
    });
    n.on("hidden.bs.modal", function() {
        $lastClicked && $($lastClicked).focus();
        droidTest() && ($(".modal").removeClass("android"),
        $(".last").removeClass("last"),
        $("body,html").css({
            overflow: "auto",
            height: "auto"
        }))
    });
    $("#offerDetailsModal").on("shown.bs.modal", function() {
        $("#OfferDetailsCloseModal").focus()
    });
    $("#benefitsModal").on("show.bs.modal", function() {
        setTimeout(function() {
            $("#AdditionalBenefitsCloseModal").focus()
        }, 500)
    });
    $("#addCardModal").on("show.bs.modal", function() {
        $(".compare-modal-item.selected-card").find(".icon-circle-check").attr("aria-hidden", "false")
    });
    $("#addCardModal").on("shown.bs.modal", function() {
        setTimeout(function() {
            $("#AddCardCloseModal").focus()
        }, 500)
    });
    $("#reviewsModal").on("shown.bs.modal", function() {
        setTimeout(function() {
            $("#ReviewsCloseModal").focus()
        }, 500)
    });
    $("#bannerCards .card-featured").each(function() {
        $(this).click(function() {
            return ext1 = $(this).find("a").attr("href"),
            window.open(ext1, "_self"),
            !1
        })
    });
    $(".section-wrap").each(function() {
        $(this).find(".container").last().addClass("last-item")
    });
    $("[data-track]").on("click", function() {
        ga("send", "event", "1130001", "" + $(this).attr("data-track") + "")
    });
    f = "ontouchend"in document;
    t = $(".secondary-product-links ");
    $(t).find(".colapse").on("click", function(n) {
        colapseExpandItem(this, n, enumColapseExpand.colapse)
    }).each(function() {
        $(this).parentsUntil("li").parent().find("ul").show()
    });
    $(t).find(".expand").on("click", function(n) {
        colapseExpandItem(this, n, enumColapseExpand.expand)
    }).each(function() {
        $(this).parentsUntil("li").parent().find("ul").hide()
    });
    i = $("nav li a").filter(function() {
        return $(this).attr("href").indexOf("controls/#") !== -1
    });
    i.length > 0 && i.each(function() {
        $(this).attr("href", $(this).attr("href").replace("controls/", ""));
        var n = $(this).parent();
        n.find("a").attr("data-menu-expand") === "true" && n.find(".panel-collapse").addClass("in")
    });
   
   
});
$.fn.newrow = function(n) {
    for (var i = [], t = 0; t < this.length; t += n)
        i.push(this.slice(t, t + n));
    return this.pushStack(i, "newrow", n)
}
;
$(".card-finder-additional > div > div > .additional-item").newrow(2).wrap('<div class="col-xs-12 no-padding item-row"><\/div>');
$("div > .compare-modal-item, .card-finder-additional > div > div > .additional-item").each(function() {
    $(this).siblings().size() < 1 && $(this).parent().addClass("last-item")
});
equalheight = function(n) {
    var r = 0, u = 0, i = [], t;
    $(n).each(function() {
        if (t = $(this),
        $(t).height("auto"),
        topPostion = t.position().top,
        u != topPostion) {
            for (currentDiv = 0; currentDiv < i.length; currentDiv++)
                i[currentDiv].height(r);
            i.length = 0;
            u = topPostion;
            r = t.height();
            i.push(t)
        } else
            i.push(t),
            r = r < t.height() ? t.height() : r;
        for (currentDiv = 0; currentDiv < i.length; currentDiv++)
            i[currentDiv].height(r)
    })
}
;
enumColapseExpand = {
    colapse: {
        removeClass: "colapse",
        addClass: "expand",
        iconUrl: "icon_see_more.png"
    },
    expand: {
        removeClass: "expand",
        addClass: "colapse",
        iconUrl: "icon_see_less.png"
    }
};
colapseExpandItem = function(n, t, i) {
    t.preventDefault();
    var r = $(n).parentsUntil("li").parent();
    $(n).off("click");
    i === enumColapseExpand.colapse ? $(r).find("ul").hide() : $(r).find("ul").show();
    $(n).removeClass(i.removeClass).addClass(i.addClass);
    $(n).find("img").attr("src", ImagesUrl + i.iconUrl);
    $(n).off("click").on("click", function(n) {
        colapseExpandItem(this, n, i === enumColapseExpand.colapse ? enumColapseExpand.expand : enumColapseExpand.colapse)
    })
}
,
function() {
    $.throttle = function(n, t) {
        var i;
        return function() {
            var r = arguments
              , u = this;
            i || (i = setTimeout(function() {
                return i = 0,
                n.apply(u, r)
            }, t))
        }
    }
}(this),
function(n, t) {
    function u(n, r) {
        t.$body = i;
        r.initialize();
        t.chaseMarketplace.modules[r.id] = r
    }
    var i = n("body")
      , r = n(t);
    n.chaseMarketplace || (n.chaseMarketplace = {});
    t.chaseMarketplace || (t.chaseMarketplace = {
        modules: {}
    });
    t.C3 || (t.C3 = {},
    t.C3.compare = {},
    t.C3.tags = {});
    n(document).on("chaseMarketplaceModuleInit", u);
    r.load(function() {
        i.fadeIn("slow")
    })
}(jQuery, window),
function(n, t) {
    "use strict";
    function i(t, i) {
        var r = function() {}
        ;
        r = n.extend(r.prototype, {
            id: t,
            initialize: function() {
                r.ChaseMarketplaceModule();
                r.init()
            },
            ChaseMarketplaceModule: function() {
                r.chaseMarketplaceModuleCtrl = i;
                r.init = function(t) {
                    var i;
                    i = typeof t != "undefined" && t ? t : n("[data-module=" + r.id + "]");
                    i.length > 0 && i.each(function() {
                        r.chaseMarketplaceModuleCtrl(n(this));
                        n(this).addClass("module--initialized")
                    })
                }
            }
        });
        n(document).trigger("chaseMarketplaceModuleInit", r)
    }
    t.createModule = i
}(jQuery, window.chaseMarketplace),
function(n, t) {
    "use strict";
    function i() {
        function r(t, r) {
            n[t] || (n[t] = []);
            var u = (++i).toString();
            return n[t].push({
                token: u,
                func: r
            }),
            u
        }
        function u(t) {
            var i, r, u;
            for (i in n)
                if (n[i])
                    for (r = 0,
                    u = n[i].length; r < u; r++)
                        if (n[i][r].token === t)
                            return n[i].splice(r, 1),
                            t;
            return !1
        }
        function f(t, i) {
            return n[t] ? (setTimeout(function() {
                for (var r = n[t], u = r ? r.length : 0; u--; )
                    r[u].func(t, i)
            }, 0),
            !0) : !1
        }
        var n = {}
          , i = 0;
        t.subscribe = r;
        t.unsubscribe = u;
        t.publish = f
    }
    i()
}(jQuery, window.chaseMarketplace),
function(n, t) {
    "use strict";
    function i() {
        function u(n) {
            n ? (r = i.scrollTop(),
            t.addClass("_fixed")) : (t.removeClass("_fixed"),
            i.scrollTop(r))
        }
        var t = n("body")
          , i = n(window)
          , r = 0;
        return {
            fixBody: u,
            largeBreakpoint: 1279,
            mediumBreakpoint: 999,
            smallBreakpoint: 679
        }
    }
    t.utils = i();
    n.fn.hasScrollBar = function() {
        return this.get(0).scrollHeight < this.outerHeight()
    }
    ;
    n.fn.getScrollBarHeight = function() {
        return this.outerHeight() - this.get(0).scrollHeight
    }
}(jQuery, window.chaseMarketplace),
function(n, t) {
    "use strict";
    function i(i) {
        function p() {
            nt();
            window.setTimeout(function() {
                l(h())
            }, 0);
            window.setTimeout(function() {
                e()
            }, 250);
            w()
        }
        function w() {
            n(document).on("keyup.keyUpOverlay", function(n) {
                n.which === 39 ? (n.preventDefault(),
                a(1),
                e()) : n.which === 37 ? (n.preventDefault(),
                a(-1),
                e()) : n.which === 27 && closeOverlay()
            })
        }
        function a(n) {
            var t = (v() + n) % s.length;
            c(t)
        }
        function v() {
            return h().index()
        }
        function h() {
            return s.filter(".benefits_slide--active")
        }
        function c(n) {
            var t = s.removeClass("benefits_slide--active").attr("aria-hidden", "true").eq(n);
            f.removeClass("scroll-nav_item--active").eq(n).addClass("scroll-nav_item--active");
            t.addClass("benefits_slide--active").attr("aria-hidden", "false");
            window.setTimeout(function() {
                l(t)
            }, 0)
        }
        function l(n) {
            n.hasClass("benefits_slide--right-rail")
        }
        function b() {
            r.scrollLeft() === 0 ? u.addClass("scroll-nav_arrow--inactive") : u.removeClass("scroll-nav_arrow--inactive");
            r.scrollLeft() >= r[0].scrollWidth - r[0].clientWidth ? o.addClass("scroll-nav_arrow--inactive") : o.removeClass("scroll-nav_arrow--inactive")
        }
        function k() {
            var t = 0
              , i = [0];
            return f.each(function() {
                t += n(this).outerWidth();
                i.push(t)
            }),
            i
        }
        function e(n) {
            var t = n || v()
              , i = k()
              , f = i[t] + (i[t + 1] - i[t]) / 2 - window.innerWidth / 2 + u.outerWidth();
            r.stop().animate({
                scrollLeft: f
            }, "slow")
        }
        function y(n) {
            var t = r.scrollLeft();
            r.stop().animate({
                scrollLeft: t + n
            }, "fast")
        }
        function d() {
            s.each(function() {
                var i = n(this);
                t.subscribe(i.attr("id") + "_open", function() {
                    c(i.index());
                    p()
                })
            })
        }
        function g() {
            f.on("click", function() {
                var t = n(this).index();
                c(t);
                e(t)
            });
            u.on("click", function() {
                y(f.width() * -2)
            });
            o.on("click", function() {
                y(f.width() * 2)
            });
            n(window).on("resize", n.throttle(function() {
                window.setTimeout(function() {
                    l(h())
                }, 0);
                window.setTimeout(function() {
                    e()
                }, 500)
            }, 500));
            r.on("scroll", b)
        }
        function nt() {
            if (r.hasScrollBar()) {
                var n = u.height() + r.getScrollBarHeight();
                u.add(o).css("height", n + "px")
            }
        }
        function tt() {
            g();
            d()
        }
        var f = i.find(".scroll-nav_item")
          , u = i.find(".scroll-nav_arrow--left")
          , o = i.find(".scroll-nav_arrow--right")
          , r = i.find(".scroll-nav_scroll-container")
          , s = i.find(".benefits_slide")
          , it = n(window);
        tt()
    }
    t.createModule("benefits", i)
}(jQuery, window.chaseMarketplace),
function(n, t) {
    "use strict";
    function i(n) {
        function i() {
            t.slick({
                infinite: !0,
                dots: !0
            })
        }
        var t = n.find(".browse-cards_carousel");
        i()
    }
    t.createModule("browse-cards", i)
}(jQuery, window.chaseMarketplace),
function(n, t) {
    "use strict";
    function i() {
        function t() {
            function y() {
                n(window).scroll(function() {
                    e = n(".sub-nav").offset().top - h;
                    t = n(this).scrollTop();
                    l = 145 - t / 1;
                    t <= e && t > 0 ? (i.removeClass("hide"),
                    f.css({
                        width: l + "px",
                        opacity: "0.4"
                    }),
                    i.removeClass("less"),
                    u.removeClass("fixthis")) : t <= 0 ? (i.removeClass("hide"),
                    f.css("width", "145px"),
                    f.css("opacity", "1"),
                    i.removeClass("less"),
                    u.removeClass("fixthis")) : t > e && t < s ? (i.addClass("less"),
                    u.removeClass("fixthis")) : t < o ? (i.removeClass("hide"),
                    u.removeClass("up")) : t < a ? u.removeClass("fixthis") : t > s && (f.css("width", "0"),
                    i.addClass("hide"),
                    u.addClass("fixthis"),
                    u.addClass("up"),
                    i.addClass("less"));
                    o = t
                })
            }
            function p() {
                n(window).scroll(function() {
                    e = n(".sub-nav").offset().top - h;
                    t = n(this).scrollTop();
                    l = 145 - t / 1;
                    t <= e && t > 0 ? (i.removeClass("hide"),
                    f.css({
                        width: l + "px"
                    })) : t <= 0 ? (i.removeClass("hide"),
                    f.css("width", "145px")) : t < o ? (i.removeClass("hide"),
                    u.removeClass("up")) : t > s && (f.css("width", "0"),
                    i.addClass("hide"),
                    u.addClass("up"));
                    o = t
                })
            }
            var o, r = n(".sub-nav"), a = r.offset() ? r.offset().top : 0, s = r.offset() ? r.offset().top - 50 : 0, h = 120, e = r.offset() ? r.offset().top - h : 0, f = n(".logo-chase-text"), i = n("#header"), u = r, w = n("#all-cards-box"), v = n("body").attr("class"), c = n(".hero"), t, l;
            setTimeout(function() {
                s = r.offset() ? r.offset().top - 50 : 0
            }, 1e3);
            switch (v) {
            case "sub-nav-after":
                y();
                break;
            case "sub-nav-before":
                p()
            }
            h = c.css("height") == "570px" ? 350 : c.css("height") == "210px" || c.css("height") == "230px" || c.css("height") == "300px" ? 80 : 350
        }
        n(window).load(function() {
            n("#home").length > 0 || t()
        })
    }
    t.createModule("header", i)
}(jQuery, window.chaseMarketplace),
function(n, t) {
    "use strict";
    function i() {
        function t() {
            var t = n("#menu-area")
              , u = n(".subtoggle")
              , f = n(".subtogglecontent")
              , i = n(".sub-subtoggle")
              , r = n(".sub-subtogglecontent");
            n("#menu-link").click(function(i) {
                i.preventDefault();
                n("body").addClass("onmenuactive");
                t.fadeIn();
                t.addClass("animate");
                t.find("#close-button").focus();
                n("#close-button-bottom").on("keydown", function(t) {
                    t.which == 9 && t.shiftKey == 0 && (t.preventDefault(),
                    n("#close-button").focus())
                })
            });
            n("#global-close , #close-button, #close-button-bottom").click(function(i) {
                i.preventDefault();
                n("body").removeClass("onmenuactive");
                t.fadeOut();
                t.removeClass("animate");
                n("#menu-link").focus()
            });
            n("#first").slideDown();
            u.click(function(t) {
                t.preventDefault();
                n(this).hasClass("active") ? (n(this).removeClass("active"),
                n(this).next(".subtogglecontent").slideUp()) : (n(this).next(".subtogglecontent").slideDown(),
                n(this).addClass("active"))
            });
            n("#firstsub").slideDown();
            i.click(function(t) {
                t.preventDefault();
                n(this).hasClass("active") ? (i.removeClass("active"),
                r.slideUp()) : (i.removeClass("active"),
                r.slideUp(),
                n(this).next(".sub-subtogglecontent").slideDown(),
                n(this).addClass("active"))
            })
        }
        t()
    }
    t.createModule("menu-area", i)
}(jQuery, window.chaseMarketplace),
function(n, t) {
    "use strict";
    function i(i) {
        function u() {
            s = a.height();
            o = i.height();
            h = o - s;
            c = y.offset().top
        }
        function f() {
            window.innerWidth > t.utils.mediumBreakpoint ? (window.scrollY || document.documentElement.scrollTop) > h ? i.addClass("product-detail--not-fixed") : i.removeClass("product-detail--not-fixed") : (window.scrollY || document.documentElement.scrollTop) > c ? r.addClass("product-detail_sticky-header--show") : r.removeClass("product-detail_sticky-header--show")
        }
        function p() {
            v.on("click", function() {
                var i = n(this).attr("data-overlay-id");
                t.publish(i + "_open")
            })
        }
        function w() {
            var n = e.scrollTop();
            n > l ? r.removeClass("_slide-down") : r.addClass("_slide-down");
            l = n
        }
        function b() {
            p();
            u();
            f();
            setTimeout(function() {
                u();
                f()
            }, 800);
            e.on("scroll", function(n) {
                f();
                w(n)
            }).on("resize", n.throttle(u, 200))
        }
        var e = n(window), a = i.find("#leftPanel"), v = i.find(".additional .link-arrow"), y = i.find("#ApplyNow"), r = n("#header"), o, s, h, c, l = 0;
        b()
    }
    t.createModule("product-detail", i)
}(jQuery, window.chaseMarketplace),
function(n, t) {
    "use strict";
    function i(i) {
        function s() {
            a = p.height();
            v = w.height();
            l = i.height();
            b = l - a - v;
            o = window.innerWidth > t.utils.mediumBreakpoint ? 400 : 300
        }
        function h() {
            (window.scrollY || document.documentElement.scrollTop) > o ? (e.addClass("compare-page_sticky-header--show"),
            r.addClass("compare-page_sticky-header--show"),
            u.addClass("compare-page_sticky-header--show"),
            f.addClass("compare-page_sticky-header--show"),
            equalheight(".compare-equal-mobile"),
            equalheight(".compare-equal-mobile-sticky"),
            equalheight(".compare-equal-desktop"),
            equalheight(".compare-equal-desktop-sticky")) : (e.removeClass("compare-page_sticky-header--show"),
            r.removeClass("compare-page_sticky-header--show"),
            u.removeClass("compare-page_sticky-header--show"),
            f.removeClass("compare-page_sticky-header--show"),
            equalheight(".compare-equal-mobile"),
            equalheight(".compare-equal-mobile-sticky"),
            equalheight(".compare-equal-desktop"),
            equalheight(".compare-equal-desktop-sticky"))
        }
        function k() {
            var n = c.scrollTop();
            n > y ? (e.removeClass("_slide-down"),
            r.removeClass("_slide-down"),
            u.removeClass("_slide-down"),
            f.removeClass("_slide-down")) : (e.addClass("_slide-down"),
            r.addClass("_slide-down"),
            u.addClass("_slide-down"),
            f.addClass("_slide-down"));
            y = n
        }
        function d() {
            s();
            h();
            setTimeout(function() {
                s();
                h()
            }, 800);
            c.on("scroll", function(t) {
                h();
                n(".slider-for").slick("setPosition");
                k(t)
            }).on("resize", n.throttle(s, 200))
        }
        var c = n(window), r = i.find("#compare-slider-nav"), u = i.find("#compare-top-row-mobile"), f = i.find("#compare-top-row-desktop"), e = n("#header"), p = n("#bottomPanel"), w = n("footer"), l, a, v, b, o, y = 0;
        d()
    }
    t.createModule("compare-page", i)
}(jQuery, window.chaseMarketplace),
function(n, t) {
    "use strict";
    function i(t) {
        function u() {
            r.each(function() {
                var t = n(this), r = t.html(), u = r.split(" "), f;
                if (u.length > i) {
                    t.attr("data-text", r);
                    t.html(u.slice(0, i).join(" "));
                    f = t.append('<span>... <a class="read-more" href="javascript:;">Read more<\/a><\/span>');
                    t.find(".read-more").on("click", function() {
                        t.html(r)
                    })
                }
            })
        }
        function f() {
            u()
        }
        var r = t.find(".review-text")
          , i = 35;
        f()
    }
    t.createModule("reviews", i)
}(jQuery, window.chaseMarketplace),
function(n, t) {
    "use strict";
    function i() {
        function t() {
            var t = n(".sub-nav").offset().top;
            n(".more-cat").click(function(t) {
                t.preventDefault();
                n(".more").hasClass("ativado") ? (n(".more").removeClass("drop"),
                n(".more").removeClass("active"),
                n(".more-menu").fadeOut("fast"),
                setTimeout(function() {
                    n(".more").removeClass("ativado")
                }, 100)) : (n(".more").addClass("drop"),
                n(".more").addClass("active"),
                n(".more-menu").fadeIn("fast"),
                setTimeout(function() {
                    n(".more").addClass("ativado")
                }, 100))
            });
            n(".selected").click(function(i) {
                i.preventDefault();
                t = n(".sub-nav").offset().top;
                n("body").addClass("onmenuactive");
                n("#header").addClass("everhide");
                n(".sub-nav").addClass("neverup");
                n(".mobile-nav").removeClass("showNav");
                n(".category-selector-mobile").addClass("showNav");
                n("#close-button-category-bottom").on("keydown", function(t) {
                    t.which == 9 && t.shiftKey == 0 && (t.preventDefault(),
                    n("#close-button-category").focus())
                });
                calculateMobileMenuArea()
            });
            n("#close-button-category, #close-button-category-bottom").click(function(t) {
                t.preventDefault();
                n("body").removeClass("onmenuactive");
                n(".category-selector-mobile").removeClass("showNav");
                n(".mobile-nav").addClass("showNav");
                n("#header").removeClass("everhide");
                n(".sub-nav").removeClass("neverup");
                n("#choose-cat-btn").focus()
            })
        }
        t()
    }
    t.createModule("sub-nav", i)
}(jQuery, window.chaseMarketplace);
chosecategorysize = 70;
$lastClicked = null ;
windowsize = $(window).width();
$(window).load(function() {
    equalheight(".compare-equal-mobile");
    equalheight(".compare-equal-mobile-sticky");
    equalheight(".compare-equal-desktop");
    equalheight(".compare-equal-desktop-sticky");
    equalheight(".compare-equal-mobile-btm");
    equalheight(".compare-equal-desktop-btm");
    equalheight(".sq-wrap");
    equalheight(".banner-title");
    windowsize = $(window).width()
});
$(window).resize(function() {
    equalheight(".compare-equal-mobile");
    equalheight(".compare-equal-mobile-sticky");
    equalheight(".compare-equal-desktop");
    equalheight(".compare-equal-desktop-sticky");
    equalheight(".compare-equal-mobile-btm");
    equalheight(".compare-equal-desktop-btm");
    equalheight(".sq-wrap");
    equalheight(".banner-title");
    windowsize = $(window).width()
});
$("a, button").click(function() {
    $lastClicked = $(this)
});
C3.utils = {
    defaults: {
        const_Undefined: "undefined",
        const_Event_Click: "click",
        queryString: null ,
        timeoutId: null
    },
    messageConfig: {
        html: null ,
        htmlMessageContainerId: null ,
        htmlMessageContainerIdOverlay: null ,
        htmlButtonCloseId: null ,
        hasCloseButton: !1,
        closeTimeout: 8
    },
    arrayRemoveZeros: function(n) {
        return n.filter(function(n) {
            return n !== "0"
        })
    },
    arrayFirstItem: function(n) {
        return n.sort(function(n, t) {
            return t - n
        })[0]
    },
    arrayAsStringFirstItem: function(n) {
        return C3.utils.arrayFirstItem(n.split(","))
    },
    listRemove: function(n, t) {
        var r = n.split(","), u = r.indexOf(t), i, f;
        return u == -1 ? r.toString() : (i = r.slice(0, u),
        f = r.slice(++u, r.length),
        i.push.apply(i, f),
        i.push.apply(i, [0]),
        i.toString())
    },
    queryStringUpdateParameter: function(n) {
        var u = "?" + this.defaults.queryString, i = C3.uriParser.parseUri("?" + this.defaults.queryString), t = "", r;
        i.queryKey[n] !== undefined && delete i.queryKey[n];
        for (r in i.queryKey)
            t += "&" + r + "=" + i.queryKey[r];
        return t.indexOf(this.defaults.const_Undefined) != -1 && (t = t.replace(this.defaults.const_Undefined, "")),
        t
    },
    queryStringUpdateParameterKV: function(n, t, i) {
        var r = new RegExp("([?&])" + t + "=.*?(&|$)","i")
          , u = n.indexOf("?") !== -1 ? "&" : "?";
        return n.match(r) ? n.replace(r, "$1" + t + "=" + i + "$2") : n + u + t + "=" + i
    },
    queryStringEscape: function(n) {
        return n.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")
    },
    queryStringGetParameterByName: function(n, t) {
        t || (t = window.location.href);
        n = n.replace(/[\[\]]/g, "\\$&");
        var r = new RegExp("[?&]" + n + "(=([^&#]*)|&|#|$)")
          , i = r.exec(t);
        return i ? i[2] ? decodeURIComponent(i[2].replace(/\+/g, " ")) : "" : null
    },
    queryStringRemoveURLParameter: function(n, t) {
        var u = n.split("?"), f, i, r;
        if (u.length >= 2) {
            for (f = encodeURIComponent(t) + "=",
            i = u[1].split(/[&;]/g),
            r = i.length; r-- > 0; )
                i[r].lastIndexOf(f, 0) !== -1 && i.splice(r, 1);
            return u[0] + (i.length > 0 ? "?" + i.join("&") : "")
        }
        return n
    },
    reloadPage: function(n, t, i) {
        function r() {
            return window.SiteUrl.indexOf("localhost") !== -1
        }
        return location.href = encodeURI("/" + (r() ? n : t) + "?" + i),
        !1
    },
    refreshPage: function() {
        return location.href = encodeURI(location.href),
        !1
    },
    showMessage: function(n, t) {
        var r = this.messageConfig.htmlMessageContainerId, f = this.messageConfig.htmlMessageContainerIdOverlay, e = this.messageConfig.closeTimeout, i, u;
        t ? t.append(this.messageConfig.html) : $(this.messageConfig.html).appendTo("body");
        C3.utils.defaults.timeoutId && (clearTimeout(C3.utils.defaults.timeoutId),
        C3.utils.defaults.timeoutId = null );
        C3.utils.defaults.timeoutId = setTimeout(function() {
            i();
            $("#" + this.messageConfig.htmlButtonCloseId)
        }, e * 1e3);
        $("body").on("click touchstart", function(n) {
            if (n.preventDefault(),
            $(n.target).is("button.compare-cards-button"))
                return window.location.href = $(n.target).attr("data-link"),
                i(),
                !1;
            if ($("body").hasClass(C3.compare.defaults.classIgnore)) {
                $("body").removeClass(C3.compare.defaults.classIgnore);
                return
            }
            var t = n.target || n.srcElement;
            if (!(["tooltip-title", "tooltip-content"].indexOf(t.className) > -1 || t.className.split(" ").indexOf("message-container") > -1)) {
                while ($("#" + r).html())
                    i();
                $("body").off("click touchstart")
            }
        });
        $(".compare-popup-modal_close").on("click touchstart", function(n) {
            for (n.preventDefault(); $("#" + r).html(); )
                i()
        });
        i = function() {
            u(r, f);
            setTimeout(function() {
                u(r, f)
            }, 0);
            $(".compare-popup-modal_close").off("click touchstart")
        }
        ;
        u = function(n, t) {
            clearTimeout(C3.utils.defaults.timeoutId);
            $("#" + n).remove();
            $("#" + t).remove();
            try {
                $($lastClicked).focus()
            } catch (i) {}
        }
    },
    stringToArray: function(n) {
        return JSON.parse("[" + n + "]")
    },
    stringToArraySorted: function(n) {
        return C3.utils.stringToArray(n).sort(function(n, t) {
            return parseInt(t) - parseInt(n)
        })
    },
    updateUrls: function() {
        $.grep($("body a"), function(n) {
            var i = $(n)
              , t = i.attr("href");
            t != null && t.indexOf("#") > 0 && new RegExp("^" + C3.utils.queryStringEscape(RootUrl.slice(0, -1)) + "/","i").test(t) && (i.hasClass("ignoreUrlUpdate") || i.attr("href", "#" + t.split("#")[1]))
        })
    }
};
C3.uriParser = {
    parseUri: function(n) {
        var t = {
            strictMode: !1,
            key: ["source", "protocol", "authority", "userInfo", "user", "password", "host", "port", "relative", "path", "directory", "file", "query", "anchor"],
            q: {
                name: "queryKey",
                parser: /(?:^|&)([^&=]*)=?([^&]*)/g
            },
            parser: {
                strict: /^(?:([^:\/?#]+):)?(?:\/\/((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?))?((((?:[^?#\/]*\/)*)([^?#]*))(?:\?([^#]*))?(?:#(.*))?)/,
                loose: /^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/
            }
        };
        for (m = t.parser[t.strictMode ? "strict" : "loose"].exec(n),
        uri = {},
        i = 14; i--; )
            uri[t.key[i]] = m[i] || "";
        return uri[t.q.name] = {},
        uri[t.key[12]].replace(t.q.parser, function(n, i, r) {
            i && (uri[t.q.name][i] = r)
        }),
        uri
    },
    parseQueryString: function(n) {
        var r = {}, u, t, i, f, e;
        for (u = n.split("&"),
        i = 0,
        f = u.length; i < f; i++)
            t = u[i].split("="),
            e = r[t[0]],
            r[t[0]] = t[1];
        return r
    },
    convertQueryObjectToString: function(n) {
        var i = [];
        for (var t in n)
            n.hasOwnProperty(t) && n[t] != "" && i.push(t + "=" + n[t]);
        return i.join("&")
    }
},
function() {
    _EnumCompareAction = Object.freeze({
        ADD: 0,
        REMOVE: 1,
        INIT: 2
    });
    _EnumCardListType = Object.freeze({
        PERSONAL: 0,
        BUSINESS: 1,
        UNKNOWN: 2
    });
    _CardData = {
        id: null ,
        isSelectable: !1
    };
    _Defaults = {
        idCompareCardList: "CompareCardList",
        classAdded: "added",
        classCompareCards: "compare-cards",
        classCompareButton: "compare-btn",
        classDisabled: "disabled",
        classCompareCardFooter: "compare-card-footer",
        classPanelCollapse: "panel-collapse",
        htmlUpdateCard: "<div id='updateCard'><\/div>",
        messageCompareBusinessCaradToPersonalCardList: "<div class='tooltip-title'>Want to compare business cards?<\/div><p class='tooltip-content'>You are currently comparing personal cards. Please clear your selection to explore our business options.<\/p>",
        messageComparePersonalCaradToBusinessCardList: "<div class='tooltip-title'>Want to compare personal cards?<\/div><p class='tooltip-content'>You are currently comparing business cards. Please clear your selection to explore our consumer options.<\/p>",
        messageCardLimit: "<div class='tooltip-title'>Want to add this card?<\/div><p class='tooltip-content'>You can compare up to three cards at a time. Remove one of your selections to add this card.<\/p>",
        messageCardLimitCompareCard: "<div class='tooltip-title'>Start Comparing<\/div><p class='tooltip-content'>You've added the maximum number of cards to your comparison.<\/p>",
        messageTimeout: 8,
        urlPage_CompareCards: "CompareCards.aspx",
        urlPage_CompareCardsVanity: "credit-cards/compare-cards",
        urlParam_List: "list"
    };
    _AddCard = function(n) {
        var i = C3.compare.getCompareCardList(), t = i.val().split(","), u = t.indexOf("0"), r;
        t[u] = n;
        r = t.toString();
        i.val(r)
    }
    ;
    _CompareCardUpdateCard = function(n) {
        var t = $("#updateCard").closest("td"), i;
        t.empty();
        i = $("." + _Defaults.classCompareCardFooter + " >input").filter(function() {
            return $(this).val() === n.toString()
        });
        $(i.eq(0).parent().html()).appendTo(t);
        n != "0" && $("<div class='col-md-12 no-padding remove-rel'><div class='col-md-4 no-padding remove-wrap'><button class='text-center remove' tabindex='0'><span class='remove-x'>x<\/span><span class='remove-txt'><b>x<\/b> Remove<\/span> <span class='sr-only'>this card from compare<\/span><\/button><\/div><\/div>").appendTo(t);
        t.find("." + C3.compare.defaults.classRemove).on(C3.utils.defaults.const_Event_Click, C3.compare.compareCardRemoveCard)
    }
    ;
    _DisableButton = function(n) {
        var t = _GetCardList(n), i;
        if (t == null || t[0] === null ) {
            $("." + _Defaults.classCompareButton).each(function() {
                var n = $(this);
                n.hasClass(_Defaults.classDisabled) && n.removeClass(_Defaults.classDisabled)
            });
            return
        }
        if (t.length === parseInt(MaxCompareCards)) {
            $("." + _Defaults.classCompareButton).each(function() {
                var n = $(this)
                  , i = parseInt(n.find("input").val());
                n.removeClass(_Defaults.classDisabled).removeClass(_Defaults.classAdded);
                $.inArray(i, t) != -1 ? n.addClass(_Defaults.classAdded) : n.addClass(_Defaults.classDisabled)
            });
            return
        }
        i = _GetCardType(t[0]);
        $("." + _Defaults.classCompareButton).each(function() {
            var n = $(this)
              , r = parseInt(n.find("input").val());
            n.removeClass(_Defaults.classDisabled).removeClass(_Defaults.classAdded);
            $.inArray(r, t) != -1 && n.addClass(_Defaults.classAdded);
            _GetCardType(r) !== i && n.addClass(_Defaults.classDisabled)
        })
    }
    ;
    _GetCardList = function(n) {
        var i, r, t, u, f;
        if (n == null )
            return null ;
        for (i = C3.utils.stringToArraySorted(n.replace(/^0+|,0+/g, "").match(/\d+|\d+$,/g)),
        r = _EnumCardListType.UNKNOWN,
        t = 0; t < i.length; t++)
            if ((u = i[t],
            u === 0) || (f = _GetCardType(u),
            t == 0 && (r = f),
            f !== r))
                return null ;
        return i
    }
    ;
    _GetCardData = function(n) {
        var t = n.closest('div[id^="cardButtons"]');
        return t.length == 0 ? (t = n.closest("td"),
        _CardData.id = t.find("input").val(),
        _CardData.isSelectable = !0) : _CardData.id = t.parent().find("input").val(),
        t.length == 0 && (_CardData.id = -1),
        _CardData
    }
    ;
    _GetAction = function(n) {
        return $(n).hasClass(_Defaults.classAdded) ? _EnumCompareAction.REMOVE : _EnumCompareAction.ADD
    }
    ;
    _GetCardsCount = function() {
        var n = C3.compare.getCompareCardList().val().replace(/0/g, "").match(/\d+|\d+$,/g);
        return n == null ? 0 : n.length
    }
    ;
    _GetClassName = function(n) {
        return _Defaults.classCompareCards + "-" + n
    }
    ;
    _GetCardType = function(n) {
        return n === 0 ? _EnumCardListType.UNKNOWN : $.inArray(parseInt(n), BusinessCards) != -1 ? _EnumCardListType.BUSINESS : _EnumCardListType.PERSONAL
    }
    ;
    _IsEmptyCardList = function(n) {
        return n.split(",").sort(function(n, t) {
            return parseInt(t) - parseInt(n)
        })[0] === "0"
    }
    ;
    _IsValidCard = function(n, t, i, r) {
        var u = C3.compare.getCompareCardList().val();
        if (!u || _IsEmptyCardList(u))
            return !0;
        var s = /,0|^0,/g.test(u)
          , c = _GetCardsCount()
          , f = "compareAltMessage";
        if (!s)
            return windowsize < 680 ? _ShowMessage(_Defaults.messageCardLimit, t, i, !0, null , r, f) : _ShowMessage(_Defaults.messageCardLimit, t, i, !1, null , r, f),
            !1;
        var h = C3.utils.arrayAsStringFirstItem(u)
          , e = _GetCardType(h)
          , o = _GetCardType(n.val());
        return e !== o && (e === _EnumCardListType.PERSONAL ? _ShowMessage(_Defaults.messageCompareBusinessCaradToPersonalCardList, t, i, !1, null , r, f) : _ShowMessage(_Defaults.messageComparePersonalCaradToBusinessCardList, t, i, !1, null , r, f)),
        e === o
    }
    ;
    _RemoveCard = function(n, t) {
        _UpdateSelectedListCardList(n.val(), t);
        _UpdateUrls()
    }
    ;
    _SetCompareCardList = function(n) {
        if (n.action === _EnumCompareAction.ADD) {
            _UpdateSelectedListCardList(n.id, "0", _EnumCompareAction.ADD);
            return
        }
        _RemoveCard(C3.compare.getCompareCardList(), n.id)
    }
    ;
    _SetCollapseComparePanel = function() {
        var t = C3.compare.getCompareCardList().val(), i = C3.utils.arrayAsStringFirstItem(t), n;
        if (!t || i === "0") {
            $("." + _Defaults.classPanelCollapse + ':not(".in")').collapse("show");
            return
        }
        n = _GetCardType(i);
        $(".panel div[data-accordion-id=" + (n === _EnumCardListType.BUSINESS ? 2 : 1) + "]").closest(".panel").find("." + _Defaults.classPanelCollapse).collapse("show");
        $(".panel div[data-accordion-id=" + (n === _EnumCardListType.BUSINESS ? 1 : 2) + "]").closest(".panel").find("." + _Defaults.classPanelCollapse).collapse("hide")
    }
    ;
    _ShowMessage = function(n, t, i, r, u, f, e) {
        $("body").hasClass("compare-cards") && $("body").addClass(C3.compare.defaults.classIgnore);
        C3.utils.messageConfig.html = '<div id="messageOverlay" aria-hidden="false"><\/div><div id="containerMessage" class="message-container text-center ' + e + '" style="top:' + (t + 30) + "px; left:" + (i - 330) + 'px;"><a href="javascript:;" id="ComparePopupCloseModal" class="compare-popup-modal_close" data-dismiss="modal" aria-label="Close" tabindex="0">Close<\/a> <span class="sr-only">Close Overlay<\/span><span>' + n + "<\/span><br />" + (r ? u == null ? '<button id="message-close" class="promo-btn" tabindex="0">Continue<\/button>' : u : "") + "<\/div>";
        C3.utils.messageConfig.htmlMessageContainerId = "containerMessage";
        C3.utils.messageConfig.htmlMessageContainerIdOverlay = "messageOverlay";
        C3.utils.messageConfig.htmlButtonCloseId = "message-close";
        C3.utils.messageConfig.hasCloseButton = r;
        setTimeout(function() {
            $(".compare-popup-modal_close").focus()
        }, 100);
        C3.utils.messageConfig.closeTimeout = _Defaults.messageTimeout;
        C3.utils.showMessage(n, f)
    }
    ;
    _ShowMessageUnderMenu = function(n, t) {
        var i = '<button id="message-close" class="promo-btn compare-cards-button" tabindex="0" data-link="' + t.find("a").attr("href") + '">Compare Cards<\/button>';
        _ShowMessage(_Defaults.messageCardLimitCompareCard, 60, 90, !0, i, t, "compareCardLimit")
    }
    ;
    _UrlGetCardList = function() {
        var r = C3.utils.queryStringGetParameterByName(_Defaults.urlParam_List), t, n, i;
        if (r) {
            t = r.split(",");
            n = "0,0,0".split(",");
            for (i in t)
                if (AllCards.indexOf(parseInt(t[i])) > -1 && (n = _UpdateSelecteCards(t[i], "0", n, _EnumCompareAction.ADD)),
                n.indexOf("0") < 0)
                    return n.toString();
            return n.toString()
        }
    }
    ;
    _UpdateMenuLiControl = function(n, t) {
        var u = _GetCardsCount(), f = _GetClassName(u), e = n.attr("class"), r = e.match(/compare-cards-\d/g), i;
        if (r != null )
            for (i = 0; i < r.length; i++)
                n.removeClass(r[i]);
        n.addClass(f);
        $(".compare-btn .compare-cards-1").html("(1 of 3) cards");
        $(".compare-btn .compare-cards-2").html("(2 of 3) cards");
        $(".compare-btn .compare-cards-3").html("(3 of 3) cards");
        t || u !== parseInt(MaxCompareCards) || n.hasClass("sub-nav-item") && _ShowMessageUnderMenu(C3.compare.getCompareCardList().val(), n)
    }
    ;
    _UpdateMenuCount = function(n) {
        var t = $("." + _Defaults.classCompareCards);
        t.each(function() {
            _UpdateMenuLiControl($(this), n)
        })
    }
    ;
    _UpdateSelecteCards = function(n, t, i, r) {
        if (!(i.indexOf(t) < 0))
            return i[i.indexOf(t)] = r === _EnumCompareAction.ADD ? n : 0,
            i
    }
    ;
    _UpdateSelectedListCardList = function(n, t, i) {
        var r = C3.compare.getCompareCardList()
          , u = _UpdateSelecteCards(n, t, r.val().split(","), i);
        r.val(u.toString())
    }
    ;
    _UpdateUrls = function(n) {
        var t = C3.compare.getCompareCardList().val().replace(/^0+|,0+/g, "").replace(/^,|,$/g, "");
        $.grep($("body a"), function(i) {
            var u = $(i)
              , r = u.attr("href");
            r && r.indexOf("#") > -1 && r.indexOf("../") > -1 && u.attr("href", r.substring(r.indexOf("#"), r.length));
            n === _EnumCompareAction.INIT || u.closest("div").hasClass("hero-content-wrap") || !new RegExp("^" + C3.utils.queryStringEscape(RootUrl.slice(0, -1)) + "/","i").test(r) || /#/.test(r) || u.attr("href", /list=/i.test(r) ? r.replace(/list=[\d|\d,]*/g, t == "" ? t : "list=" + t).replace(/[\/\?|&]$/, "").replace(/\/$/, "") : t == "" ? r : r + (/\?/.test(r) ? "&list=" : /\/$/i.test(r) ? "?list=" : "/?list=") + t)
        })
    }
    ;
    this.defaults = {
        classSelectedCard: "selected-card",
        classIgnore: "ignore",
        classCloseModal: "generic-modal_close",
        classCompareModalBottom: "compare-modal_bottom",
        classCompareModalItem: "compare-modal-item",
        classRemove: "remove",
        selectedCardOldValue: null
    };
    this.addRemoveCard = function(n) {
        var t = n.find("#cardId")
          , i = $("#" + CompareCardListName);
        if (_GetAction(n) == _EnumCompareAction.REMOVE)
            _RemoveCard(i, t.val());
        else {
            if (!_IsValidCard(t, n.offset().top, n.offset().left))
                return;
            _AddCard(t.val());
            _UpdateUrls()
        }
        n.toggleClass(_Defaults.classAdded);
        _DisableButton(i.val());
        _UpdateMenuCount()
    }
    ;
    this.compareCardAddCard = function(n) {
        var i = n.find("input").val(), t;
        n.hasClass(C3.compare.defaults.classSelectedCard) || _IsValidCard(n.find("input"), n.offset().top, n.offset().left, n) && (t = $(".table td>input[value='0']:first").parent(),
        n.addClass(C3.compare.defaults.classSelectedCard),
        n.find(".icon-circle-check").attr("aria-hidden", "false"),
        t.empty(),
        $(_Defaults.htmlUpdateCard).appendTo(t),
        _CompareCardUpdateCard(i),
        _SetCompareCardList({
            id: i,
            action: _EnumCompareAction.ADD
        }),
        _SetCollapseComparePanel())
    }
    ;
    this.compareCardRemoveCard = function(n) {
        var t, i, r;
        if (n.preventDefault(),
        t = $(this),
        i = _GetCardData(t),
        _SetCompareCardList(i),
        _SetCollapseComparePanel(),
        i.isSelectable) {
            t.closest(".compare-modal_bottom").parent().find("." + C3.compare.defaults.classSelectedCard).each(function() {
                parseInt($(this).find("input").val()) == i.id && $(this).removeClass(C3.compare.defaults.classSelectedCard).find(".icon-circle-check").attr("aria-hidden", "true")
            });
            r = t.closest("td");
            r.empty();
            $(_Defaults.htmlUpdateCard).appendTo(r);
            _CompareCardUpdateCard(0);
            return
        }
        C3.compare.reloadPage()
    }
    ;
    this.getCompareCardList = function(n) {
        return n ? C3.utils.arrayRemoveZeros($("#" + _Defaults.idCompareCardList).val().split(",")) : $("#" + _Defaults.idCompareCardList)
    }
    ;
    this.initializePage = function() {
        var n = _UrlGetCardList();
        _DisableButton(n);
        _UpdateMenuCount(_EnumCompareAction.INIT);
        _UpdateUrls(_EnumCompareAction.INIT)
    }
    ;
    this.reloadPage = function() {
        var n = C3.utils.queryStringUpdateParameter(_Defaults.urlParam_List)
          , t = C3.compare.getCompareCardList(!0);
        C3.utils.reloadPage(_Defaults.urlPage_CompareCards, _Defaults.urlPage_CompareCardsVanity, t.length == 0 ? n.substring(1) : _Defaults.urlParam_List + "=" + t + n)
    }
    ;
    this.sizeAdjustment = function() {
        for (var i, r, e, n = {
            widthTop: null ,
            widthElement: null ,
            translate3D: null
        }, u = $("#mobile-view .slider.slider-for.top-row.slick-initialized.slick-slider div[role='listbox']"), f = $("#mobile-view #compareRow div[role='listbox']"), t = 0; t < u.length; t++)
            i = u.eq(t),
            i.width() > 0 && (n.widthTop = i.css("width"),
            n.translate3D = i[0].style.transform,
            n.widthElement = i.children(":first").css("width"));
        if (n.widthTop != null )
            for (t = 0; t < f.length; t++)
                r = f.eq(t),
                e = parseInt(r.css("width").replace("px", "").replace("em", "").replace("%", "")),
                e === 0 && (r.css("width", n.widthTop),
                r[0].style.transform = n.translate3D,
                r.children().each(function() {
                    $(this).css("width", n.widthElement)
                }))
    }
    ;
    this.updateUrls = function() {
        _UpdateUrls(_EnumCompareAction.INIT);
        _SetCollapseComparePanel()
    }
}
.apply(C3.compare),
function() {
    var n = {
        categoryNames: null ,
        categoryName: null
    };
    _Dictionary = function() {
        var n = {};
        this.setData = function(t, i) {
            n[t] = i
        }
        ;
        this.getData = function(t) {
            return n[t]
        }
    }
    ;
    _Initialize = function() {
        n.CategoryNames = new _Dictionary;
        n.CategoryNames.setData("1", "allcc");
        n.CategoryNames.setData("2", "cshbck");
        n.CategoryNames.setData("3", "blatrns");
        n.CategoryNames.setData("4", "travl");
        n.CategoryNames.setData("5", "sbiz");
        n.CategoryNames.setData("6", "rwds");
        n.CategoryNames.setData("7", "nannfee");
        n.CategoryNames.setData("8", "nofx");
    }
    ;
    
}
.apply(C3.tags);

</script>-->
<div data-module="sub-nav" class="sub-nav module--initialized up"><!--fixthis -->
    <h2 class="sr-only">Choose a Category</h2>
    <div class="mobile-nav showNav">
        <ul>
            <li class="selected sub-nav-item all-cards active">
                <a id="choose-cat-btn" href="#"><span class="choose">Choose a Category</span><sup class="sr-only"> opens overlay </sup></a><span class="icon-arrow-down"><sup class="sr-only">arrow icon</sup> </span>
            </li>
        </ul>
        <ul class="compare">
            <li class="sub-nav-item compare-cards compare-cards-0">
                <a id="CompareCardsGeneral" href="https://creditcards.chase.com/credit-cards/compare-cards?iCELL=61HG&amp;jp_ltg=chsecate_compare" class="chaseanalytics-track-link"><img src="https://creditcards.chase.com/R-Marketplace/1110008/images/compare-cards.svg" alt="compare cards icon" style="border-width:0px;"><span>Compare</span></a>
            </li>
        </ul>
    </div>
    <div id="menuHorizontalLeft" class="category-selector">
        <ul>
            
                    <li id="HorizontalMenuLeftListItem" class="sub-nav-item active">
                        <a id="HorizontalMenuLink_1" href="https://creditcards.chase.com/credit-cards/home?iCELL=61FX&amp;jp_ltg=chsecate_featured" class="chaseanalytics-track-link icon-featured-card featured-cards-cat" data-arrow-id="featured"><span>Featured Cards (7)</span></a></li>
                
                    <li id="HorizontalMenuLeftListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLink_2" href="https://creditcards.chase.com/credit-cards/browse-all?iCELL=61FY&amp;jp_ltg=chsecate_allcards" class="chaseanalytics-track-link icon-cards all-cards-cat" data-arrow-id="all-cards"><span>All Cards (22)</span></a></li>
                
                    <li id="HorizontalMenuLeftListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLink_3" href="https://creditcards.chase.com/credit-cards/travel?iCELL=61GD&amp;jp_ltg=chsecate_travel" class="chaseanalytics-track-link icon-travel travel-cat" data-arrow-id="travel"><span>Travel (16)</span></a></li>
                
                    <li id="HorizontalMenuLeftListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLink_4" href="https://creditcards.chase.com/credit-cards/cash-back?iCELL=61FZ&amp;jp_ltg=chsecate_cashback" class="chaseanalytics-track-link icon-cash-back cash-back-cat" data-arrow-id="cash-back"><span>Cash Back (5)</span></a></li>
                
                    <li id="HorizontalMenuLeftListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLink_5" href="https://creditcards.chase.com/credit-cards/balance-transfer?iCELL=61GB&amp;jp_ltg=chsecate_blntransfr" class="chaseanalytics-track-link icon-balance-transfer balance-transfer-cat" data-arrow-id="balance-transfer"><span>Balance Transfer (5)</span></a></li>
                
                    <li id="HorizontalMenuLeftListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLink_6" href="https://creditcards.chase.com/credit-cards/small-business?iCELL=61GF&amp;jp_ltg=chsecate_smlbiz" class="chaseanalytics-track-link icon-small-business small-business-cat" data-arrow-id="small-business"><span>Small Business (5)</span></a></li>
                
                    <li id="HorizontalMenuLeftListItem" class="sub-nav-item more">
                        <a id="HorizontalMenuLink_999" href="#" class="chaseanalytics-track-link icon-more more-cat" data-arrow-id="more"><span>More Categories</span></a>
<div class="more-menu">
    <div class="white-space"></div>
    <ul>
        
                <li class="sub-nav-item more-menu-item">
                    <a id="HorizontalSubmenuLeftLink_8" href="https://creditcards.chase.com/credit-cards/rewards?iCELL=61GK&amp;jp_ltg=chsecate_rewards" class="chaseanalytics-track-link icon-rewards rewards-cat" data-arrow-id="more"><span>Rewards (21)</span></a></li>
            
                <li class="sub-nav-item more-menu-item">
                    <a id="HorizontalSubmenuLeftLink_9" href="https://creditcards.chase.com/credit-cards/no-annual-fee?iCELL=61GZ&amp;jp_ltg=chsecate_noannlfee" class="chaseanalytics-track-link icon-annual-fee annual-fee-cat" data-arrow-id="more"><span>No Annual Fee (6)</span></a></li>
            
                <li class="sub-nav-item more-menu-item">
                    <a id="HorizontalSubmenuLeftLink_10" href="https://creditcards.chase.com/credit-cards/no-foreign-transaction-fee?iCELL=61HB&amp;jp_ltg=chsecate_nofxfee" class="chaseanalytics-track-link icon-foreign-transaction-fee foreign-transaction-fee-cat" data-arrow-id="more"><span>No Foreign Transaction Fee (13)</span></a></li>
            
        
                <li class="sub-nav-item more-menu-item">
                    <a id="HorizontalSubmenuRightLink_11" href="https://creditcards.chase.com/credit-cards/0-intro-apr?iCELL=61HC&amp;jp_ltg=chsecate_0introapr" class="chaseanalytics-track-link icon-earn-point earn-point-cat" data-arrow-id="more"><span>0% Intro APR (5)</span></a></li>
            
                <li class="sub-nav-item more-menu-item">
                    <a id="HorizontalSubmenuRightLink_12" href="https://creditcards.chase.com/credit-cards/visa?iCELL=61HD&amp;jp_ltg=chsecate_visa" class="chaseanalytics-track-link icon-visa visa-cat" data-arrow-id="more"><span>Visa (21)</span></a></li>
            
                <li class="sub-nav-item more-menu-item">
                    <a id="HorizontalSubmenuRightLink_13" href="https://creditcards.chase.com/credit-cards/mastercard?iCELL=61HF&amp;jp_ltg=chsecate_mastrcard" class="chaseanalytics-track-link icon-mastercard mastercard-cat" data-arrow-id="more"><span>MasterCard (1)</span></a></li>
            
    </ul>
</div>
</li>
                
            
                    <li id="HorizontalMenuRightListItem" class="sub-nav-item compare-cards compare-cards-0">
                        <a id="HorizontalMenuLink_14" href="https://creditcards.chase.com/credit-cards/compare-cards?iCELL=61HG&amp;jp_ltg=chsecate_compare" class="chaseanalytics-track-link icon-compare-cards"><span>Compare cards</span></a></li>
                
        </ul>
    </div>
    <div class="category-selector-mobile">
        <h2>Choose a Category</h2>
        <a id="close-button-category" class="close" tabindex="0" href="javascript:;"><span class="sr-only">Close</span></a>
        <ul id="mobile-menu-area">
            
            
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item active">
                        <a id="HorizontalMenuLinkMobile_1" href="https://creditcards.chase.com/credit-cards/home?iCELL=61FX&amp;jp_ltg=chsecate_featured" class="chaseanalytics-track-link icon-featured-card featured-cards-cat" data-arrow-id="featured"><span>Featured Cards (7)</span></a>
                    </li>
                
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLinkMobile_2" href="https://creditcards.chase.com/credit-cards/browse-all?iCELL=61FY&amp;jp_ltg=chsecate_allcards" class="chaseanalytics-track-link icon-cards all-cards-cat" data-arrow-id="all-cards"><span>All Cards (22)</span></a>
                    </li>
                
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLinkMobile_3" href="https://creditcards.chase.com/credit-cards/travel?iCELL=61GD&amp;jp_ltg=chsecate_travel" class="chaseanalytics-track-link icon-travel travel-cat" data-arrow-id="travel"><span>Travel (16)</span></a>
                    </li>
                
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLinkMobile_4" href="https://creditcards.chase.com/credit-cards/cash-back?iCELL=61FZ&amp;jp_ltg=chsecate_cashback" class="chaseanalytics-track-link icon-cash-back cash-back-cat" data-arrow-id="cash-back"><span>Cash Back (5)</span></a>
                    </li>
                
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLinkMobile_5" href="https://creditcards.chase.com/credit-cards/balance-transfer?iCELL=61GB&amp;jp_ltg=chsecate_blntransfr" class="chaseanalytics-track-link icon-balance-transfer balance-transfer-cat" data-arrow-id="balance-transfer"><span>Balance Transfer (5)</span></a>
                    </li>
                
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLinkMobile_6" href="https://creditcards.chase.com/credit-cards/small-business?iCELL=61GF&amp;jp_ltg=chsecate_smlbiz" class="chaseanalytics-track-link icon-small-business small-business-cat" data-arrow-id="small-business"><span>Small Business (5)</span></a>
                    </li>
                
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLinkMobile_8" href="https://creditcards.chase.com/credit-cards/rewards?iCELL=61GK&amp;jp_ltg=chsecate_rewards" class="chaseanalytics-track-link icon-rewards rewards-cat" data-arrow-id="more"><span>Rewards (21)</span></a>
                    </li>
                
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLinkMobile_9" href="https://creditcards.chase.com/credit-cards/no-annual-fee?iCELL=61GZ&amp;jp_ltg=chsecate_noannlfee" class="chaseanalytics-track-link icon-annual-fee annual-fee-cat" data-arrow-id="more"><span>No Annual Fee (6)</span></a>
                    </li>
                
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLinkMobile_10" href="https://creditcards.chase.com/credit-cards/no-foreign-transaction-fee?iCELL=61HB&amp;jp_ltg=chsecate_nofxfee" class="chaseanalytics-track-link icon-foreign-transaction-fee foreign-transaction-fee-cat" data-arrow-id="more"><span>No Foreign Transaction Fee (13)</span></a>
                    </li>
                
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLinkMobile_11" href="https://creditcards.chase.com/credit-cards/0-intro-apr?iCELL=61HC&amp;jp_ltg=chsecate_0introapr" class="chaseanalytics-track-link icon-earn-point earn-point-cat" data-arrow-id="more"><span>0% Intro APR (5)</span></a>
                    </li>
                
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLinkMobile_12" href="https://creditcards.chase.com/credit-cards/visa?iCELL=61HD&amp;jp_ltg=chsecate_visa" class="chaseanalytics-track-link icon-visa visa-cat" data-arrow-id="more"><span>Visa (21)</span></a>
                    </li>
                
                    <li id="HorizontalMenuMobileListItem" class="sub-nav-item">
                        <a id="HorizontalMenuLinkMobile_13" href="https://creditcards.chase.com/credit-cards/mastercard?iCELL=61HF&amp;jp_ltg=chsecate_mastrcard" class="chaseanalytics-track-link icon-mastercard mastercard-cat" data-arrow-id="more"><span>MasterCard (1)</span></a>
                    </li>
                
            
        </ul>
        <a id="close-button-category-bottom" tabindex="0" href="javascript:;"><span class="sr-only">Close</span></a>
    </div>
    <div class="line">
        <div class="container">
            <div id="line-arrow" class="featured"></div>
        </div>
    </div>
</div>