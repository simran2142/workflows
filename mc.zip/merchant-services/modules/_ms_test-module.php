

<div class="GiveModuleAClassName module-container row"> <!--(remove - row - if needed)-->
		
	<div class="col-xs-12 module-bucket"> <!--(add bootstrap classes here if needed)-->
		<div class="customWhatever" style="width:160px; margin:auto; text-align:center">
			<h3 class="moduleTitle">Look at this Module</h3>
			<p class="moduleCopy"></p>
			<img src="http://placekitten.com/150/150" />
		</div>
	</div>

</div><!-- /.module-container -->

