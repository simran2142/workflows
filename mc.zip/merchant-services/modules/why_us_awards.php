  <section id="whyus-awards" class="container">
    <div class="row">
      <div id="whyus-awards__accordion" class="col-xs-12 col-sm-8 col-sm-offset-2 colnopadding-small-up module-padding-large"><div id="accordion__component" data-accordion="" class="module accordion">
  <div id="accordion-intro" class="header-font-family text-center text-xs-left">
    <h2 id="intro__title" class="accordion__tittle">Awards and recognition</h2>
    <p id="intro__desc" class="delta accordion__tittle--sub">JPMorgan Chase &amp; Co. has consistently ranked as one of the top employers in our industry categories across key Employer Brand rankings.</p>
  </div>

  <div id="accordion-wrapper-container" class="accordion-wrapper"><div id="accordion-block" class="accordion-section">
      <a id="data-content__a" class="accordion-section-title" href="#" data-content-trigger="0.33187205618706284-1">See recent awards here</a>
      <div id="data-content__div" data-content="0.33187205618706284-1" class="accordion-section-content">
        <div class="accordion-section-content-wrapper">
          <p id="accordion-block-summary"></p><ul><li>Top 5 Most Prestigious Companies to Intern for among current and former interns by Vault - 2016</li><li>Top 10 World’s Most Attractive Employers among Business students by Universum - 2015</li><li>One of the only three “mega-banks” among 50 companies in the World’s Most Admired Companies by Forbes -2015</li><li>Top company for Vault Banking 50 since 2012</li><li>Top 5 Most Attractive Employers among Business students by Universum - 2014-2015 (US)</li><li>Top 5 Most Attractive Employers among Business students by Universum - 2012-2015 (UK)</li><li>#1 Singapore’s Most Attractive Financial Employer among Business students by Universum - 2015</li><li>Top Company for Best Places to Work in UK by Glassdoor - 2015</li><li>Graduate Employer of Choice for Investment Banking by The Times Graduate Recruitment Awards - 2013-2015</li></ul>
        </div>
      </div>
    </div></div>
</div></div>
    </div>
  </section>