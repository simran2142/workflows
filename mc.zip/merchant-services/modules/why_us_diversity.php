  <section id="whyus-impact__diversity" class="module-spacing-base"><div class="container">
      <div class="row">
        <div id="video-intro" class="col-xs-12 col-md-8 col-md-push-2 text-center text-xs-left"><article class="title-desc margin-bottom-md">
  <h2 id="intro__title" class="title-desc__title {{extraclass}}">A workplace for everyone</h2>
  <p id="intro__desc" class="title-desc__desc delta header-font-family">Here, you’ll feel welcomed and valued. Our clients, transactions, deals and projects are global so we work hard to create diverse, inclusive teams that support our business and each other - it's good for business and it makes sense.</p>
</article></div>
      </div>
    </div>

    <div class="container module-spacing-base colnoleftpadding-xs colnorightpadding-xs">
      <div class="row">
        <div id="video__container" class="col-xs-12 padding-reset"><div class="video-containing-block">
            <div class="video-inner-wrapper">
              <video data-video="" class="brightcove-video video-js" id="" data-videoid="5045730426001" data-autoplay="false" data-video-id="5045730426001" data-account="1139173452001" data-player="a6771937-047d-4f5f-88e6-a697b37b5456" data-embed="default" controls="" style="width: 100%; height: 100%; position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px;" data-width="960" data-height="534"></video>
            </div>
          </div></div>
      </div>
    </div></div>

  <div id="whyus-diversity__learnmore" class="container module-spacing-large">
    <div class="row">
      <div class="col-xs-12 text-center">
        <a id="whyus-diversity__learnmore-a" class="btn btn-outline red" href="http://careers.jpmorgan.com/careers/why-us/diversity">Learn more</a>
      </div>
    </div>
  </section>