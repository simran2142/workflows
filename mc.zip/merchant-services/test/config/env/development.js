'use strict';

module.exports = {
  karma: {
    browsers: ['PhantomJS'],
    preprocessors: {
      '**/*.php': ['ng-php2js'],
      '**/*.html' : ['html2js']
    },
    reporters: ['spec'
    // , 'coverage'
    ],
    autoWatch: true,
    singleRun: false
  }
};